---
name: brandformance-community-report
description: "Kích hoạt khi cần đánh giá riêng community health — growth, engagement rate, sentiment, tỉ lệ chuyển đổi sang funnel chính — khác với content-report (đo bài đăng social nói chung). Trigger: 'báo cáo community', 'đánh giá group Facebook/Zalo', 'community health', 'group có đang hoạt động tốt không', 'community có ra doanh thu không'. Kích hoạt khi community đã vận hành một thời gian (từ brandformance-community-building.md) và cần đánh giá hiệu quả."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Community Report

## 1. Triggers

### Explicit triggers
- "báo cáo community", "đánh giá group Facebook/Zalo"
- "community có đang hoạt động tốt không?", "community có ra doanh thu không?"

### Implicit triggers
- Community đã vận hành ≥1 tháng theo `brandformance-community-building.md`, chưa từng đánh giá lại
- Thành viên group tăng nhưng không rõ có đang tạo giá trị kinh doanh không
- Chuẩn bị dùng `brandformance-next-cycle.md` → cần community report làm input

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Data community (số thành viên, bài đăng, tương tác) trong khoảng thời gian
- [ ] **[BẮT BUỘC]** Loại community đang vận hành (TOFU open / MOFU semi-closed / BOFU closed — theo `brandformance-community-building.md`)
- [ ] **[NẾU CÓ]** Data kỳ trước để so sánh, số liệu chuyển đổi từ community sang lead/KH

Đọc trước khi thực hiện:
- `brandformance-community-building.md` → Toàn bộ (loại community, KPI kỳ vọng theo từng loại)
- `brandformance-measurement.md`

## 3. Execution Steps

### Bước 1: Thu thập số liệu growth và engagement
- **Growth**: Thành viên mới, thành viên rời đi (net growth)
- **Engagement rate**: Tổng comment/reaction / Tổng số bài đăng
- **Tỉ lệ active**: % thành viên đã tương tác (comment/reaction/xem) trong 30 ngày gần nhất — chỉ số quan trọng hơn tổng số thành viên

### Bước 2: Đánh giá theo đúng loại community
KPI kỳ vọng khác nhau theo loại (từ `brandformance-community-building.md`):
| Loại | KPI chính |
|---|---|
| TOFU (Open) | Growth, reach, tỉ lệ tương tác nội dung giáo dục |
| MOFU (Semi-closed) | Tỉ lệ tham gia Q&A/poll, chuyển đổi sang lead |
| BOFU (Closed, đã mua) | Tỉ lệ tham gia hoạt động, referral phát sinh, repeat purchase |

Không đánh giá TOFU community bằng KPI chuyển đổi — cũng giống nguyên tắc TOFU content không nên đo bằng lead.

### Bước 3: Phân tích content nào tạo engagement cao nhất trong group
Challenge/câu hỏi mở thường có engagement cao hơn value post thuần túy; Member spotlight tạo social proof tốt — xác định pattern để lặp lại đúng loại nội dung hiệu quả.

### Bước 4: Đo lường chuyển đổi từ Community sang Funnel chính
Bao nhiêu member đã trở thành lead/KH? Đây là chỉ số quan trọng nhất để biện minh cho nguồn lực duy trì community — nếu = 0 sau thời gian dài vận hành, cần xem lại mục đích/vị trí community trong phễu.

### Bước 5: Sentiment check
Tổng hợp cảm nhận chung của member qua comment: tích cực (khen, tag bạn bè), trung lập, tiêu cực (phàn nàn, report spam) — không cần công cụ phức tạp, đọc qua 20-30 comment gần nhất là đủ để có cảm nhận định tính.

### Bước 6: Build Community Report + đề xuất action
Action cụ thể: tăng/giảm tần suất loại content nào, có nên mở rộng quy mô hay không, có cần điều chỉnh mục đích community không.

## 4. Examples

### Example 1 — Generic: Community "Tài chính thực tế cho người đi làm" (TOFU Open, báo cáo tháng)
```
GROWTH: +450 thành viên mới, -30 rời đi → Net +420
ENGAGEMENT: Trung bình 35 comment/reaction mỗi bài (kỳ trước 22) — tăng 59%
TỈ LỆ ACTIVE: 28% thành viên tương tác trong 30 ngày (bình thường với TOFU open, không cần cao)

CONTENT PATTERN: Bài "Bạn đang tiết kiệm bằng cách nào?" (câu hỏi mở) có 120 comment — cao nhất tháng.
Value post tutorial trung bình chỉ 15 comment.

CHUYỂN ĐỔI: 12 member đã trở thành lead qua Lead Magnet chia sẻ trong group (thấp nhưng đúng kỳ vọng TOFU)

ACTION: Tăng tần suất câu hỏi mở lên 2 lần/tuần (từ 1 lần), giữ nguyên vai trò TOFU — không kỳ vọng chuyển đổi cao ở đây.
```

### Example 2 — Giáo dục: Alumni Club khóa học (BOFU Closed, báo cáo quý)
```
GROWTH: +85 alumni mới (từ học viên vừa hoàn thành khóa) — 100% đúng như kỳ vọng (chỉ nhận học viên đã mua)
TỈ LỆ ACTIVE: 62% — cao, đúng đặc thù BOFU community (nhóm nhỏ, gắn kết hơn)

ĐO CHUYỂN ĐỔI: 18 alumni đã giới thiệu bạn bè đăng ký khóa mới (referral phát sinh tự nhiên từ community)
→ Insight quan trọng: nên chính thức hóa qua `brandformance-referral-program.md`

SENTIMENT: Đọc 30 comment gần nhất — 90% tích cực, 2 phàn nàn về tốc độ phản hồi Office Hours

ACTION: Tăng tần suất Office Hours từ 2 lần/tháng lên 4 lần để giải quyết phàn nàn; chính thức hóa referral.
```

## 5. Edge Cases & Error Handling

**Group tăng thành viên nhưng tỉ lệ active giảm** (vanity growth): Dấu hiệu đang thu hút sai đối tượng hoặc follow-growth tactic đang đổi ưu đãi lấy số lượng — ưu tiên xem lại nguồn tăng trưởng hơn là mừng vì số lớn.

**Engagement thấp nhưng thực ra do content quá quảng cáo**: Kiểm tra tỉ lệ content giá trị vs content bán hàng trong group — quy tắc 80% giá trị/20% soft mention từ `brandformance-community-building.md` có đang bị vi phạm không.

**Không convert được community sang doanh thu dù engagement cao**: Với TOFU/MOFU community, đây có thể là bình thường trong ngắn hạn — nhưng nếu kéo dài nhiều quý không có chuyển đổi nào, cần đánh giá lại vị trí community trong phễu tổng thể (`brandformance-funnel-audit.md`).

## 6. State Management

| State | Claude làm gì |
|---|---|
| `DATA_COLLECT` | Thu thập growth + engagement |
| `TYPE_EVALUATE` | Đánh giá theo đúng loại community |
| `PATTERN_FIND` | Phân tích content hiệu quả |
| `CONVERSION_MEASURE` | Đo chuyển đổi sang funnel chính |
| `SENTIMENT_CHECK` | Kiểm tra cảm nhận member |
| `DONE` | Community Report + action đề xuất |

## References
- `brandformance-community-building.md` → Toàn bộ (loại community, KPI kỳ vọng)
- `brandformance-content-report.md` → Phân biệt với báo cáo content social nói chung
- `brandformance-referral-program.md` → Khi phát hiện referral tự nhiên từ community
- `brandformance-funnel-audit.md` → Khi community không convert được sang funnel chính
