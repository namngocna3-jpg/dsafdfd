---
name: brandformance-kpi-setup
description: "Kích hoạt khi cần thiết lập khung KPI Brandformance — North Star Metric, OMTM, mapping KPI ngược từ mục tiêu doanh thu, KPI riêng cho Brand và Performance. Trigger: 'setup KPI', 'KPI framework', 'NSM OMTM', 'KPI nào quan trọng', 'đặt KPI cho marketing', 'KPI mapping từ doanh thu', 'không biết nên đo cái gì'. Kích hoạt cả khi đang đo quá nhiều chỉ số mà không biết cái nào thực sự quan trọng."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# KPI Setup

## 1. Triggers

### Explicit triggers
- "setup KPI marketing", "KPI framework", "NSM là gì, OMTM là gì"
- "KPI mapping từ doanh thu", "không biết nên đo cái gì"

### Implicit triggers
- Đang track hàng chục chỉ số nhưng không rõ cái nào quyết định
- Báo cáo hàng tuần dài nhưng không dẫn đến hành động cụ thể
- Brand KPI và Performance KPI đang bị lẫn lộn, so sánh sai bản chất
- Chuẩn bị chu kỳ mới (tháng/quý) → cần đặt lại KPI rõ ràng

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Mục tiêu doanh thu của chu kỳ (tháng/quý)
- [ ] **[BẮT BUỘC]** Giai đoạn kinh doanh (mới / tăng trưởng / ổn định / scale)
- [ ] **[BẮT BUỘC]** Các kênh đang chạy (ads, content, email...)
- [ ] **[NẾU CÓ]** Data lịch sử: CPL, tỉ lệ chốt, AOV

Đọc trước khi thực hiện:
- `brandformance-measurement.md` → Toàn bộ (NSM, AARRR, OMTM, Benchmark)
- `brandformance-framework.md` → Phần V (Phễu AAARRR)

## 3. Execution Steps

### Bước 1: Xác định North Star Metric (NSM)
NSM phải phản ánh giá trị KH thực sự nhận được, không phải chỉ số vanity. Ví dụ: không phải "số follower" mà là "số KH quay lại mua lần 2" hoặc "số lead chất lượng chuyển thành doanh thu".

Câu hỏi để tìm NSM: "Nếu chỉ được nhìn 1 con số để biết business đang khỏe hay không, đó là gì?"

### Bước 2: Map đầy đủ khung AARRR
| Giai đoạn | KPI chính |
|---|---|
| Awareness | CPM, Reach, Video View Rate |
| Acquisition | CPL, CTR, số lead |
| Activation | Tỉ lệ lead qualified, tỉ lệ inbox → tư vấn |
| Retention | Tỉ lệ mua lần 2, open rate |
| Revenue | AOV, ROAS, MER, CAC, LTV |
| Referral | % lead từ giới thiệu, UGC tự nhiên |

### Bước 3: Chọn OMTM (One Metric That Matters) cho chu kỳ hiện tại
OMTM = chỉ số **yếu nhất** trong AARRR hiện tại — không phải chỉ số quan trọng nhất theo lý thuyết chung. Nếu Acquisition (CPL) đang ổn nhưng Retention (mua lần 2) rất thấp → OMTM tháng này là tỉ lệ mua lần 2, dồn nguồn lực vào đó.

### Bước 4: KPI mapping ngược từ doanh thu
```
Mục tiêu doanh thu → / AOV → Số đơn cần
Số đơn cần → / Tỉ lệ chốt → Số lead qualified cần
Số lead qualified → / Tỉ lệ MQL→SQL → Số lead tổng cần
Số lead tổng → × CPL benchmark → Ngân sách acquisition cần
```
So sánh ngân sách cần với ngân sách thực có — nếu không đủ, điều chỉnh target hoặc cải thiện tỉ lệ chuyển đổi thay vì chỉ tăng ngân sách.

### Bước 5: Build KPI Dashboard structure
- **Daily**: Spend pace, CPL tức thời (chỉ để phát hiện bất thường)
- **Weekly**: CPL, tỉ lệ lead qualified, tỉ lệ chốt, ROAS, MER
- **Monthly**: Brand KPI (reach tự nhiên, follower growth) + toàn bộ Performance KPI + NSM

### Bước 6: Setup benchmark và ngưỡng cảnh báo
Với mỗi KPI, xác định: benchmark ngành/nội bộ + ngưỡng cảnh báo (khi nào cần xem lại) + ngưỡng dừng (khi nào cần hành động ngay).

## 4. Examples

### Example 1 — Generic: Spa làm đẹp, mục tiêu 200 triệu doanh thu/tháng
```
NSM: Tỉ lệ khách quay lại liệu trình thứ 2 (phản ánh thật hiệu quả dịch vụ)

MAPPING NGƯỢC:
200 triệu / AOV 4 triệu = 50 đơn cần
50 đơn / tỉ lệ chốt 25% = 200 lead qualified cần
200 lead / tỉ lệ MQL→SQL 50% = 400 lead tổng cần
400 lead × CPL 150K = 60 triệu ngân sách acquisition cần

OMTM THÁNG NÀY: Tỉ lệ chốt đang chỉ 15% (thấp hơn target 25%) → dồn lực vào cải thiện
Sales script và Lead Scoring, KHÔNG tăng thêm ngân sách ads.
```

### Example 2 — Giáo dục: Trung tâm ngoại ngữ, giai đoạn tăng trưởng
```
NSM: Số học viên hoàn thành khóa + giới thiệu bạn bè mới

AARRR HIỆN TẠI:
Awareness: Reach ổn (50K/tháng) ✓
Acquisition: CPL 250K, đang tốt ✓
Activation: Chỉ 40% lead đăng ký học thử tham gia đầy đủ ⚠️ ← OMTM
Retention: Chưa đo được
Revenue: ROAS 3.2x ✓

OMTM: Tăng tỉ lệ tham gia học thử đầy đủ từ 40% lên 65% — ưu tiên số 1 tháng này,
tạm dừng thử nghiệm kênh mới cho đến khi cải thiện điểm này.
```

## 5. Edge Cases & Error Handling

**Muốn theo dõi tất cả KPI cùng lúc với độ ưu tiên ngang nhau**: Dẫn đến phân tán nguồn lực — luôn chỉ có 1 OMTM tại một thời điểm, các KPI khác vẫn theo dõi nhưng không phải trọng tâm hành động.

**KPI leading và lagging bị nhầm lẫn**: CPL, CTR là leading (biết sớm); Doanh thu, LTV là lagging (biết muộn nhưng chính xác hơn) — dùng leading để điều chỉnh nhanh, lagging để đánh giá tổng thể.

**Không có baseline để so sánh (lần đầu đo)**: Chạy 2-4 tuần đầu chỉ để thiết lập baseline, chưa đặt ngưỡng cảnh báo cứng.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `NSM_DEFINE` | Xác định North Star Metric |
| `AARRR_MAPPING` | Map đầy đủ khung AARRR |
| `OMTM_SELECT` | Chọn OMTM cho chu kỳ |
| `REVENUE_MAPPING` | Mapping ngược từ doanh thu |
| `DASHBOARD_BUILD` | Build cấu trúc Dashboard |
| `DONE` | KPI Framework hoàn chỉnh |

## References
- `brandformance-measurement.md` → Toàn bộ
- `brandformance-campaign-plan.md` → KPI mapping áp dụng khi lập plan
- `brandformance-funnel-audit.md` → Dùng KPI framework để chẩn đoán điểm nghẽn
