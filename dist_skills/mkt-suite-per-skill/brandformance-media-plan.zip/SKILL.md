---
name: brandformance-media-plan
description: >
  Lập media plan cho campaign — campaign structure, budget by funnel stage, KPI thresholds, điều kiện stop/scale. Kích hoạt khi: "media plan", "lập plan ads", "kế hoạch chạy ads", "phân bổ budget ads", "plan Meta Ads", "plan TikTok Ads".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Media Plan  
  
## 1. Triggers  
  
### Explicit triggers  
- "lập media plan", "plan ads tháng/quý này"  
- "kế hoạch chạy quảng cáo Meta/TikTok"  
- "phân bổ budget ads chi tiết", "campaign structure"  
  
### Implicit triggers  
- Vừa có Budget Allocation → cần chi tiết hóa phần paid media  
- ROAS thấp → cần review lại campaign structure  
- Sắp launch campaign → cần media plan để setup ads  
  
## 2. Context Requirements  
  
- [ ] **[BẮT BUỘC]** Ngân sách paid media tổng  
- [ ] **[BẮT BUỘC]** Kênh sẽ chạy (Meta / TikTok / Google)  
- [ ] **[BẮT BUỘC]** Mục tiêu: CPL target, ROAS target  
- [ ] **[BẮT BUỘC]** Thời gian chạy  
- [ ] **[NẾU CÓ]** Data lịch sử: CPL thật, CTR thật  
  
## 3. Execution Steps  
  
### Bước 1: Xác định objective theo tầng phễu  
  
| Tầng phễu | Objective Meta | Objective TikTok |  
|---|---|---|  
| TOFU | Awareness / Reach / Video Views | Reach / Video Views |  
| MOFU | Traffic / Lead Gen | Traffic / Lead Gen |  
| BOFU | Conversions / Sales | Conversions |  
| Retarget | Conversions | Conversions |  
  
Nguyên tắc: Phải có ít nhất 1 TOFU campaign — không phải toàn BOFU.  
  
### Bước 2: Thiết kế Campaign Structure  
  
```  
Campaign (Objective)  
 └─ Ad Set 1 (Audience A — Broad/Interest)  
 │ └─ Ad A1 (Creative 1)  
 │ └─ Ad A2 (Creative 2)  
 └─ Ad Set 2 (Audience B — Lookalike)  
 └─ Ad B1 (Creative 1)  
 └─ Ad B2 (Creative 2)  
```  
  
Testing phase: 2-3 creatives per ad set, 2-3 audiences per campaign.  
Scale phase: Chỉ scale cái đã prove — không scale cái chưa test.  
Retarget campaign: Luôn tách riêng với Prospecting.  
  
### Bước 3: Phân bổ ngân sách  
  
| Campaign type | % Ngân sách |  
|---|---|  
| TOFU Prospecting | 20-25% |  
| MOFU Lead Gen | 20-25% |  
| BOFU Conversion | 35-40% |  
| Retarget | 15-20% |  
  
Daily budget = Ngân sách tháng / 30 ngày.  
Không set daily budget < 100K/ngày per ad set.  
  
### Bước 4: KPI target và ngưỡng cắt  
  
| Tầng | KPI chính | Benchmark VN |  
|---|---|---|  
| TOFU | CPM, Video View Rate | CPM: 10-30K; VVR > 25% |  
| MOFU | CTR, CPL | CTR > 1% |  
| BOFU | CPA, ROAS | ROAS > 3-5× |  
  
Stop conditions:  
- Ad: CTR < 0.8% sau 3 ngày → Dừng creative  
- Ad Set: CPL > 2× target sau 7 ngày → Review audience  
- Campaign: ROAS < 1 sau 14 ngày → Review toàn bộ  
  
Scale conditions:  
- CTR > 2% + CPL ổn định 5 ngày → Scale 20-30%/tuần  
  
### Bước 5: Build Media Plan  
  
| Campaign | Objective | Budget/tháng | Audience | Creative | KPI Target |  
|---|---|---|---|---|---|  
| TOFU Brand | Awareness | X triệu | Broad | Video 15s | Reach Y |  
| BOFU Sale | Conversion | X triệu | Retarget 30d | Static | ROAS > B |  
  
Lịch review: Daily (spend pace) / 3 ngày (CTR creative) / 7 ngày (audience) / 14 ngày (tổng thể)  
  
## 4. Examples  
  
### Example 1 — Generic: Thuê xe du lịch (Meta, 15 triệu/tháng)  
```  
MEDIA PLAN — Thuê Xe (Tháng 8)  
  
[CAM 1] TOFU — 3 triệu  
Audience: Broad 28-55, Du lịch + Gia đình  
Creative: Video "Chuyến đi gia đình không cần lo chuyện di chuyển"  
KPI: Reach > 50K, VVR > 30%  
  
[CAM 2] MOFU Lead Gen — 4 triệu  
Ad Set A: Lookalike 1% từ KH cũ — 2 triệu  
Ad Set B: Interest: cưới hỏi + du lịch — 2 triệu  
Creative: "Báo giá xe 7 chỗ tháng 8 — Inbox ngay"  
KPI: CPL < 150K  
  
[CAM 3] BOFU Retarget — 5 triệu  
Audience: Video viewers 75% (30 ngày) + Engaged page (60 ngày)  
Creative: "Đặt xe trước 10/8 — Giá ưu đãi đoàn du lịch"  
KPI: CPL < 100K, Tỉ lệ inquiry → hợp đồng > 20%  
  
[CAM 4] Remarketing LP — 3 triệu (landing page visitors chưa submit form)  
  
Contingency: 0 triệu — giữ để scale winner  
  
NGƯỠNG CẮT:  
- Ad CTR < 0.8% sau 3 ngày → Dừng  
- Ad Set CPL > 300K sau 7 ngày → Pause  
```  
  
### Example 2 — Giáo dục: IELTS Center (Meta + TikTok, 20 triệu/tháng)  
```  
META ADS — 14 triệu:  
TOFU: 3 triệu — "Học IELTS sau 5 giờ chiều, không nghỉ làm"  
MOFU Lead: 5 triệu — Lookalike từ trial users  
BOFU Retarget: 4 triệu — LP visitors  
Remarketing: 2 triệu — form abandonment  
  
TIKTOK ADS — 6 triệu:  
TOFU Brand: 4 triệu — In-feed video 15-30s, education hook  
BOFU: 2 triệu — retarget video viewers 50%  
  
KPI TỔNG:  
Meta CPL target: 350K (từ 500K → optimize bằng creative mới)  
TikTok CPL target: 300K (benchmark mới, chưa có data)  
  
Sau 2 tuần: So sánh Meta vs TikTok CPL → reallocate budget về kênh hiệu quả hơn  
```  
  
## 5. Edge Cases & Error Handling  
  
**Case 1: Budget nhỏ (< 5 triệu/tháng)**  
→ 1 Lead Gen + 1 Retarget. TOFU = Organic content.  
  
**Case 2: Ads không ra kết quả sau 2 tuần**  
→ Trước khi tăng budget: Kiểm tra funnel (landing page, offer, follow-up).  
→ 80% vấn đề không phải ở ads mà ở sau ads.  
  
**Case 3: Meta CPM tăng cao**  
→ Thử TikTok (CPM thấp hơn 30-50%); Focus Retarget (CPM thấp hơn cold).  
  
**Case 4: Muốn chạy tất cả kênh với budget nhỏ**  
→ Flag: "Mỗi kênh tối thiểu 3-5 triệu/tháng để có data tốt."  
  
## 6. State Management  
  
| State | Mô tả | Claude làm gì |  
|---|---|---|  
| `OBJECTIVE_SETTING` | Xác định objective | Chạy Bước 1 |  
| `STRUCTURE_DESIGN` | Thiết kế campaign structure | Chạy Bước 2 |  
| `BUDGET_BREAKDOWN` | Phân bổ budget | Chạy Bước 3 |  
| `KPI_SETTING` | Đặt KPI và ngưỡng cắt | Chạy Bước 4 |  
| `BUILDING` | Build Media Plan | Chạy Bước 5 |  
| `DONE` | Plan hoàn chỉnh | Đề xuất lưu vào Google Sheets để track daily |  
  
## References  
  
- `brandformance-ads.md` → Phần II (Testing), Phần III (Tối ưu), Phần IV (Scale)  
- `brandformance-measurement.md` → Phần IV (KPI Dashboard)  
  
Benchmark CPL theo ngành (VN 2025, ước tính):  
- Giáo dục (khóa học): 100-300K/lead  
- F&B: 20-50K/inquiry  
- Dịch vụ SME B2B: 300K-1 triệu/lead  
- Mỹ phẩm/Spa: 50-150K/inbox
