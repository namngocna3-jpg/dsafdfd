# Xây dựng Cộng đồng Facebook bền vững
Distil từ "JOBVUI - TAS: Bài giảng xây cộng đồng" — Chiến Binh Fullstack Marketing (GV Tấn Lê).

## 1. Cộng đồng là gì & vì sao xây
Cộng đồng FB = một **"xã hội thu nhỏ"** dựa trên mối quan tâm / mục tiêu / lợi ích / nhu cầu chung.
- **Lợi ích cá nhân:** xây personal brand, bán hàng & "bán thân", mở network, chia sẻ, kiếm tiền qua booking.
- **Lợi ích doanh nghiệp:** tiếp cận đúng tệp khách, thử nghiệm & thu insight, duy trì tương tác + tăng nhận diện, kênh vệ tinh quảng bá, **giảm chi phí marketing & sale**.

## 2. BỘ 4 KIM CHỈ NAM tạo cộng đồng bền vững (làm rõ 4 cái này TRƯỚC khi lập nhóm)

### Kim chỉ nam 1 — MỤC TIÊU CỐT LÕI
Điều số đông cộng đồng muốn đạt được sau cùng. Phải: (a) là mong muốn/khao khát sau cùng của mọi người, (b) là thứ **đạt được/giải quyết được**, (c) **gọi tên & đo đếm được**.

### Kim chỉ nam 2 — GIÁ TRỊ CỐT LÕI
Thứ khiến người ta hiểu bạn và quyết định đồng hành (vì "đúng thứ họ cần"). Xây niềm tin → củng cố hành vi → tăng gắn kết → hình thành văn hoá. Các loại giá trị một cộng đồng nên có: học hỏi/chuyên môn/kinh nghiệm, chia sẻ chân thành & hỗ trợ, minh bạch/khách quan, hỗ trợ cảm xúc–tinh thần, mở rộng network, được thể hiện bản thân, cơ hội kiếm thêm tài chính. **Chọn 2–3 (hoặc hơn) phù hợp thế mạnh mình — không cần chọn hết.**
**3 bước tìm giá trị:** (1) Thế mạnh của mình là gì? (đối chiếu cộng đồng khác, tìm điểm mình "trội" hơn) → (2) Member mục tiêu đang tìm gì? (khảo sát trực tiếp, research, đọc insight từ comment/tương tác) → (3) Làm gì để giá trị mình thực sự hữu ích với thứ họ cần?

### Kim chỉ nam 3 — NIỀM TIN CỐT LÕI
Khiến member tin cộng đồng đáp ứng điều họ cần ở **mức cao hơn hẳn**. Lưu ý: niềm tin **bắt buộc phải được chứng minh bằng hành động** theo đúng sứ mệnh, giá trị cốt lõi và mục tiêu đã tuyên bố.

### Kim chỉ nam 4 — VĂN HOÁ CỘNG ĐỒNG
Quy tắc chung: xưng hô, cách bàn vấn đề, văn phong, con người… quan trọng nhất là được thành viên tiếp nhận & thấy phù hợp.
**4 bước hình thành văn hoá:** (1) xác định rõ cá tính BQT + tệp người dùng → (2) tìm điểm giao thoa để ra cách tiếp cận hiệu quả → (3) thúc đẩy mạnh, đều, thường xuyên để tạo thói quen giai đoạn đầu → (4) hành động nhất quán và duy trì có kế hoạch.

## 3. Thứ tự triển khai
Xác định 4 kim chỉ nam → cài đặt nhóm Facebook (mô tả, quy tắc, câu hỏi duyệt thành viên bám giá trị/văn hoá) → seeding nội dung theo giá trị cốt lõi → duy trì tương tác đều để nuôi văn hoá & niềm tin.

## 4. Kết nối
- Đo sức khoẻ cộng đồng: brandformance-community-report.
- Kế hoạch seeding nội dung: brandformance-seeding-plan.
- Chuyển member thành khách: brandformance-lead-conversion.
