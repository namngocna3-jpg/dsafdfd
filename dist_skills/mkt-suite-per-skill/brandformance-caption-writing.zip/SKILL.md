---
name: brandformance-caption-writing
description: >
  Viết caption theo từng platform (Facebook, Instagram, TikTok) và mục tiêu funnel. Kích hoạt khi: "viết caption", "caption writing", "caption cho bài đăng", "viết nội dung post", "caption Facebook", "caption Instagram", "caption TikTok", "viết bài đăng".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: content</summary>

# brandformance-content

> Kiến thức về hệ thống nội dung Brandformance — đọc trước khi chạy bất kỳ skill content hoặc community.

## I. 4 Content Pillar theo mục đích phễu

Pillar 1: Nhận diện & Thu hút (TOFU) — không đề cập sản phẩm trực tiếp
Pillar 2: Giáo dục & Tin tưởng (MOFU) — đề cập sản phẩm gián tiếp
Pillar 3: Chuyển đổi (BOFU) — CTA rõ, offer cụ thể
Pillar 4: Giữ chân & Referral — nuôi dưỡng KH cũ

## II. Trục nội dung

Công thức: Trục nội dung = Mục tiêu truyền thông × Vấn đề KH × Thế mạnh thương hiệu

## III. Nguồn sản xuất content

FGC (Founder Generated Content) — lợi thế SME lớn nhất
BGC (Brand Generated Content) — kênh brand chính thức
EGC (Employee Generated Content) — nhân sự nội bộ
UGC (User Generated Content) — KH thật tạo content
KOC/KOL — người review trả phí

## IV. Ma trận content theo 3 tầng phễu

TOFU: Brand 80% / Perf 20% — CPM, View Rate
MOFU: Brand 50% / Perf 50% — CTR, CPL
BOFU: Brand 30% / Perf 70% — CPA, Conversion Rate

## V. Hook → Lead Magnet → Offer

Hook: thu hút attention (mọi giai đoạn)
Lead Magnet: đổi info lấy tài nguyên giá trị
Offer: gói SP/DV kèm giá trị, giảm rào cản ra quyết định
Chuỗi: Hook → LM → Thank-you page → Email/Zalo nurture → Core Offer → Retarget

## VI. Target bằng content

Target rộng + content nói đúng vấn đề cụ thể = content gạn lọc người phù hợp.
Bỏ target sâu theo hành vi/sở thích truyền thống (ngày càng sai lệch, đắt).

## VII. Content Funnel đa kênh

Facebook/Instagram: Reach + Conversion
TikTok: TOFU, viral, khám phá
Zalo OA: Nurture, retention — 2 loại tin khác nhau: **Broadcast** (quảng cáo, cần follower đồng ý, giới hạn 2-3 lần/tuần để tránh giảm follow rate) và **ZNS** (Zalo Notification Service — giao dịch/xác nhận đơn/lịch hẹn, không phải quảng cáo, độ tin cậy cao hơn). Nội dung phải ngắn, trực tiếp hơn Email vì thói quen kiểm tra Zalo nhiều lần/ngày.
Email: Nurture sequence, conversion — phù hợp nội dung sâu, case study dài mà Zalo không phù hợp.
Group/Forum: Seeding, social proof
Kênh Founder: Trust building, FGC

## VIII. Community — kênh Retention/Referral

Community không phải kênh acquisition, đừng đo bằng lead ngay. 3 loại theo tầng phễu:
- **TOFU (Open)**: giáo dục, growth-focused — đo bằng reach/growth, không kỳ vọng chuyển đổi cao
- **MOFU (Semi-closed)**: Q&A, poll — đo bằng tỉ lệ tham gia + chuyển đổi nhẹ sang lead
- **BOFU (Closed, chỉ KH đã mua)**: đo bằng tỉ lệ tham gia hoạt động + referral phát sinh + repeat purchase

Quy tắc nội dung trong community: 80% giá trị thật / 20% soft mention sản phẩm — vi phạm tỉ lệ này, community sẽ giống spam và mất tương tác thật.

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Caption Writing

## 1. Triggers
- "viết caption", "caption Facebook/Instagram", "bài đăng viết gì?"
- User paste ảnh/video → cần caption; Caption cũ reach thấp

## 2. Context Requirements
- [ ] **[BẮT BUỘC]** Nội dung muốn truyền tải
- [ ] **[BẮT BUỘC]** Tầng phễu (TOFU/MOFU/BOFU)
- [ ] **[BẮT BUỘC]** Platform (Facebook/Instagram/LinkedIn)
- [ ] **[NẾU CÓ]** Brand Voice, KPI mục tiêu

## 3. Execution Steps

### Bước 1: Cấu trúc caption theo tầng

**TOFU Structure:**
```
[Hook — dòng 1-2: Pain/Curiosity/Contradiction]
[Setup — mở rộng hook]
[Value/Insight — cung cấp giá trị thật]
[Soft close — gợi mở, không bán hàng]
[CTA: Follow/Save/Comment keyword]
```

**MOFU Structure:**
```
[Hook từ kết quả/social proof]
[Story: Tình huống → Giải pháp → Kết quả]
[Proof: Số liệu, quote, screenshot]
[Bridge: "Nếu bạn cũng đang gặp X..."]
[CTA: Inbox / Link / Tag bạn bè]
```

**BOFU Structure:**
```
[Reminder pain point]
[Offer cụ thể rõ ràng]
[Urgency thật]
[Risk reversal / Guarantee]
[CTA đơn giản và rõ]
```

### Bước 2: Hook đầu dòng
Facebook: Phải kết thúc bằng "..." để truncate đúng chỗ → khuyến khích "Xem thêm".
Không dùng: "Chào mọi người!", "Hôm nay mình muốn chia sẻ".
Instagram: 2 dòng đầu phải đủ hấp dẫn (rest bị truncate).

### Bước 3: Body theo Brand Voice
- Đoạn 2-3 câu, không viết block dài
- Ký tự xuống dòng đơn giữa đoạn

### Bước 4: CTA theo objective
- Reach: "Save bài này" / "Tag người bạn cần đọc"
- Engagement: "Comment [keyword] để nhận [X]"
- Lead: "Inbox mình" / "Link đăng ký ở bio"
- Sale: "[Action] trước [deadline cụ thể]"

### Bước 5: Review checklist
- [ ] Hook dòng đầu đủ mạnh?
- [ ] Đúng tầng (TOFU không mention sản phẩm)?
- [ ] Brand Voice nhất quán?
- [ ] CTA phù hợp objective?

## 4. Examples

### Example 1 — TOFU Facebook: Spa làm đẹp
```
"Tại sao da vẫn mụn dù đã skincare đủ bước?

Vấn đề thường không phải thiếu sản phẩm — mà dùng sai thứ tự.

Một số enzym trong serum bị vô hiệu hóa khi tiếp xúc với acid trong toner.
Kết quả: Skincare tốn tiền nhưng hiệu quả giảm 40-60%.

Thứ tự đúng phụ thuộc vào pH từng sản phẩm — không phải cứ thoa là được.

Bạn đang dùng bao nhiêu bước skincare? Comment bên dưới 👇"

[NOTES: Ảnh flat lay skincare; Không mention spa; Không CTA inbox]
```

### Example 2 — MOFU Facebook: Khóa học Excel
```
"Anh Minh từng mất 4 tiếng mỗi tuần compile báo cáo bằng tay...

Sau khi học Excel nâng cao, anh làm xong trong 15 phút.

Không phải vì làm nhanh hơn — mà biết cách tạo dashboard tự động cập nhật từ data gốc.

Kỹ năng này không cần background kỹ thuật. Cần 6 tiếng học đúng cách.

Nếu bạn đang làm báo cáo mỗi tuần, inbox mình — sẽ gửi checklist 5 formula tiết kiệm thời gian nhất."
```

## 5. Edge Cases & Error Handling

**Case 1: Muốn viết "vui vẻ" nhưng tầng BOFU**
→ BOFU cần clear hơn vui vẻ. Giữ tone brand nhưng phải clear về offer + CTA.

**Case 2: Caption quá dài**
→ Facebook TOFU: 500-800 ký tự OK; Instagram: 150 chars visible.
→ Cắt body, giữ hook và CTA.

**Case 3: Không biết tầng phễu**
→ Hỏi: "Bài này nhắm vào ai — chưa biết brand, đang cân nhắc, hay sắp mua?"

## 6. State Management

| State | Claude làm gì |
|---|---|
| `STRUCTURE_SELECT` | Chọn cấu trúc theo tầng |
| `HOOK_WRITING` | Viết hook đầu dòng |
| `BODY_WRITING` | Viết body theo Brand Voice |
| `CTA_WRITING` | Viết CTA |
| `REVIEW` | Checklist review |
| `DONE` | Deliver inline |

## References
- `brandformance-content.md` → Phần IV (Caption framework)
- `brandformance-brand-bible.md` → Voice Matrix, Từ điển thương hiệu

Caption tốt: Đọc hook — tò mò không? Nếu không → viết lại hook
