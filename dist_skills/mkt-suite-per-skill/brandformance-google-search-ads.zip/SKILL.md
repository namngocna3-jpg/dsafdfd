---
name: brandformance-google-search-ads
description: "Kích hoạt khi cần thiết lập Google Search Ads — logic khác hẳn Meta/TikTok vì bắt Intent có sẵn qua từ khóa thay vì audience interruption. Trigger: 'Google Ads', 'quảng cáo tìm kiếm', 'Google Search Ads', 'SEM', 'chạy Google Ads', 'từ khóa quảng cáo'. Kích hoạt cả khi đang chỉ chạy Meta/TikTok và muốn mở thêm kênh bắt intent tìm kiếm."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: ads</summary>

# brandformance-ads

> Kiến thức về hệ thống Performance Ads trong Brandformance — đọc trước khi chạy bất kỳ skill ads.

## I. Khi nào nên chạy Ads

Ads là bước cuối cùng, không phải khởi đầu. Chỉ chạy khi: SP rõ + biết bán cho ai + có content đúng insight + có nơi để KH đi tiếp.

## II. Cấu trúc Campaign Meta Ads

Campaign (1 mục tiêu) → Ad Set (1 audience + 1 ngân sách) → Ad (1 creative)
Mỗi cấp chỉ có 1 biến để test. Không trộn mục tiêu trong cùng Campaign.

## III. Giai đoạn 1 — Testing

Mục tiêu: tìm content + audience work. Không tối ưu chi phí ở giai đoạn này.
Cấu trúc: 1 Campaign → 2-3 Ad Set → 2-3 Ads/Ad Set = 4-9 ads tổng.
Ngân sách: 100-300K/ngày/Ad Set. Tối thiểu 3-5 ngày. ~1-2 triệu để có data.
A/B Testing: thay 1 yếu tố/lần. Không đánh giá trước 3 ngày. Không sửa ad đang chạy ổn.

## IV. Giai đoạn 2 — Đo lường & Tối ưu

Vào sau khi Ads chạy ≥3 ngày, mỗi Ad Set ≥1.000 impressions.
Tắt: CTR < 0.8% sau 3 ngày không có lead.
Gom ngân sách về top performers.
Nhân bản Ads tốt sang audience khác.

## V. Giai đoạn 3 — Scale Up

Điều kiện scale: CTR > 2% + CPL ổn định 5-7 ngày + tỉ lệ chốt > 20%.
Scale dọc: tăng ngân sách ≤20-30%/lần, cách 2-3 ngày.
Scale ngang: nhân bản sang audience mới hoặc content mới.
Retarget: xem video >3s / nhắn tin chưa chốt / vào landing chưa để lại thông tin.

## VI. Ngưỡng chỉ số tham chiếu

CTR tốt: > 2% / Cần xem lại: < 0.8%
Frequency tốt: < 3 / Cần xem lại: > 3 trong 7 ngày
Tỉ lệ chốt tốt: > 20% / Cần xem lại: < 10%

Creative lifespan: audience nhỏ + ngân sách cao → mệt nhanh (1-2 tuần); audience lớn + ngân sách vừa → 4-6 tuần. Nên có creative mới sẵn sàng TRƯỚC khi frequency chạm ngưỡng 3.

## VII. Content Brandformance trong Ads

Mỗi ads = "2 trong 1": Branding (cảm xúc, câu chuyện) + Performance (CTA rõ, trigger hành động).
Mỗi tầng gắn Content Pillar chính + Angle cụ thể để dễ nhân bản theo tuần/tháng.

## VIII. Tracking & Attribution

Bắt buộc: Pixel + Conversion API chạy song song. Chỉ dùng Pixel (browser-side) không còn đủ tin cậy từ iOS 14.5+ và ad blocker — có thể mất 15-30% data thực tế. Conversion API (server-side) bù đắp phần mất.

Event Match Quality (EMQ) — tăng bằng cách gửi kèm email/SĐT đã hash trong sự kiện. EMQ thấp làm giảm hiệu quả tối ưu của thuật toán Meta dù creative/audience đúng.

UTM chuẩn hóa theo cấu trúc cố định (source/medium/campaign/content) cho mọi campaign để so sánh được qua thời gian.

## IX. Ngoài Meta — Google Search Ads

Meta/TikTok = Interruption — chen vào feed người chưa chủ động tìm kiếm, cần Hook mạnh để dừng scroll.
Google Search = Intent Capture — người dùng đã chủ động gõ từ khóa, không cần hook, cần đúng lúc đúng chỗ.

Chỉ chạy ads cho từ khóa Commercial investigation/Transactional. Không chạy cho Informational — dùng SEO/content thay thế.

Quality Score (ảnh hưởng CPC) phụ thuộc vào mức khớp giữa Từ khóa → Ad → Landing page.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Google Search Ads

## 1. Triggers

### Explicit triggers
- "chạy Google Ads", "quảng cáo tìm kiếm Google", "SEM"
- "từ khóa nào nên chạy ads?"

### Implicit triggers
- Đang chỉ chạy Meta/TikTok, muốn mở thêm kênh bắt người đang chủ động tìm kiếm giải pháp
- KH thường tìm kiếm trên Google trước khi quyết định (sản phẩm/dịch vụ giá cao, cần nghiên cứu)
- Đối thủ đang xuất hiện đầu trang tìm kiếm cho từ khóa liên quan đến brand

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Sản phẩm/dịch vụ và ngành hàng cụ thể
- [ ] **[BẮT BUỘC]** Ngân sách dành riêng cho Google Ads
- [ ] **[NẾU CÓ]** Đối thủ đang chạy Google Ads cho từ khóa nào

## 3. Execution Steps

### Bước 1: Phân biệt logic Google Search với Meta/TikTok
Meta/TikTok = Interruption — chen vào feed người chưa chủ động tìm kiếm, cần Hook mạnh để dừng scroll.
Google Search = Intent Capture — người dùng ĐÃ chủ động gõ từ khóa, không cần hook, cần đúng lúc đúng chỗ.

### Bước 2: Keyword research theo loại Intent
- **Informational** ("là gì", "cách làm") → KHÔNG chạy ads, dùng SEO content
- **Commercial investigation** ("tốt nhất", "so sánh", "review") → Chạy ads, hướng vào trust/so sánh
- **Transactional** ("giá", "mua", "đặt lịch", "gần đây") → Ưu tiên ngân sách cao nhất

### Bước 3: Cấu trúc Campaign → Ad Group → Ads
```
Campaign (1 mục tiêu, VD: Search - Dịch vụ chính)
 └─ Ad Group A (cụm từ khóa liên quan chặt: "sửa điều hòa quận 1", "sửa điều hòa tại nhà")
 └─ Responsive Search Ads (nhiều headline/description để Google tự tối ưu tổ hợp)
 └─ Ad Group B (cụm từ khóa khác: "bảo trì điều hòa định kỳ")
```
Mỗi Ad Group chỉ chứa từ khóa cùng chủ đề — không trộn để Quality Score không bị pha loãng.

### Bước 4: Negative keywords
Loại các từ khóa không liên quan: "miễn phí", "tuyển dụng", "học nghề" (nếu không phải mục tiêu).

### Bước 5: Landing page phải match chính xác Intent từ khóa
Quality Score phụ thuộc mạnh vào mức độ liên quan giữa từ khóa → ad → landing page.

### Bước 6: Build Media Plan riêng cho Google Ads
Google Search thường đặt ở vai trò BOFU/Convert do bắt Intent cao.

## 4. Examples

### Example 1 — Dịch vụ sửa điều hòa tại nhà (5 triệu/tháng)
```
AD GROUP 1 — Transactional (60% ngân sách): "sửa điều hòa tại nhà quận 1", "thợ sửa điều hòa gần đây"
Headline: "Sửa Điều Hòa Tại Nhà - Có Mặt Trong 30 Phút" | "Bảo Hành 6 Tháng - Giá Niêm Yết"

AD GROUP 2 — Commercial (40%): "dịch vụ sửa điều hòa uy tín", "sửa điều hòa giá bao nhiêu"
Headline: "200+ Đánh Giá 5 Sao" | "Báo Giá Trước Khi Sửa - Không Phát Sinh"

NEGATIVE KEYWORDS: "học sửa điều hòa", "tuyển thợ điều hòa", "điều hòa cũ giá rẻ"
```

### Example 2 — Khóa học IELTS online
```
AD GROUP 1 — Transactional: "học IELTS online giá bao nhiêu", "đăng ký khóa IELTS online"
Headline: "Cam Kết Đầu Ra 6.5 - Học Phí Từ 2 Triệu" | "Học Thử Miễn Phí Trước Khi Đăng Ký"

KHÔNG chạy ads cho "IELTS là gì", "cách tự học IELTS" — đây là Informational, nên đầu tư SEO blog.
```

## 5. Edge Cases & Error Handling

**Từ khóa cạnh tranh cao khiến CPC quá đắt**: Ưu tiên long-tail keyword cụ thể hơn.
**Quality Score thấp làm CPC cao dù bid thấp**: Landing page không match — quay lại Bước 5.
**Search volume quá nhỏ với ngành ngách**: Google Ads không phù hợp làm kênh chính.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `INTENT_ANALYSIS` | Phân loại từ khóa theo Intent |
| `STRUCTURE_BUILD` | Xây cấu trúc Campaign/Ad Group |
| `NEGATIVE_KEYWORDS` | Xác định từ khóa loại trừ |
| `LANDING_MATCH` | Đảm bảo landing page match Intent |
| `MEDIA_PLAN` | Tích hợp vào Media Plan tổng |
| `DONE` | Google Search Ads Plan hoàn chỉnh |

## References
- `brandformance-channel-strategy.md` → Vai trò Google Search trong tổng thể kênh
- `brandformance-media-plan.md` → Tích hợp ngân sách
- `brandformance-ads-tracking-setup.md` → Conversion tracking cho Google Ads
