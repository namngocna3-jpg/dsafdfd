---
name: brandformance-pushback
description: "Kích hoạt khi cần phản biện hoặc kiểm tra độ logic của kế hoạch Brandformance — challenge giả định yếu, kiểm tra tỉ lệ Brand/Performance theo từng tầng phễu, validate KPI mapping và ngân sách. Trigger: 'review kế hoạch', 'kế hoạch có ổn không', 'phản biện plan', 'challenge chiến lược', 'điểm yếu của kế hoạch này', 'kiểm tra plan trước khi chạy', 'plan này có vấn đề gì không', 'phân tích rủi ro chiến dịch'. Kích hoạt cả khi user vừa chia sẻ một kế hoạch marketing và cần đánh giá khách quan trước khi triển khai."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: content</summary>

# brandformance-content

> Kiến thức về hệ thống nội dung Brandformance — đọc trước khi chạy bất kỳ skill content hoặc community.

## I. 4 Content Pillar theo mục đích phễu

Pillar 1: Nhận diện & Thu hút (TOFU) — không đề cập sản phẩm trực tiếp
Pillar 2: Giáo dục & Tin tưởng (MOFU) — đề cập sản phẩm gián tiếp
Pillar 3: Chuyển đổi (BOFU) — CTA rõ, offer cụ thể
Pillar 4: Giữ chân & Referral — nuôi dưỡng KH cũ

## II. Trục nội dung

Công thức: Trục nội dung = Mục tiêu truyền thông × Vấn đề KH × Thế mạnh thương hiệu

## III. Nguồn sản xuất content

FGC (Founder Generated Content) — lợi thế SME lớn nhất
BGC (Brand Generated Content) — kênh brand chính thức
EGC (Employee Generated Content) — nhân sự nội bộ
UGC (User Generated Content) — KH thật tạo content
KOC/KOL — người review trả phí

## IV. Ma trận content theo 3 tầng phễu

TOFU: Brand 80% / Perf 20% — CPM, View Rate
MOFU: Brand 50% / Perf 50% — CTR, CPL
BOFU: Brand 30% / Perf 70% — CPA, Conversion Rate

## V. Hook → Lead Magnet → Offer

Hook: thu hút attention (mọi giai đoạn)
Lead Magnet: đổi info lấy tài nguyên giá trị
Offer: gói SP/DV kèm giá trị, giảm rào cản ra quyết định
Chuỗi: Hook → LM → Thank-you page → Email/Zalo nurture → Core Offer → Retarget

## VI. Target bằng content

Target rộng + content nói đúng vấn đề cụ thể = content gạn lọc người phù hợp.
Bỏ target sâu theo hành vi/sở thích truyền thống (ngày càng sai lệch, đắt).

## VII. Content Funnel đa kênh

Facebook/Instagram: Reach + Conversion
TikTok: TOFU, viral, khám phá
Zalo OA: Nurture, retention — 2 loại tin khác nhau: **Broadcast** (quảng cáo, cần follower đồng ý, giới hạn 2-3 lần/tuần để tránh giảm follow rate) và **ZNS** (Zalo Notification Service — giao dịch/xác nhận đơn/lịch hẹn, không phải quảng cáo, độ tin cậy cao hơn). Nội dung phải ngắn, trực tiếp hơn Email vì thói quen kiểm tra Zalo nhiều lần/ngày.
Email: Nurture sequence, conversion — phù hợp nội dung sâu, case study dài mà Zalo không phù hợp.
Group/Forum: Seeding, social proof
Kênh Founder: Trust building, FGC

## VIII. Community — kênh Retention/Referral

Community không phải kênh acquisition, đừng đo bằng lead ngay. 3 loại theo tầng phễu:
- **TOFU (Open)**: giáo dục, growth-focused — đo bằng reach/growth, không kỳ vọng chuyển đổi cao
- **MOFU (Semi-closed)**: Q&A, poll — đo bằng tỉ lệ tham gia + chuyển đổi nhẹ sang lead
- **BOFU (Closed, chỉ KH đã mua)**: đo bằng tỉ lệ tham gia hoạt động + referral phát sinh + repeat purchase

Quy tắc nội dung trong community: 80% giá trị thật / 20% soft mention sản phẩm — vi phạm tỉ lệ này, community sẽ giống spam và mất tương tác thật.

</details>

---

# Brandformance Pushback

## 1. Triggers

### Explicit triggers
- Người dùng hỏi: "kế hoạch này có ổn không?", "plan có vấn đề gì không?", "review plan giúp tôi"
- Người dùng yêu cầu: "phản biện kế hoạch", "challenge plan này", "điểm yếu là gì?"
- Người dùng cần: "kiểm tra trước khi chạy", "đánh giá rủi ro", "plan này có logic không?"

### Implicit triggers
- Người dùng vừa chia sẻ một kế hoạch marketing/campaign và dừng lại → đang chờ feedback
- Kế hoạch chỉ có BOFU (bán hàng) mà thiếu hoàn toàn giai đoạn Awareness
- Ngân sách kế hoạch không khả thi so với mục tiêu doanh thu
- KPI được đặt ra không có cơ sở (ví dụ: "target 1000 lead/tháng" nhưng không có gì để support)

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Kế hoạch/chiến lược cụ thể cần được phản biện
- [ ] **[BẮT BUỘC]** Mục tiêu doanh thu/KPI cuối cùng cần đạt
- [ ] **[NẾU CÓ]** Ngân sách marketing tổng hoặc ước tính
- [ ] **[NẾU CÓ]** Data lịch sử: CPL, ROAS, tỉ lệ chốt của các campaign trước
- [ ] **[NẾU CÓ]** Thời gian thực hiện kế hoạch

Đọc trước khi thực hiện:
- `brandformance-framework.md` → Phần III (Phễu 4 giai đoạn + tỉ lệ Brand/Performance), Phần VII (Điểm nghẽn phổ biến)
- `brandformance-measurement.md` → Phần II (Mapping ngược từ doanh thu), Phần V (Bảng điểm nghẽn)

## 3. Execution Steps

### Bước 1: Đọc và hiểu kế hoạch tổng thể
1.1 Đọc toàn bộ kế hoạch trước khi nhận xét bất kỳ điểm nào.
1.2 Xác định: Kế hoạch đang ở giai đoạn nào? (Campaign mới / Đang chạy / Chuẩn bị scale)
1.3 Xác định: Mục tiêu cuối cùng là gì? (Doanh thu / Lead / Brand awareness)
1.4 Map kế hoạch vào mô hình phễu 4 giai đoạn Brandformance — xem giai đoạn nào bị bỏ qua.

### Bước 2: Chạy checklist 8 điểm Brandformance

**Câu 1 — Phễu đầy đủ chưa?**
- Kế hoạch có đủ 4 giai đoạn: Awareness → Activation → Conversion → Retention không?
- Hay chỉ tập trung vào BOFU mà bỏ qua TOFU/MOFU?
- Triệu chứng cảnh báo: 100% ngân sách cho ads bán hàng, không có content xây brand

**Câu 2 — Tỉ lệ Brand/Performance có đúng theo tầng phễu không?**
- GĐ1 (Awareness): Brand 70% / Performance 30%
- GĐ2 (Activation): Brand 50% / Performance 50%
- GĐ3 (Conversion): Brand 30% / Performance 70%
- GĐ4 (Retention): Brand 60% / Performance 40%

**Câu 3 — KPI mapping có logic từ doanh thu ngược lên không?**
- Từ mục tiêu doanh thu → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người
- Tất cả con số có nhất quán không?

**Câu 4 — Ngân sách có đủ để test + optimize không?**
- Với ngân sách này, có đủ để chạy giai đoạn Testing không?
- Tỉ lệ ngân sách test/scale có hợp lý không (thường: 30% test, 70% scale winner)?

**Câu 5 — Phân vai có rõ ràng không?**
- Ai chịu trách nhiệm từng phần? (Content, Ads, Sale, Chốt đơn)
- Nếu ads không ra lead, ai quyết định thay creative và trong bao lâu?

**Câu 6 — Campaign Memory từ lần trước được dùng không?**
- Kế hoạch có tham chiếu insight/data từ campaign trước không?
- Đây là lần đầu chạy thì có benchmark ngành để so sánh không?

**Câu 7 — Bypass Lead có được tracking không?**
- Có 20-30% KH đến qua kênh ngoài funnel chính (giới thiệu, Zalo cá nhân, Google)?
- Có form thu thập "bạn biết đến chúng tôi qua đâu?" không?

**Câu 8 — Điểm nghẽn dự kiến ở đâu trong phễu?**
- Giai đoạn nào có khả năng gãy nhất?
- Có phương án dự phòng nếu CTR thấp hơn kỳ vọng?
- Threshold để dừng/thay đổi hướng là gì?

### Bước 3: Phân loại vấn đề tìm được

| Ký hiệu | Mức độ | Ý nghĩa |
|---|---|---|
| 🔴 CRITICAL | Phải fix ngay trước khi chạy | Kế hoạch sẽ thất bại nếu không sửa |
| ⚠️ WARNING | Nên fix, có thể làm ngay | Ảnh hưởng đáng kể đến hiệu quả |
| 💡 SUGGESTION | Đề xuất tối ưu | Cải thiện dài hạn |
| ✅ GOOD | Điểm mạnh | Ghi nhận để nhân bản |

Với mỗi 🔴 CRITICAL: bắt buộc giải thích tại sao critical và gợi ý fix cụ thể.
Không liệt kê nhiều hơn 3-5 điểm CRITICAL — chọn những điểm ảnh hưởng nhất.

### Bước 4: Nhận định tổng thể và đề xuất
4.1 Tóm tắt: "Kế hoạch này ở mức [X/10] về độ hoàn chỉnh Brandformance. Điểm mạnh nhất là [X]. Rủi ro lớn nhất là [Y]."
4.2 Ưu tiên hành động: Nếu phải fix 1 điều trước khi chạy, đó là điều gì?
4.3 Nếu kế hoạch có quá nhiều vấn đề nghiêm trọng → gợi ý cấu trúc lại thay vì patch từng điểm nhỏ.
4.4 Kết thúc bằng: "Bạn muốn tôi giúp fix phần [X] ngay không?"

## 4. Edge Cases & Error Handling

**Case 1: Kế hoạch quá sơ sài, thiếu thông tin để phân tích**
→ Hỏi tối thiểu: Mục tiêu KPI là gì? Ngân sách tổng? Đã có data từ campaign trước chưa?

**Case 2: User chỉ muốn confirm "plan ổn", không muốn nghe phản biện**
→ Vẫn phải đưa ra nhận xét trung thực — đây là mục đích của skill.
→ Đóng gói: "Plan có điểm mạnh [X], nhưng có [Y] cần chú ý để không lãng phí ngân sách."

**Case 3: Kế hoạch thực sự tốt (ít vấn đề)**
→ Xác nhận điểm mạnh, ghi điểm (7-8/10).
→ Vẫn đề xuất 1-2 điểm tối ưu thêm. Không tạo vấn đề giả tạo.

**Case 4: Phản biện kế hoạch đang triển khai (không phải kế hoạch mới)**
→ Focus vào "điều chỉnh ngay" thay vì "nên làm từ đầu".
→ Không nhắc những gì đã qua không thể thay đổi.

## References

- `brandformance-framework.md` → Phần III (Tỉ lệ Brand/Performance), Phần VII (Điểm nghẽn phổ biến)
- `brandformance-measurement.md` → Phần II (Mapping ngược từ doanh thu)

Scoring rubric (Brand/Performance ratio chuẩn):

| Giai đoạn | Brand % chuẩn | Perf % chuẩn | Cảnh báo nếu |
|---|---|---|---|
| GĐ1 Awareness | 70% | 30% | Perf > 60% → thiếu brand warming |
| GĐ2 Activation | 50% | 50% | Brand < 30% → thiếu nurture |
| GĐ3 Conversion | 30% | 70% | Perf < 50% → CTA quá yếu |
| GĐ4 Retention | 60% | 40% | Không có plan GĐ4 → mất KH cũ |
