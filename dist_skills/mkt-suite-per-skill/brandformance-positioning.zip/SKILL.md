---
name: brandformance-positioning
description: "Kích hoạt khi cần xây dựng định vị thương hiệu theo tư duy Brandformance — câu định vị, offer ladder theo phễu, brand personality direction. Trigger: 'định vị thương hiệu', 'positioning', 'khác biệt hóa', 'USP', 'tôi khác đối thủ ở điểm nào', 'câu định vị', 'brand statement', 'tôi nên nói về mình như thế nào', 'tôi nên nhắm vào góc gì'. Kích hoạt cả khi brand đang bị nhận xét là 'trông như đối thủ', hoặc khi KH không nhớ brand là gì sau khi đã tương tác."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Positioning

## 1. Triggers

### Explicit triggers
- "định vị thương hiệu", "xây dựng positioning"
- "USP của tôi là gì?", "tôi khác đối thủ ở điểm nào?"
- "câu định vị", "brand statement", "tôi nên nhắm vào góc gì?"

### Implicit triggers
- KH không nhớ brand là gì sau khi tương tác → chưa có positioning rõ ràng
- Brand đang trông giống đối thủ → không có điểm khác biệt
- Team không biết nên nói về brand như thế nào
- Đang chuẩn bị Brand Bible nhưng chưa có positioning foundation
- Vừa hoàn thành Competitor Map → bước tiếp theo tự nhiên là Positioning

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Sản phẩm/dịch vụ và vấn đề cụ thể nó giải quyết
- [ ] **[BẮT BUỘC]** Target audience chính (từ Customer Insight nếu đã có)
- [ ] **[BẮT BUỘC]** Khoảng trống cạnh tranh (từ Competitor Map hoặc mô tả ngắn gọn)
- [ ] **[NẾU CÓ]** Điểm mạnh thực sự và bền vững của brand (không phải "chất lượng tốt")
- [ ] **[NẾU CÓ]** Bằng chứng cụ thể (case study, số liệu, thành tích)

Đọc trước khi thực hiện:
- `brandformance-framework.md` → Phần II (Bản chất Brandformance)
- `brandformance-customer.md` → Phần IV (3 nhóm KH)
- Kết quả từ `brandformance-competitor-map` nếu đã có
- `references/branding-marketing-sale-phungsu.md` → khi cần chiều sâu định vị theo triết lý "Phụng Sự" (Brand DNA qua IKIGAI + Stoicism, 12 hình mẫu Jung, bản sắc đa giác quan)

## 3. Execution Steps

### Bước 1: Xác định nền tảng positioning
1.1 Xác định "Core Truth": Điều gì là thật và duy nhất về brand này?
- Không phải "chúng tôi chất lượng tốt" — không phải differentiator
- Phải là: "Chúng tôi làm X theo cách mà không ai khác làm vì [lý do cụ thể]"
1.2 Kiểm tra tính bền vững: Điểm khác biệt này đối thủ có copy được dễ không?
- Dễ copy: Giá rẻ hơn / Nhanh hơn / Thêm tính năng
- Khó copy: Cách tiếp cận / Triết lý / Mối quan hệ với KH / Câu chuyện founder
1.3 Positioning tốt nên nói không với một số người để nói có với đúng người.

### Bước 2: Xây dựng Positioning Statement
Format chuẩn:
> "[Brand] là [loại hình] duy nhất giúp [target audience CỤ THỂ] [kết quả ĐO ĐƯỢC] bằng cách [phương pháp KHÁC BIỆT]."

2.1 Điền vào từng phần:
- [loại hình]: Cụ thể hơn ngành chung chung
- [target audience CỤ THỂ]: Không phải "SME" — phải là "chủ SME dịch vụ 5-30 nhân viên đang muốn scale mà không tăng headcount"
- [kết quả ĐO ĐƯỢC]: Không phải "thành công hơn" — phải là "tăng 30% lead qualified trong 90 ngày"
- [phương pháp KHÁC BIỆT]: Không phải "giải pháp toàn diện" — phải là cách tiếp cận cụ thể của brand

2.2 Kiểm tra:
- Nếu thay tên brand bằng đối thủ, câu này vẫn đúng không? → Nếu đúng = chưa differentiated
- Có người đọc nói "đây là dành cho tôi" không? → Phải có
- Có người đọc nói "không phải dành cho tôi" không? → Phải có — dấu hiệu positioning tốt

### Bước 3: Xây Offer Ladder theo tầng phễu

3.1 **TOFU Offer — Hook/Lead Magnet**
- Offer miễn phí hoặc rất thấp để KH lạnh bước vào phễu
- Phải phản ánh positioning: Positioning "thực chiến" → TOFU offer phải là checklist/tool thực chiến
- Format: Checklist / Template / Free tool / Webinar / Mini-course / Audit miễn phí

3.2 **MOFU Offer — Tripwire/Low Commitment**
- Offer giá thấp hoặc free trial để KH ấm trải nghiệm giá trị
- Mục tiêu: "tin về lý thuyết" → "đã trải nghiệm và tin về thực tế"

3.3 **BOFU Offer — Core Product**
- Sản phẩm/dịch vụ chính
- Positioning thể hiện rõ nhất qua package, deliverables, và cam kết cụ thể

3.4 **Retention Offer — Upsell/Renewal**
- Consistent với positioning: Positioning "đồng hành dài hạn" → phải có offer support/community/renewal

### Bước 4: Xây Brand Personality Direction
4.1 Positioning phải thể hiện nhất quán trong personality:
- Positioning "thực chiến, thẳng thắn" → personality direct, không hoa mỹ
- Positioning "dễ tiếp cận, đồng hành" → personality conversational, không distant

4.2 3 Positioning Pillars — 3 thông điệp cốt lõi mọi content reinforce:
- Pillar 1: [Điều brand giỏi nhất]
- Pillar 2: [Cách brand khác với mọi người]
- Pillar 3: [Kết quả brand tạo ra cho KH]

4.3 Brand Manifesto — đoạn văn 3-5 câu mô tả brand tin vào điều gì, tại sao tồn tại.

### Bước 5: Stress test và finalize
5.1 "Nếu brand này biến mất, ai sẽ thực sự miss và vì sao?" → Câu trả lời = core positioning
5.2 Confirm với user: "Positioning này có phản ánh đúng brand không?"
5.3 Đề xuất: "Dùng positioning này làm nền tảng cho brandformance-brand-bible."

## 4. Edge Cases & Error Handling

**Case 1: Brand không có điểm khác biệt thật sự**
→ Thường khác biệt nằm ở CÁCH làm, không phải CÁI làm.
→ Hỏi: "Kể 1-2 câu chuyện về KH mà bạn đã làm khác đi so với đối thủ."

**Case 2: Founder muốn nhắm tất cả mọi người**
→ Flag: "Positioning dành cho tất cả = không có positioning."
→ "Hẹp ban đầu, mở rộng sau. Dominate 1 phân khúc nhỏ trước."

**Case 3: Positioning tốt nhưng claim không có bằng chứng**
→ Flag: "Cần bằng chứng để credible. Bạn có [số liệu / case study] gì để backup không?"

**Case 4: Có lịch sử positioning cũ muốn đổi**
→ Thường tốt hơn là evolve (mở rộng) thay vì đổi hoàn toàn.

## References

- `brandformance-competitor-map` → Kết quả khoảng trống cạnh tranh
- `brandformance-customer.md` → Phần IV (3 nhóm KH)
- `references/branding-marketing-sale-phungsu.md` → Hệ điều hành "Branding–Marketing–Sale Phụng Sự 2.0": 3 trụ cột (Brand DNA, Marketing dẫn đường, Sale trị liệu 4 bước), 12 hình mẫu Jung, bộ công cụ thực thi

Template: "[Brand] là [loại hình CỤ THỂ] duy nhất giúp [audience CỤ THỂ] [kết quả ĐO ĐƯỢC] bằng cách [phương pháp KHÁC BIỆT]."

Dấu hiệu positioning TỐT:
- Nói được "chúng tôi không phù hợp với [nhóm KH cụ thể]" mà không ngại
- KH đọc nói "đây là dành cho tôi" — không cần giải thích thêm
