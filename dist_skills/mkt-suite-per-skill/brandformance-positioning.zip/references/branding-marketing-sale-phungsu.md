# Hệ điều hành "Branding – Marketing – Sale PHỤNG SỰ 2.0"
Distil từ tài liệu "BRANDING-MARKETING-SALE 3.0" (Chiến Binh Fullstack Marketing).

**Triết lý cốt lõi:** Mọi hoạt động kinh doanh là một hành động **phụng sự**. Lợi nhuận không phải mục tiêu theo đuổi, mà là **kết quả tất yếu** của việc phụng sự xuất sắc. Vận hành đồng bộ 3 trụ cột:

## Trụ cột I — BRANDING PHỤNG SỰ ("Bản sắc từ Linh hồn")
Không xây hình ảnh bên ngoài, mà khai mở & biểu đạt "linh hồn" bên trong — trả lời "Chúng ta là ai?" ở tầng sâu nhất.
- **1.1 Giải mã Brand DNA:** dùng **IKIGAI** tìm lý do tồn tại đích thực + **Stoicism** xác định giá trị cốt lõi không thoả hiệp → định vị một "Lý tưởng Phụng sự" vượt trên sản phẩm (vd Nike phụng sự "khai phá tiềm năng con người", không bán giày).
- **1.2 Hình mẫu hoá bản sắc:** dùng **12 Hình mẫu của Carl Jung** (Người Hùng, Kẻ Nổi loạn, Người Chăm sóc…) chọn 1 chủ đạo + 1 phụ → tính cách thương hiệu nhất quán, đi vào tiềm thức.
- **1.3 Bản sắc đa giác quan:** biến bản sắc vô hình thành trải nghiệm hữu hình ở mọi điểm chạm — Visual (màu, font), Audio (giọng văn, nhạc), cả Olfactory (mùi hương cửa hàng) — đồng nhất với hình mẫu đã chọn.

## Trụ cột II — MARKETING PHỤNG SỰ ("Dẫn dắt Hành trình Chuyển đổi")
Không săn đuổi khách, mà trở thành **người dẫn đường đáng tin cậy**.
- **2.1 Nam châm Giá trị (Value Magnet):** nền tảng Youtility + Permission Marketing; dùng AI sản xuất nội dung hữu ích quy mô lớn → hút khách bằng cách **cho đi giá trị vô điều kiện**.
- **2.2 Bản đồ Tâm lý Hành trình:** kết hợp Customer Journey + Tháp Maslow + Tâm lý học Tiến hoá → hiểu rào cản/động lực từng giai đoạn (Nhận biết → Cân nhắc → Mua) và "phục kích" bằng đúng nội dung hoá giải nút thắt tâm lý.
- **2.3 Virus Ý tưởng:** Ideavirus + tâm lý đám đông + social/video ngắn → tạo câu chuyện chạm EQ, tự lan truyền, biến khách thành "tông đồ".

## Trụ cột III — SALE PHỤNG SỰ ("Hoà âm Kết thúc")
Không chốt giao dịch, mà giúp khách **ra quyết định tốt nhất cho chính họ**.
- **3.1 Người bán → "Nhà trị liệu Quyết định":** chẩn đoán, lắng nghe, đồng sáng tạo giải pháp (là đồng minh, không phải đối thủ). Nội lực từ Napoleon Hill, Covey, kỹ năng lắng nghe Dale Carnegie.
- **3.2 Quy trình "Trị liệu" 4 bước:**
  1. **Kiến tạo Không gian An toàn** → hoá giải Sự sợ hãi.
  2. **Chẩn đoán bằng Sự im lặng** → hoá giải Sự hoài nghi.
  3. **Đồng sáng tạo Giải pháp** → hoá giải Sự trì hoãn.
  4. **Tái định vị Giá trị** → hoá giải Xung đột Giá trị.
  → Giao dịch diễn ra tự nhiên, nhẹ nhàng; khách thấy được thấu hiểu & tự tin.
- **3.3 Tối ưu bằng AI & dữ liệu tâm lý:** phân tích cuộc gọi bán hàng, tìm mẫu ngôn ngữ hiệu quả, dự báo hành vi, cá nhân hoá lời đề nghị.

## Bộ công cụ thực thi (Practitioner's Toolkit)
1. Bộ câu hỏi **"Khai mở Linh hồn Thương hiệu"** (IKIGAI + Stoicism + 12 hình mẫu).
2. Biểu mẫu **"Phân tích Tâm lý Khách hàng 360°"** (Maslow + tâm lý tiến hoá).
3. Khung **"Kịch bản Bán hàng Trị liệu"** (chi tiết hoá 4 bước Hoà âm Kết thúc thành mẫu câu + xử lý từ chối).
4. Checklist **"Kích hoạt Bản sắc Đa giác quan"** (áp hình mẫu vào website → email signature).

## Kết nối
- Định vị & DNA thương hiệu: skill này (positioning) + brandformance-brand-bible (voice/tone/archetype).
- Hành trình & phễu: brandformance-funnel-design. Insight khách: brandformance-customer-insight.
- Kịch bản bán/chốt: brandformance-lead-conversion.
