---
name: brandformance-ads-optimize
description: "Kích hoạt khi cần tối ưu ads đang chạy — phân tích số liệu, xác định điểm nghẽn, đề xuất điều chỉnh cụ thể. Trigger: 'tối ưu ads', 'optimize ads', 'ads không hiệu quả', 'CPL cao quá', 'ROAS thấp', 'CTR thấp', 'tại sao ads không ra số', 'ads đang chạy không ổn'."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: ads</summary>

# brandformance-ads

> Kiến thức về hệ thống Performance Ads trong Brandformance — đọc trước khi chạy bất kỳ skill ads.

## I. Khi nào nên chạy Ads

Ads là bước cuối cùng, không phải khởi đầu. Chỉ chạy khi: SP rõ + biết bán cho ai + có content đúng insight + có nơi để KH đi tiếp.

## II. Cấu trúc Campaign Meta Ads

Campaign (1 mục tiêu) → Ad Set (1 audience + 1 ngân sách) → Ad (1 creative)
Mỗi cấp chỉ có 1 biến để test. Không trộn mục tiêu trong cùng Campaign.

## III. Giai đoạn 1 — Testing

Mục tiêu: tìm content + audience work. Không tối ưu chi phí ở giai đoạn này.
Cấu trúc: 1 Campaign → 2-3 Ad Set → 2-3 Ads/Ad Set = 4-9 ads tổng.
Ngân sách: 100-300K/ngày/Ad Set. Tối thiểu 3-5 ngày. ~1-2 triệu để có data.
A/B Testing: thay 1 yếu tố/lần. Không đánh giá trước 3 ngày. Không sửa ad đang chạy ổn.

## IV. Giai đoạn 2 — Đo lường & Tối ưu

Vào sau khi Ads chạy ≥3 ngày, mỗi Ad Set ≥1.000 impressions.
Tắt: CTR < 0.8% sau 3 ngày không có lead.
Gom ngân sách về top performers.
Nhân bản Ads tốt sang audience khác.

## V. Giai đoạn 3 — Scale Up

Điều kiện scale: CTR > 2% + CPL ổn định 5-7 ngày + tỉ lệ chốt > 20%.
Scale dọc: tăng ngân sách ≤20-30%/lần, cách 2-3 ngày.
Scale ngang: nhân bản sang audience mới hoặc content mới.
Retarget: xem video >3s / nhắn tin chưa chốt / vào landing chưa để lại thông tin.

## VI. Ngưỡng chỉ số tham chiếu

CTR tốt: > 2% / Cần xem lại: < 0.8%
Frequency tốt: < 3 / Cần xem lại: > 3 trong 7 ngày
Tỉ lệ chốt tốt: > 20% / Cần xem lại: < 10%

Creative lifespan: audience nhỏ + ngân sách cao → mệt nhanh (1-2 tuần); audience lớn + ngân sách vừa → 4-6 tuần. Nên có creative mới sẵn sàng TRƯỚC khi frequency chạm ngưỡng 3.

## VII. Content Brandformance trong Ads

Mỗi ads = "2 trong 1": Branding (cảm xúc, câu chuyện) + Performance (CTA rõ, trigger hành động).
Mỗi tầng gắn Content Pillar chính + Angle cụ thể để dễ nhân bản theo tuần/tháng.

## VIII. Tracking & Attribution

Bắt buộc: Pixel + Conversion API chạy song song. Chỉ dùng Pixel (browser-side) không còn đủ tin cậy từ iOS 14.5+ và ad blocker — có thể mất 15-30% data thực tế. Conversion API (server-side) bù đắp phần mất.

Event Match Quality (EMQ) — tăng bằng cách gửi kèm email/SĐT đã hash trong sự kiện. EMQ thấp làm giảm hiệu quả tối ưu của thuật toán Meta dù creative/audience đúng.

UTM chuẩn hóa theo cấu trúc cố định (source/medium/campaign/content) cho mọi campaign để so sánh được qua thời gian.

## IX. Ngoài Meta — Google Search Ads

Meta/TikTok = Interruption — chen vào feed người chưa chủ động tìm kiếm, cần Hook mạnh để dừng scroll.
Google Search = Intent Capture — người dùng đã chủ động gõ từ khóa, không cần hook, cần đúng lúc đúng chỗ.

Chỉ chạy ads cho từ khóa Commercial investigation/Transactional. Không chạy cho Informational — dùng SEO/content thay thế.

Quality Score (ảnh hưởng CPC) phụ thuộc vào mức khớp giữa Từ khóa → Ad → Landing page.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Ads Optimize

## 1. Triggers
- "tối ưu ads", "CPL cao", "ROAS thấp", "CTR thấp", "ads không ra số"

## 2. Context Requirements
- [ ] **[BẮT BUỘC]** CPL, CTR, ROAS, CPA, số ngày đã chạy
- [ ] **[NẾU CÓ]** Creative và audience nào tốt/tệ

## 3. Execution Steps

### Bước 1: Chẩn đoán theo funnel
**Reach nhiều → Click ít (CTR < 0.8%):** Vấn đề CREATIVE
**Click nhiều → Lead ít (Form fill < 15%):** Vấn đề LANDING PAGE / OFFER
**Lead nhiều → Chốt ít (< 10%):** Vấn đề SALES PROCESS (không phải ads)
**Lead quality thấp:** Vấn đề AUDIENCE TARGETING

### Bước 2: Fix theo vấn đề

**CTR thấp → Fix Creative:**
Đổi hook (3 dạng khác nhau), thumbnail, format. Không touch audience/budget.

**Form fill thấp → Fix Landing Page:**
Tốc độ load, CTA visibility, form quá nhiều field (giữ tên + SĐT), social proof.

**Lead quality thấp → Fix Audience:**
Narrow interest, loại trừ non-relevant, test Lookalike từ KH đã mua.

**ROAS thấp toàn diện → Check toàn phễu:**
Brand:Performance đúng tỉ lệ chưa? Đang bán BOFU message cho cold audience không?

### Bước 3: Quy tắc không vi phạm
❌ Không edit trong 7 ngày đầu learning phase
❌ Không tăng budget > 30% một lần
❌ Không dừng và restart liên tục
❌ Không thay đổi nhiều thứ cùng lúc

✅ 1 biến / 3-5 ngày quan sát

### Bước 4: Optimization log

| Ngày | Vấn đề | Hành động | Kết quả | Lesson |
|---|---|---|---|---|
| 15/7 | CTR 0.6% | Đổi hook: Number → Pain | CTR 1.8% | Pain hook hiệu quả |

## 4. Examples

### Example 1 — CTR thấp
```
PROBLEM: CTR 0.5%, CPL 500K (target 200K)
DIAGNOSIS: Creative problem

ACTIONS (Ngày 8):
Dừng 2 static images, giữ video CTR 0.8%
Launch 2 video mới:
 C (Pain): "Bạn đổ tiền ads mà không ra KH — lý do thật sự là..."
 D (Story): "Tháng trước KH tôi tăng lead 300%..."

RESULT: C: CTR 2.3%, CPL 150K ✅ / D: CTR 1.1%, CPL 260K
ACTION: Scale C +30%, dừng D
```

### Example 2 — Lead quality thấp
```
PROBLEM: 50 leads/tuần, close rate 6% (target 15%)
DIAGNOSIS: Audience quá broad

ACTIONS:
Ngày 1: Add qualification question in form
Ngày 3: Narrow interest (bỏ "Business", giữ "Content marketing")
Ngày 7: Test Lookalike 1% từ 20 KH đã mua

RESULT: 35 leads/tuần, close rate 18%, CPO -40%
```

## 5. Edge Cases
**Số liệu không ổn định**: Đợi 7-14 ngày + 50 conversions trước khi judge.
**Đã fix mọi thứ, CPL vẫn cao**: Check offer thật sự có hấp dẫn không? Hỏi KH đã inbox tại sao không mua.
**Ads từng work, giờ không**: Ad fatigue → Fresh creative, không phải thay audience.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `DIAGNOSIS` | Chẩn đoán theo funnel |
| `FIXING` | Fix theo vấn đề |
| `RULES_CHECK` | Không vi phạm rules |
| `LOGGING` | Log actions |
| `DONE` | Optimization plan |

## References
- `brandformance-ads.md` → Phần III + V (Tối ưu + Điểm nghẽn)
