---
name: brandformance-zalo-oa-strategy
description: "Kích hoạt khi cần thiết lập chiến lược Zalo OA riêng biệt — menu, ZNS, broadcast rules, follow-growth. Trigger: 'Zalo OA', 'chiến lược Zalo', 'setup Zalo OA', 'ZNS', 'broadcast Zalo', 'menu Zalo OA', 'tăng follow Zalo'. Kích hoạt khi Zalo OA đang bị dùng như bản sao của Email mà chưa khai thác đúng đặc thù kênh."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Zalo OA Strategy

## 1. Triggers

### Explicit triggers
- "setup Zalo OA", "chiến lược Zalo OA", "ZNS là gì"
- "broadcast Zalo", "tăng follow Zalo OA"

### Implicit triggers
- Đang gửi Zalo OA y hệt nội dung Email, không tận dụng đặc thù kênh
- Follow rate Zalo OA cao nhưng tương tác/click thấp
- Cần kênh xác nhận giao dịch (đặt lịch, đơn hàng) nhanh hơn Email

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Mục tiêu OA: CSKH / Sale / Cả hai
- [ ] **[BẮT BUỘC]** Lượng follower hiện tại và ngành nghề
- [ ] **[NẾU CÓ]** Dữ liệu tương tác hiện tại

## 3. Execution Steps

### Bước 1: Phân biệt Zalo OA với Email
Người Việt kiểm tra Zalo nhiều lần/ngày — nội dung phải **ngắn, trực tiếp, giống tin nhắn thật**. Zalo OA có 2 loại tin:
- **Broadcast (quảng cáo)**: cần follower đồng ý nhận, có giới hạn tần suất
- **ZNS (Zalo Notification Service)**: dùng cho giao dịch/xác nhận (đơn hàng, lịch hẹn), không phải quảng cáo

### Bước 2: Thiết kế Menu OA
Cấu trúc menu chat rõ ràng: [Xem bảng giá] [Đặt lịch tư vấn] [Hỏi đáp nhanh] [Liên hệ CSKH]. Quick reply cho câu hỏi thường gặp để giảm tải người trực Zalo.

### Bước 3: Follow-growth tactics
- QR code tại điểm chạm offline (cửa hàng, sự kiện, bao bì sản phẩm)
- Tích hợp nút "Quan tâm OA" ngay trên landing page/thank-you page
- Ưu đãi nhỏ đổi lấy follow (không lạm dụng — follow chất lượng thấp kéo tương tác xuống)

### Bước 4: Broadcast rules
- Tần suất tối đa 2-3 broadcast/tuần
- Nội dung phù hợp: ưu đãi có giới hạn thời gian, thông báo sản phẩm mới, nhắc lịch
- KHÔNG dùng để giáo dục dài dòng (đó là việc của Content Social/Email)

### Bước 5: ZNS cho use case giao dịch
Xác nhận đơn hàng, nhắc lịch hẹn, thông báo trạng thái — template phải đăng ký đúng chuẩn Zalo trước khi dùng.

### Bước 6: Build Zalo OA Content Plan tích hợp với Nurture Sequence
Xác định rõ trigger nào dùng Zalo (cần phản hồi nhanh, urgency) và trigger nào dùng Email (nội dung sâu).

## 4. Examples

### Example 1 — Spa làm đẹp
```
MENU OA: [Bảng giá liệu trình] [Đặt lịch ngay] [Hỏi da mình phù hợp gì] [CSKH]

FOLLOW-GROWTH: QR code dán tại quầy lễ tân + in trên hóa đơn — "Quan tâm OA nhận ưu đãi 10% lần sau"

BROADCAST TUẦN: T3 "Còn 5 slot liệu trình cuối tuần" | T6 "Ưu đãi cuối tuần - còn 24h"

ZNS: Xác nhận lịch hẹn tự động ngay sau khi khách đặt qua form — giảm tỉ lệ no-show 30%
```

### Example 2 — Trung tâm ngoại ngữ
```
MENU OA: [Lịch khai giảng] [Đăng ký học thử] [Tư vấn lộ trình] [Hỗ trợ học viên]

ZALO vs EMAIL TRONG NURTURE:
- Học viên đăng ký học thử nhưng chưa tham gia → Zalo OA nhắc trước 1 ngày
- Case study/nội dung giáo dục sâu → vẫn dùng Email

BROADCAST: Chỉ dùng cho thông báo khai giảng mới + deadline ưu đãi, tối đa 2 lần/tuần
```

## 5. Edge Cases & Error Handling

**OA bị giảm follow rate do broadcast quá dày**: Giảm ngay về 1-2 broadcast/tuần trong 1 tháng.
**ZNS bị từ chối do sai template**: Kiểm tra lại đúng use case đăng ký (giao dịch, không phải quảng cáo).
**Follower cao nhưng tương tác thấp**: Follow chất lượng thấp — ưu tiên chất lượng follow qua điểm chạm thật.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `CHANNEL_DIFF` | Phân biệt Zalo OA vs Email |
| `MENU_DESIGN` | Thiết kế Menu OA |
| `GROWTH_TACTICS` | Follow-growth tactics |
| `BROADCAST_RULE` | Thiết lập tần suất + nội dung broadcast |
| `ZNS_SETUP` | Setup ZNS cho giao dịch |
| `DONE` | Zalo OA Content Plan hoàn chỉnh |

## References
- `brandformance-content.md` → Phần VII
- `brandformance-nurture-sequence.md` → Phân vai kênh Email vs Zalo
- `brandformance-email-plan.md` → So sánh nguyên tắc chung
