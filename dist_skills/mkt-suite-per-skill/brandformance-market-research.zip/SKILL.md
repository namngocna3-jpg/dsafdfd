---
name: brandformance-market-research
description: "Kích hoạt khi cần nghiên cứu thị trường theo tư duy Brandformance — xác định vùng đánh du kích, phân khúc cắt lát/cắt lớp, tìm khoảng trống thị trường chưa ai chiếm. Trigger: 'nghiên cứu thị trường', 'phân tích ngành', 'phân khúc thị trường', 'cắt lát thị trường', 'vùng KH tiềm năng', 'thị trường đang như thế nào', 'tôi nên nhắm vào tệp nào', 'có cơ hội nào chưa ai khai thác không'. Kích hoạt cả khi user chuẩn bị vào thị trường mới hoặc review lại chiến lược targeting hiện tại."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Market Research

## 1. Triggers

### Explicit triggers
- "nghiên cứu thị trường cho ngành [X]"
- "phân tích ngành", "thị trường đang như thế nào"
- "tôi nên nhắm vào tệp KH nào?", "cắt lát thị trường giúp tôi"
- "có cơ hội nào chưa ai khai thác không?"

### Implicit triggers
- User chuẩn bị ra mắt sản phẩm/dịch vụ mới nhưng chưa xác định rõ tệp
- Target audience đang quá rộng ("tất cả mọi người") → cần thu hẹp lại
- CPL đang tăng dần → có thể đang nhắm sai phân khúc
- Đối thủ vừa xuất hiện với sản phẩm tương tự → cần tìm góc khác biệt
- User mô tả KH bằng nhân khẩu học chung chung: "nữ 25-35 tuổi, quan tâm làm đẹp"

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Ngành hàng / lĩnh vực kinh doanh và sản phẩm/dịch vụ chính
- [ ] **[BẮT BUỘC]** Địa lý target (cả nước / vùng / tỉnh thành cụ thể)
- [ ] **[BẮT BUỘC]** Giai đoạn doanh nghiệp: mới vào thị trường hay đang scale
- [ ] **[NẾU CÓ]** Mức giá sản phẩm/dịch vụ
- [ ] **[NẾU CÓ]** Ngân sách marketing ước tính hàng tháng
- [ ] **[NẾU CÓ]** Những phân khúc đã thử và kết quả (để tránh lặp lại)

Đọc trước khi thực hiện:
- `brandformance-framework.md` → Phần I (Vấn đề Brandformance giải quyết), Phần III (Phễu 4 giai đoạn)
- `brandformance-customer.md` → Phần I (Nguyên tắc phân khúc), Phần II (Cắt lát), Phần III (Cắt lớp)

## 3. Execution Steps

### Bước 1: Xác định bức tranh tổng thể ngành
1.1 Mô tả ngành đang ở giai đoạn nào: mới nổi / tăng trưởng / bão hòa / suy giảm.
1.2 Xác định 3 lực lượng đang định hình thị trường: xu hướng tiêu dùng, áp lực cạnh tranh, thay đổi hành vi.
1.3 Ước tính quy mô thị trường có thể tiếp cận (không cần con số chính xác, chỉ cần cảm nhận: lớn / vừa / nhỏ).
1.4 Đặt câu hỏi quan trọng: "Thị trường này đang thiếu gì mà KH vẫn chưa được phục vụ tốt?"

### Bước 2: Phân khúc cắt lát (Segmentation by need/behavior)
Không phân khúc theo nhân khẩu học đơn thuần — phân theo VẤN ĐỀ + HÀNH VI + GIAI ĐOẠN ra quyết định.

2.1 Xác định 4-6 "lát cắt" khác nhau trong thị trường:
- Lát theo vấn đề: KH đang gặp vấn đề gì cụ thể? (không phải "muốn mua sản phẩm X")
- Lát theo hành vi: Họ đang làm gì để giải quyết vấn đề đó trước khi biết đến brand?
- Lát theo giai đoạn: Họ đang nhận ra vấn đề / đang tìm giải pháp / sẵn sàng mua?

2.2 Với mỗi lát cắt, đánh giá 3 tiêu chí:
- Quy mô: Có đủ người trong phân khúc này không?
- Khả năng chi trả: Họ có ngân sách phù hợp với mức giá không?
- Khả năng tiếp cận: Brand này có thể reach được họ với ngân sách hiện có không?

2.3 Tạo ma trận ưu tiên:

| Phân khúc | Quy mô (S/M/L) | Chi trả (Thấp/Trung/Cao) | Tiếp cận (Dễ/Vừa/Khó) | Ưu tiên |
|---|---|---|---|---|
| [Lát 1] | | | | |
| [Lát 2] | | | | |

### Bước 3: Phân khúc cắt lớp (Persona Depth)
Đi sâu vào 2-3 lát cắt được ưu tiên:

3.1 Với mỗi lát được chọn, vẽ chân dung chi tiết:
- Họ là ai trong cuộc sống thực? (không chỉ nhân khẩu học)
- Ngày làm việc điển hình của họ trông như thế nào?
- Câu hỏi họ search trên Google/TikTok về vấn đề này là gì?
- Họ đã thử giải pháp nào trước đó và tại sao thất bại?

3.2 Xác định "Câu nói nội tâm" thật của từng nhóm:
- Không phải "tôi muốn mua sản phẩm A"
- Phải là: "Sao mình cứ [vấn đề] hoài vậy, chắc tại [lý do sai mà họ tin]"

3.3 Xác định điểm vào phễu: Phân khúc này sẽ vào từ đâu — TikTok organic / Facebook Ads / Google Search / Giới thiệu?

### Bước 4: Tìm khoảng trống Brandformance
4.1 **Khoảng trống BRAND**: Có phân khúc nào đang bị underserved về mặt nhận diện / storytelling không?
- Đối thủ đang nói gì với phân khúc này?
- Góc nào chưa ai nói đến?

4.2 **Khoảng trống PERFORMANCE**: Có phân khúc nào đang bị phục vụ kém về offer / pricing / format không?
- Offer hiện tại trên thị trường có gaps gì?
- KH đang phải tự "ghép" từ nhiều giải pháp khác nhau?

4.3 Xác định "Vùng đánh du kích": Phân khúc đủ nhỏ để brand dominate với ngân sách hiện có, đủ lớn để scale sau.

### Bước 5: Compile Research Report và đưa ra khuyến nghị
5.1 Tóm tắt bức tranh ngành (3-5 câu).
5.2 Liệt kê 3-5 phân khúc đã phát hiện với đánh giá ưu tiên.
5.3 Chọn 1-2 phân khúc nên đánh trước với lý do cụ thể.
5.4 Xác định khoảng trống có thể khai thác ngay.
5.5 Đề xuất: "Bước tiếp theo nên là brandformance-customer-insight để đi sâu vào 2 phân khúc này."

## 4. Edge Cases & Error Handling

**Case 1: Ngành quá rộng ("kinh doanh online", "thực phẩm")**
→ Hỏi lại: "Sản phẩm cụ thể là gì? Giải quyết vấn đề gì?"
→ Không research tổng quan ngành mà không có focal point.

**Case 2: User đã có tệp KH nhưng muốn tìm thêm**
→ Bắt đầu từ tệp hiện tại: "Tệp này đang hoạt động tốt không? Muốn mở rộng hay tìm thay thế?"
→ Research phân khúc liền kề, không bắt đầu lại từ đầu.

**Case 3: Không có data thị trường (ngành mới/niche)**
→ Dùng proxy: research ngành tương tự ở thị trường phát triển hơn.
→ Ghi rõ: "Ước tính dựa trên ngành tương tự, chưa có data thực tế VN."

**Case 4: User muốn đánh tất cả phân khúc cùng lúc**
→ Flag: "Ngân sách [X] triệu không đủ dominate nhiều phân khúc. Chọn 1-2 để thắng trước."

**Case 5: Thị trường rất cạnh tranh, đối thủ lớn chiếm đa số**
→ Không phải lý do từ bỏ — là lý do tìm phân khúc nhỏ chưa ai serve tốt.

## References

- `brandformance-customer.md` → Phần I (Nguyên tắc phân khúc), Phần II (Cắt lát), Phần III (Cắt lớp)
- `brandformance-framework.md` → Phần I (Vấn đề Brandformance giải quyết)

Phân biệt 2 phương pháp:
- **Cắt lát** = Chia thị trường thành mảng theo vấn đề/hành vi/giai đoạn → chọn vùng nào đánh
- **Cắt lớp** = Đi sâu vào 1 mảng đã chọn → hiểu từng người trong đó nghĩ gì
