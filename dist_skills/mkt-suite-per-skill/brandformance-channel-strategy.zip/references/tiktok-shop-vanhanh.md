# Vận hành kênh TikTok Shop bán hàng

Distil từ khóa "Xây kênh TikTok bán hàng hiệu quả" (GV Lê Bùi, TAS Global). Dùng khi TikTok Shop / TikTok bán hàng là kênh chuyển đổi chính, không phải kênh phủ nhận thức. Bổ trợ cho `brandformance-content-script` (kịch bản viral) — file này lo phần **vận hành bán hàng & livestream**.

---

## I. Lộ trình cửa hàng mới — 3 giai đoạn

1. **Chuẩn bị & khởi động** — Đăng tối thiểu 15 sản phẩm lên mục lục; mỗi sản phẩm ≥3 video 15s giới thiệu kênh/sản phẩm/đặc điểm nổi bật; tối ưu tiêu đề/hình ảnh/mô tả; cài ≥2 công cụ khuyến mãi.
2. **Xây hình ảnh & người hâm mộ** — Đăng ≥2–3 video/tuần, theo dõi **GPM, CO, CTR**; chuẩn bị kịch bản livestream + sản phẩm + CTKM; lên lịch Live ≥2–3 buổi/tuần, mỗi buổi 1h30–3h để tăng tương tác và nhận diện với tệp mới.
3. **Tối ưu & mở rộng** — Đặt mục tiêu doanh thu Live; theo dõi bảng dữ liệu Livestream/Video/Khách hàng để cải thiện; mở rộng qua **Nhà sáng tạo hợp tác (affiliate)** — gửi sản phẩm mẫu để KOC tạo nội dung.

## II. Chỉ số phải theo dõi

| Chỉ số | Ý nghĩa |
|---|---|
| **GPM** (Gross Merchandise per Mille) | Doanh thu trên 1.000 lượt xem — đo hiệu quả biến view thành tiền |
| **CTR** | Tỉ lệ click vào sản phẩm — đo sức hút hình ảnh/tiêu đề |
| **CO** (Conversion) | Tỉ lệ chuyển đổi từ click sang mua |

Benchmark tham chiếu từ tài liệu: sản phẩm kéo đơn tốt có **CTR >6%, CO >2.5%**; sản phẩm lợi nhuận cao chấp nhận CTR ~5–6% nhưng biên >20%.

## III. Chiến lược 3 nhóm sản phẩm (quan trọng nhất)

Mỗi sản phẩm phải được gán một vai trò, không để lẫn lộn:

| Nhóm | Mục tiêu | Loại sản phẩm | Công cụ & mức lợi nhuận |
|---|---|---|---|
| **Kéo lượt xem** | Hút người vào Live | Flash deal giá sốc 9K/19K/29K; phụ kiện (túi chống sốc, cường lực, bộ vệ sinh) | Voucher hoàn thành nhiệm vụ xem Live; **lợi nhuận ~0%, số lượng có hạn** |
| **Kéo doanh số** | Tạo đơn nhanh trong thời gian ngắn | Sản phẩm bán chạy, hàng tốt, sản phẩm bỏ giỏ | Mua theo gói, Mua nhiều giảm nhiều, Mua 1 tặng 1; **lợi nhuận trung bình ~10%**; tham gia Free Shipping |
| **Kéo lợi nhuận** | Đem lại biên cao | Sản phẩm AOV cao | **Lợi nhuận >20%** |

**Nhịp trong buổi Live:** đầu Live tung sản phẩm kéo view + kích Like/Share/Comment đến ngưỡng → giữa Live teasing sản phẩm kéo doanh số → giữa đến cuối Live đẩy sản phẩm lợi nhuận cao.

## IV. Đặt tên sản phẩm tối ưu

Cú pháp: **[Ưu đãi/Mua 1 tặng 1] + [Thời gian áp dụng] + [Tên sản phẩm] + [Thuộc tính]**
- Đính kèm hình quà tặng.
- Chỉ ghi "Mua 1 tặng 1" khi ĐÃ cài chương trình quà tặng trên Seller Center (tránh vi phạm).
- Ví dụ: "[Chỉ 20–22/7 Voucher đến 500k] Nồi chiên không dầu Bear 4.5L".

## V. Công cụ khuyến mãi theo giai đoạn

- **Khởi động:** Voucher giảm giá, Mua theo gói, Mua nhiều giá hời.
- **Trong Live:** Voucher tương tác trong Live, Quà tặng khi mua, Săn giá sốc.
- Duy trì mỗi chương trình + danh sách sản phẩm ≥1 tuần để đủ dữ liệu đo hiệu suất trước khi đổi.

## VI. Hoa hồng affiliate (Nhà sáng tạo hợp tác)

Mức hoa hồng đề xuất theo AOV để hút KOC nhận mẫu:
- Sản phẩm **< 499K**: hoa hồng ~15%.
- Sản phẩm **≥ 499K**: hoa hồng ~8%.
→ Gửi sản phẩm mẫu kèm brief để khuyến khích Nhà sáng tạo tạo nội dung gắn giỏ hàng.

## VII. Nguyên tắc

- TikTok Shop là kênh **Convert** (đáy phễu) — không kỳ vọng nó tự sinh nhận thức; phối với content viral (giai đoạn "Chưa biết→Biết") ở `brandformance-content-script`.
- Livestream là công cụ vừa xây nhận diện vừa chốt đơn — duy trì tần suất đều quan trọng hơn một buổi đột biến.
- Mọi sản phẩm phải có vai trò rõ (view/đơn/lợi nhuận); lẫn lộn vai trò làm loãng cả buổi Live.

## Kết nối skill

- Kịch bản video viral kéo traffic vào kênh → `brandformance-content-script` (`references/short-video-playbook.md`).
- Brief cho KOC/affiliate nhận mẫu → `brandformance-ugc-koc-brief`.
- Thiết kế offer & combo sản phẩm → `brandformance-offer-design`.
- Đo lường doanh thu kênh → `brandformance-kpi-setup`, `brandformance-report`.
