---
name: brandformance-channel-strategy
description: >
  Xác định vai trò kênh (Reach/Nurture/Convert), chọn kênh phù hợp theo ngân sách và quy mô team. Kích hoạt khi: "channel strategy", "chiến lược kênh", "kênh nào phù hợp", "chọn kênh marketing", "nên tập trung kênh nào", "đa kênh", "omnichannel".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Channel Strategy

## 1. Triggers

### Explicit triggers
- "chiến lược kênh / channel strategy"
- "nên tập trung vào kênh nào?", "phân vai kênh marketing"
- "kênh xây brand vs kênh convert", "owned / paid / earned media"

### Implicit triggers
- Brand đang spread quá mỏng, không kênh nào thực sự tốt
- Một kênh đột ngột không hiệu quả → cần backup channel
- CPL tăng trên kênh chính → cần diversify

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Ngành hàng và hành vi KH
- [ ] **[BẮT BUỘC]** Ngân sách marketing tháng
- [ ] **[BẮT BUỘC]** Nhân lực hiện có
- [ ] **[NẾU CÓ]** Kênh đang chạy và kết quả

## 3. Execution Steps

### Bước 1: Map KH đang ở đâu (Channel-Audience Fit)
- KH B2C 18-35 tuổi → TikTok, Instagram, YouTube
- KH B2C 30-50 tuổi → Facebook, YouTube, Google Search
- KH B2B, decision maker → LinkedIn, Facebook Group, Email
- KH tìm kiếm có intent → Google Search, YouTube

Kênh theo Content Type:
- Sản phẩm visual → Instagram, TikTok
- Education-heavy (B2B, khóa học) → YouTube, Blog, Email
- Review-driven (mỹ phẩm, tech) → TikTok, YouTube, Group

### Bước 2: Phân kênh theo chức năng Brandformance

**Nhóm REACH (TOFU — Xây brand):**
TikTok organic, Facebook/Instagram organic, YouTube, SEO/Blog, KOC/Seeding, PR

**Nhóm NURTURE (MOFU — Xây trust):**
Email marketing, Zalo OA, Facebook Group, YouTube subscription

**Nhóm CONVERT (BOFU — Ra doanh thu):**
Facebook/Instagram Ads retarget, Google Search Ads, TikTok Ads, Direct message/Sales call

### Bước 3: Chọn kênh theo ngân sách và nhân lực

**< 10 triệu/tháng, 1 người:**
- Reach: TikTok organic (0 tiền, time cost)
- Nurture: Email hoặc Zalo OA
- Convert: Facebook Ads BOFU
→ 3 kênh, không spread mỏng

**10-30 triệu/tháng, 2-3 người:**
- TikTok + Facebook organic
- Facebook Ads TOFU + BOFU
- Email + Zalo OA
→ 5-6 kênh

**> 30 triệu/tháng, 4+ người:**
- Thêm: Google Search, YouTube, KOC program
→ 7-10 kênh, mỗi kênh có người chuyên trách

Nguyên tắc vàng: Không chạy kênh không có người theo dõi.

### Bước 4: Thiết kế Channel Mix Matrix

| Kênh | Chức năng | Budget/tháng | Owner | KPI | Review |
|---|---|---|---|---|---|
| TikTok organic | Reach TOFU | 0 | Content | Views, Follower | Weekly |
| Facebook Ads BOFU | Convert | X triệu | Ads Mgr | CPL, ROAS | Daily |
| Email/Zalo | Nurture | Y triệu | Marketing | Open rate, CTR | Weekly |

Primary channel = nơi đầu tư nhiều nhất. Phải work trước khi thêm kênh mới.

### Bước 5: Build Channel Strategy document
- Channel Map: KH đi từ kênh nào → kênh nào trong hành trình mua.
- Phân bổ ngân sách theo kênh.
- Điều kiện cắt/thêm kênh.

## 4. Examples

### Example 1 — Generic: Dịch vụ thiết kế nội thất (25 triệu/tháng)
```
WHERE IS KH: Facebook (group nhà đẹp), YouTube (tour nhà), Google ("thiết kế nội thất TP.HCM")

CHANNEL MIX:
Instagram organic | Reach TOFU | 0 (time) | Founder chụp công trình | Follower, Save rate
Facebook Ads BOFU | Convert | 10 triệu | Ass. Marketing | CPL inbox < 200K
Facebook Ads TOFU | Brand warm-up | 4 triệu | Ass. Marketing | Reach, Video views
TikTok organic | Brand storytelling | 0 (time) | Founder quay tour | Views, Comment
Google Ads Search | Intent capture | 4 triệu | Outsource | CPL < 300K
Email/Zalo | Nurture | 1 triệu | Ass. | Inbox → báo giá rate
KOC (1/quý) | Social proof | 3 triệu | Founder approve | Views, Inbox
Contingency | | 3 triệu | |

CHANNEL JOURNEY:
TikTok/Instagram (TOFU) → Facebook Retarget (MOFU) → Inbox (BOFU) → Zalo nurture → Chốt

PRIMARY CHANNEL PHẢI WORK TRƯỚC:
T1-2: Facebook Ads BOFU + Zalo (test baseline)
T3: Thêm Google Search nếu Facebook CPL ổn
T4+: Scale winner, thêm TikTok Ads nếu organic có traction
```

### Example 2 — Giáo dục: Trung tâm kỹ năng online (15 triệu/tháng)
```
WHERE IS KH: TikTok (clip kỹ năng ngắn), YouTube (khóa học trial), Facebook Group (hỏi kinh nghiệm)
ĐẶC BIỆT: Cần nhiều social proof trước khi mua

CHANNEL MIX:
TikTok organic | Reach TOFU | 0 (3 video/tuần)
Facebook Ads | Lead Gen | 8 triệu | CPL < 150K
Email sequence | Nurture | 1 triệu (tool)
Zalo OA | BOFU re-engage | 0.5 triệu
YouTube | Authority | 0 (2 video/tháng)
KOC học viên cũ | Social proof | 2 triệu | 2 video/tháng
Contingency | | 3.5 triệu

SOCIAL PROOF STRATEGY:
Email #3 trong sequence = Testimonial từ 3 học viên thật
Zalo OA: Gửi link case study sau khi KH đăng ký nhưng chưa mua

KHÔNG CHẠY: Google Ads (không search intent rõ), LinkedIn (đắt + không phù hợp)
```

## 5. Edge Cases & Error Handling

**Case 1: Không biết KH đang ở đâu**
→ Hỏi 5 KH gần nhất: "Bạn biết đến chúng tôi qua đâu?"
→ Check analytics: Traffic source từ kênh nào nhiều nhất.

**Case 2: Nhiều kênh nhưng không có traction**
→ Spread mỏng → chọn 1 primary channel → focus 3 tháng → có traction mới mở rộng.

**Case 3: Kênh chủ lực đột ngột tăng CPM/CPL**
→ Xây backup channel trong C-month → không bị passive khi cần.

**Case 4: Có nên chạy TikTok không?**
→ 2 câu hỏi: KH có ở TikTok không? + Có capacity tạo video không?
→ Cả 2 Có → nên thử.

## 6. State Management

| State | Mô tả | Claude làm gì |
|---|---|---|
| `AUDIENCE_MAPPING` | Xác định KH ở đâu | Chạy Bước 1 |
| `FUNCTION_MAPPING` | Phân kênh Reach/Nurture/Convert | Chạy Bước 2 |
| `SELECTION` | Chọn kênh theo budget + nhân lực | Chạy Bước 3 |
| `MATRIX_BUILD` | Tạo Channel Mix Matrix | Chạy Bước 4 |
| `COMPILING` | Build Channel Strategy | Chạy Bước 5 |
| `DONE` | Hoàn chỉnh | Đề xuất: "brandformance-media-plan để chi tiết hóa kênh paid" |

## References

- `brandformance-framework.md` → Phần III (Phễu 4 giai đoạn)
- `brandformance-content.md` → Phần VII (Content Funnel đa kênh)
- `references/tiktok-shop-vanhanh.md` → Khi TikTok Shop là kênh Convert chính: lộ trình cửa hàng mới, chỉ số GPM/CTR/CO, chiến lược 3 nhóm sản phẩm (kéo view/đơn/lợi nhuận), kịch bản Live, đặt tên sản phẩm, hoa hồng affiliate

Nguyên tắc:
- Owned channels (Email, Zalo OA) > Rented (Facebook, TikTok) về long-term
- Test new channel với 10-15% ngân sách trước khi commit
- Kênh nào KH actually dùng > kênh nào trending nhất
