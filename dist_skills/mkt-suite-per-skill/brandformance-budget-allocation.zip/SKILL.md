---
name: brandformance-budget-allocation
description: >
  Phân bổ ngân sách Brand/Performance theo giai đoạn business, funnel stage (TOFU 70/30, MOFU 50/50, BOFU 30/70), và từng kênh. Kích hoạt khi: "phân bổ ngân sách", "budget allocation", "phân chia budget", "tỷ lệ brand performance", "chi bao nhiêu cho ads", "phân bổ chi phí marketing".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Budget Allocation  
  
## 1. Triggers  
  
### Explicit triggers  
- "phân bổ ngân sách marketing", "budget allocation"  
- "bao nhiêu tiền nên chi cho ads / content / PR?"  
- "chia ngân sách theo kênh", "tỉ lệ brand vs performance"  
  
### Implicit triggers  
- Ngân sách mới được phê duyệt → cần phân bổ trước khi chạy  
- ROAS thấp mặc dù chi nhiều → có thể đang phân bổ sai  
- Mới vào thị trường → không biết nên bắt đầu từ đâu  
  
## 2. Context Requirements  
  
- [ ] **[BẮT BUỘC]** Ngân sách marketing tổng hàng tháng hoặc per campaign  
- [ ] **[BẮT BUỘC]** Mục tiêu: Doanh thu / Lead / Brand awareness  
- [ ] **[BẮT BUỘC]** Giai đoạn kinh doanh (mới / tăng trưởng / ổn định / scale)  
- [ ] **[NẾU CÓ]** Kênh đang chạy và kết quả hiện tại  
- [ ] **[NẾU CÓ]** Data lịch sử CPL, ROAS, CAC  
  
## 3. Execution Steps  
  
### Bước 1: Xác định giai đoạn → tỉ lệ Brand/Performance  
  
| Giai đoạn | Brand % | Performance % | Lý do |  
|---|---|---|---|  
| Mới ra thị trường (< 6 tháng) | 60-70% | 30-40% | Xây nhận diện trước khi bán |  
| Tăng trưởng (6-18 tháng) | 50% | 50% | Cân bằng xây brand + doanh thu |  
| Ổn định (> 18 tháng) | 40% | 60% | Brand đã có → convert |  
| Scale (có data tốt) | 30% | 70% | Double down on what works |  
  
### Bước 2: Phân bổ theo tầng phễu  
  
| Giai đoạn phễu | % Ngân sách | Mục tiêu |  
|---|---|---|  
| GĐ1 Awareness | 20-25% | Reach + Brand recognition |  
| GĐ2 Activation | 15-20% | Lead generation, Email list |  
| GĐ3 Conversion | 40-50% | CPA, CPO, ROAS |  
| GĐ4 Retention | 10-15% | Repeat purchase, LTV |  
  
### Bước 3: Phân bổ theo kênh cụ thể  
  
| Kênh | % Điển hình |  
|---|---|  
| Meta Ads TOFU | 15-20% |  
| Meta Ads BOFU/Retarget | 25-35% |  
| TikTok/YouTube | 10-15% |  
| Google Search | 10-15% |  
| Email/Zalo OA | 5-10% |  
| Content production | 10-15% |  
| Seeding/KOC | 5-10% |  
  
Quy tắc: Không phân bổ < 5% cho bất kỳ kênh nào; không quá 50% vào 1 kênh.  
  
### Bước 4: Tính số tiền cụ thể  
- Kiểm tra từng kênh có đủ ngân sách để chạy không.  
- Meta: Tối thiểu 200-300K/ngày per ad set.  
- Nếu ngân sách quá nhỏ cho nhiều kênh → cắt kênh, tập trung hơn.  
- Giữ contingency fund 10-15% để scale winner.  
  
### Bước 5: Build Budget Tracker  
  
| Kênh | % | Số tiền/tháng | KPI Target | Review trigger |  
|---|---|---|---|---|  
| Meta Ads TOFU | 20% | X triệu | Reach Y | CPM > Z → review |  
| Meta Ads BOFU | 30% | X triệu | A lead | CPL > 2× target → pause |  
  
## 4. Examples  
  
### Example 1 — Generic: Spa làm đẹp (20 triệu/tháng, giai đoạn tăng trưởng)  
```  
Tỉ lệ: Brand 50% / Performance 50%  
  
| Kênh | % | Số tiền |  
|---|---|---|  
| Facebook Ads BOFU | 30% | 6 triệu |  
| Facebook Ads TOFU | 20% | 4 triệu |  
| Content production (ảnh/video) | 20% | 4 triệu |  
| KOC/Seeding | 15% | 3 triệu |  
| Email/Zalo | 5% | 1 triệu |  
| Contingency | 10% | 2 triệu |  
  
KPI: 40 đơn / 6 triệu Ads BOFU → CPO mục tiêu 150K  
Review: Sau 10 ngày nếu CPL Facebook > 200K → reallocate 2 triệu sang KOC  
```  
  
### Example 2 — Giáo dục: Trung tâm khóa học (30 triệu/tháng, giai đoạn ổn định)  
```  
Tỉ lệ: Brand 40% / Performance 60%  
Lợi thế: Có email list 1500 → focus convert, ít cần awareness  
  
| Kênh | % | Số tiền |  
|---|---|---|  
| Facebook Ads BOFU | 35% | 10.5 triệu |  
| Facebook Ads TOFU | 15% | 4.5 triệu |  
| TikTok Organic + Ads | 15% | 4.5 triệu |  
| Email/Zalo (tool + content) | 10% | 3 triệu |  
| Content production | 15% | 4.5 triệu |  
| Referral program | 5% | 1.5 triệu |  
| Contingency | 5% | 1.5 triệu |  
  
Insight: Email list 1500 người = kênh BOFU mạnh nhất, chi phí thấp nhất  
→ Ưu tiên email sequence tốt hơn thêm ngân sách ads  
```  
  
## 5. Edge Cases & Error Handling  
  
**Case 1: Ngân sách < 5 triệu/tháng**  
→ 1 kênh duy nhất (BOFU); dùng time cost cho brand content.  
  
**Case 2: ROAS thấp dù chi nhiều**  
→ Vấn đề không phải ngân sách — vấn đề là phân bổ sai.  
→ Kiểm tra: TOFU thừa (Reach nhiều nhưng ít lead) hay BOFU thừa (audience bão hòa).  
  
**Case 3: Thay đổi phân bổ sau 1 tuần**  
→ 1 tuần chưa đủ data (Meta cần 7-14 ngày để optimize).  
→ Chỉ điều chỉnh khi có đủ data.  
  
**Case 4: Muốn 100% Performance**  
→ Flag: "Performance without brand = declining ROAS. Audience bão hòa nhanh."  
→ Giữ tối thiểu 20-30% cho brand content.  
  
## 6. State Management  
  
| State | Mô tả | Claude làm gì |  
|---|---|---|  
| `STAGE_ASSESSMENT` | Xác định giai đoạn | Chạy Bước 1 |  
| `FUNNEL_ALLOCATION` | Phân bổ theo tầng | Chạy Bước 2 |  
| `CHANNEL_ALLOCATION` | Phân bổ theo kênh | Chạy Bước 3 |  
| `CALCULATION` | Tính số tiền cụ thể | Chạy Bước 4 |  
| `TRACKING_BUILD` | Build Budget Tracker | Chạy Bước 5 |  
| `DONE` | Phân bổ hoàn chỉnh | Đề xuất export sang Google Sheets |  
  
## References  
  
- `brandformance-framework.md` → Phần III (Tỉ lệ Brand/Performance theo giai đoạn)  
- `brandformance-measurement.md` → Phần II (CAC, LTV, MER)  
  
Nguyên tắc vàng:  
- Không bao giờ < 20% cho Brand  
- Giữ 10-15% contingency để scale winner  
- Kênh < 5% ngân sách = không đủ để đo lường → cắt hoặc tăng
