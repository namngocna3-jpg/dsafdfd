# TikTok Ads Playbook 2026 (thị trường VN)
Distil từ "TikTok Ads Training" — Chiến Binh Fullstack Marketing (GV Uyên Đỗ, Media Planning Manager).

## 1. Bối cảnh nền tảng (VN 2026)
- TikTok đứng **Top 3** về % dùng social media, **Top 1** về mức độ yêu thích + thời gian dùng mỗi ngày.
- Tệp **25–34 tuổi** chiếm tỷ trọng cao nhất → tệp mua sắm chính.
- Cơ chế: nội dung phân phối qua FYP theo tín hiệu tương tác → ads phải "giống content" mới hiệu quả.

## 2. Hai cách tính phí
- **Auction (Bidding) — self-serve:** charge theo Impression, đấu giá, linh hoạt. Dùng cho phần lớn campaign performance.
- **Booking (Reservation):** trả phí cố định theo ngân sách/số lượng. Dùng cho branding lớn (TopView, Branded Mission).

Mô hình giá thường gặp: **CPC** (click), **CPV** (view), **CPM/oCPM** (1000 hiển thị), **CPT** (Cost per Takeover — cho TopView).

## 3. Các định dạng quảng cáo
| Nhóm | Định dạng | Dùng để |
|---|---|---|
| Content/Standard | **In-Feed Ads** | Xuất hiện trong "For You" như video thường — chủ lực performance |
| Branding | **TopView** (First video khi mở app), **Pulse**, **Branded Mission** | Phủ nhận diện mạnh, booking |
| Shopping | **Video Shopping Ads**, **Live Shopping Ads**, **Product Shopping Ads**, **Spark Ads** (boost video/TikTok Shop có sẵn) | Bán hàng trực tiếp qua Shop |
| Search | **Search Ads** | Bắt nhu cầu chủ động |
| Khác | **Messaging Ads**, **Interactive Add-ons**, **App Promotion** | Nhắn tin/tương tác/cài app |
| Tự động bán | **GMV Max** | AI tự tối ưu bán hàng theo GMV |

## 4. Mục tiêu chiến dịch theo Funnel
- **Awareness:** Reach, Video views, Community interaction → dùng TopView/In-feed branding.
- **Consideration:** Traffic, Brand Consideration (kéo tệp high-intent), Comment/Product Card behaviours → kết hợp **TikTok Market Scope** để đo phễu.
- **Conversion:** Lead generation, Sales, App promotion → In-feed + Shopping Ads + Retargeting.
Thang đo brand lift theo phễu: Familiarity → Favorability → Preference → Intent.

## 5. Nhắm chọn khách hàng (Targeting)
- **Direct:** nhắm theo nhân khẩu/sở thích/hành vi.
- **Retargeting:** nhắm lại người đã tương tác/xem/vào web/giỏ hàng.
- **Lookalike:** nhân bản tệp giống khách đã mua.

## 6. Ứng dụng AI của TikTok
- **Symphony Creative Studio:** AI tạo/biến thể creative nhanh (nhiều hook để test).
- **GMV Max AI:** tự động tối ưu ngân sách & placement theo doanh thu.

## 7. Quy định cần biết
Tuân thủ chính sách nội dung + tài khoản (tránh ngành/claim bị cấm, tránh khoá tài khoản). Kiểm tra policy trước khi chạy ngành nhạy cảm (sức khỏe, tài chính, mỹ phẩm...).

## 8. Kết nối
- Setup pixel/tracking: brandformance-ads-tracking-setup.
- Test hook/creative/audience/offer trước khi scale: brandformance-ads-testing (dùng Symphony để tạo biến thể).
- Creative cho video ads: brandformance-content-script (`references/short-video-playbook.md` — hook, phễu).
