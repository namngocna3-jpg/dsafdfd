---
name: brandformance-report
description: "Kích hoạt khi cần báo cáo marketing tổng thể cho founder/CEO — tổng hợp Brand Health và Performance Health thành 1 bức tranh, kèm narrative và ưu tiên hành động. Trigger: 'báo cáo tổng thể', 'report tổng quan marketing', 'brand health performance health', 'báo cáo tháng cho founder', 'tổng kết marketing quý này'. Kích hoạt khi cần trình bày cho người không chuyên sâu về marketing."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Report Tổng Thể

## 1. Triggers

### Explicit triggers
- "báo cáo marketing tổng thể", "report cho founder/CEO"
- "brand health vs performance health", "tổng kết marketing quý"

### Implicit triggers
- Kết thúc chu kỳ lớn (tháng/quý) cần trình bày cho người ra quyết định
- Đã có các report con (content, ads, email) nhưng chưa ai ghép lại thành bức tranh chung
- Founder hỏi "tổng thể marketing đang ổn không" — cần câu trả lời tổng hợp, không phải từng số liệu rời rạc

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Data từ tất cả kênh trong kỳ (ads, content, email...)
- [ ] **[BẮT BUỘC]** Mục tiêu ban đầu của kỳ đó
- [ ] **[NẾU CÓ]** Các report con đã có: `brandformance-content-report`, `brandformance-ads-report`, `brandformance-email-report`

Đọc trước khi thực hiện:
- Toàn bộ 5 Knowledge Docs (`brandformance-framework.md`, `-customer.md`, `-content.md`, `-ads.md`, `-measurement.md`)
- Các report con nếu đã tồn tại

## 3. Execution Steps

### Bước 1: Tổng hợp từ report con hoặc thu thập trực tiếp
Nếu đã có content-report, ads-report, email-report → dùng làm nguồn chính, không phân tích lại từ đầu. Nếu chưa có → thu thập trực tiếp theo từng kênh.

### Bước 2: Đánh giá riêng Brand Health và Performance Health
**Brand Health** (khó đo bằng tiền, nhưng đo được bằng xu hướng):
- Reach tự nhiên, follower growth, brand search volume (nếu có Google Trends)
- Tỉ lệ engagement thực (comment/save, không phải chỉ like)
- Sentiment từ comment/inbox (tích cực/tiêu cực/trung lập)

**Performance Health** (đo trực tiếp bằng số):
- CPL, ROAS, MER, CAC, tỉ lệ chốt so với mục tiêu

Hai trục này KHÔNG cộng gộp thành 1 điểm duy nhất — phải trình bày song song để thấy rõ brand đang mạnh/yếu ở đâu so với performance.

### Bước 3: Build Brandformance Scorecard
| Trục | Chỉ số | Kỳ này | Kỳ trước | Target | Đánh giá |
|---|---|---|---|---|---|
| Brand | Reach tự nhiên | | | | ✓/⚠️/✗ |
| Brand | Follower growth | | | | |
| Performance | CPL | | | | |
| Performance | ROAS/MER | | | | |

### Bước 4: Xác định narrative tổng thể
Không chỉ liệt kê số — kể câu chuyện: "Tháng này Brand mạnh lên rõ (reach +40%) nhưng Performance chưa theo kịp (CPL tăng nhẹ) — vì audience mới đến từ TOFU chưa đủ warm để convert ngay, đây là hiện tượng bình thường ở giai đoạn brand-building."

### Bước 5: Đề xuất 3 ưu tiên cho kỳ tới
Không đưa ra 10 đề xuất — chọn đúng 3 việc quan trọng nhất, xếp theo impact.

### Bước 6: Build Executive Report
Ngắn gọn, dễ hiểu cho người không chuyên sâu marketing: Tóm tắt 3-5 câu → Scorecard → Narrative → 3 ưu tiên.

## 4. Examples

### Example 1 — Generic: Spa làm đẹp (báo cáo tháng cho founder)
```
TÓM TẮT: Tháng 7, Brand Health cải thiện rõ rệt (reach tự nhiên +45%, follower +800) nhờ
chiến lược Founder Content mới. Performance Health giữ ổn định (CPL 180K, đạt target).
Doanh thu đạt 92% mục tiêu — thiếu 8% do 1 tuần giữa tháng ads bị gián đoạn kỹ thuật.

SCORECARD:
Brand: Reach tự nhiên 15K → 22K (+45%) ✓ | Follower +800 ✓
Performance: CPL 180K (target 200K) ✓ | ROAS 3.5x (target 3x) ✓ | Doanh thu 184tr/200tr ⚠️

NARRATIVE: Brand đang xây tốt và bắt đầu chuyển hóa thành lead chất lượng hơn — CPL thấp hơn
target dù không tăng ngân sách. Vấn đề duy nhất là gián đoạn kỹ thuật, không phải chiến lược sai.

3 ƯU TIÊN THÁNG TỚI:
1. Fix quy trình để tránh gián đoạn ads (đặt người backup theo dõi hàng ngày)
2. Nhân rộng Founder Content — đang là driver chính của Brand Health
3. Test tăng ngân sách BOFU Retarget 20% vì đang có dư địa (ROAS tốt hơn target)
```

### Example 2 — Giáo dục: Trung tâm ngoại ngữ (báo cáo quý)
```
TÓM TẮT: Quý 3, Performance Health rất tốt (CPA giảm 25% so với quý trước) nhưng Brand Health
đang chững lại (follower growth chỉ +5%, thấp hơn quý trước +18%).

NARRATIVE: Team đang tập trung toàn lực vào Ads tối ưu (đúng vì mùa tựu trường) nhưng
gần như dừng hẳn content TOFU tự nhiên trong 6 tuần — dẫn đến audience mới không tăng,
sẽ ảnh hưởng CPL trong 1-2 tháng tới khi tệp warm hiện tại cạn dần.

3 ƯU TIÊN QUÝ TỚI:
1. Khôi phục lịch content TOFU tối thiểu 3 bài/tuần ngay tháng đầu quý mới
2. Giữ nguyên chiến lược Ads đang hiệu quả, không thay đổi
3. Setup Lead Scoring để không phải đánh đổi giữa số lượng và chất lượng lead
```

## 5. Edge Cases & Error Handling

**Brand Health tốt nhưng Performance yếu**: Bình thường ở giai đoạn xây dựng — không hoảng loạn cắt ngân sách content, nhưng cần theo dõi xem Performance có cải thiện theo sau 1-2 chu kỳ không.

**Performance tốt nhưng Brand Health yếu dần**: Cảnh báo dài hạn — hiện tại ổn nhưng CPL sẽ tăng dần khi audience bão hòa nếu không đầu tư lại vào brand.

**Thiếu data 1 trong 2 trục**: Nêu rõ, không suy diễn — báo cáo tổng thể vẫn có giá trị dù thiếu 1 phần, miễn là minh bạch về giới hạn.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `DATA_AGGREGATE` | Tổng hợp từ report con hoặc trực tiếp |
| `HEALTH_SPLIT` | Đánh giá riêng Brand vs Performance Health |
| `SCORECARD_BUILD` | Build Brandformance Scorecard |
| `NARRATIVE` | Xây câu chuyện tổng thể |
| `PRIORITIZE` | Chọn 3 ưu tiên kỳ tới |
| `DONE` | Executive Report hoàn chỉnh |

## References
- `brandformance-content-report.md`, `brandformance-ads-report.md`, `brandformance-email-report.md` → Nguồn dữ liệu con
- `brandformance-measurement.md` → Toàn bộ
- `brandformance-campaign-retrospective.md` → Bước tiếp theo sau report này nếu gắn với 1 campaign cụ thể
