---
name: brandformance-content-script
description: >
  Viết script video TikTok/Reels/YouTube Shorts theo cấu trúc Hook→Body→CTA. Kích hoạt khi: "script TikTok", "kịch bản video", "viết script", "content script", "script Reels", "script YouTube Shorts", "hook video", "brief kịch bản", "script video ngắn".
---

## 📎 Tư liệu chuyên sâu (đọc khi cần, tự động)
Khi làm script/kịch bản video ngắn hoặc cần tactic sâu, LUÔN đọc thêm 2 file sau bằng Read tool (tài liệu chuyên gia đã distil):
- `references/short-video-playbook.md` — tư duy 3s/2 pha não, content theo phễu, công thức hook, thuật toán TikTok, lộ trình 30 ngày, sai lầm người mới.
- `references/ai-video-heygen.md` — sản xuất & nhân bản video-AI hàng loạt (Avatar, UGC, PDF-to-Video, đa ngôn ngữ) khi cần scale.

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: content</summary>

# brandformance-content

> Kiến thức về hệ thống nội dung Brandformance — đọc trước khi chạy bất kỳ skill content hoặc community.

## I. 4 Content Pillar theo mục đích phễu

Pillar 1: Nhận diện & Thu hút (TOFU) — không đề cập sản phẩm trực tiếp
Pillar 2: Giáo dục & Tin tưởng (MOFU) — đề cập sản phẩm gián tiếp
Pillar 3: Chuyển đổi (BOFU) — CTA rõ, offer cụ thể
Pillar 4: Giữ chân & Referral — nuôi dưỡng KH cũ

## II. Trục nội dung

Công thức: Trục nội dung = Mục tiêu truyền thông × Vấn đề KH × Thế mạnh thương hiệu

## III. Nguồn sản xuất content

FGC (Founder Generated Content) — lợi thế SME lớn nhất
BGC (Brand Generated Content) — kênh brand chính thức
EGC (Employee Generated Content) — nhân sự nội bộ
UGC (User Generated Content) — KH thật tạo content
KOC/KOL — người review trả phí

## IV. Ma trận content theo 3 tầng phễu

TOFU: Brand 80% / Perf 20% — CPM, View Rate
MOFU: Brand 50% / Perf 50% — CTR, CPL
BOFU: Brand 30% / Perf 70% — CPA, Conversion Rate

## V. Hook → Lead Magnet → Offer

Hook: thu hút attention (mọi giai đoạn)
Lead Magnet: đổi info lấy tài nguyên giá trị
Offer: gói SP/DV kèm giá trị, giảm rào cản ra quyết định
Chuỗi: Hook → LM → Thank-you page → Email/Zalo nurture → Core Offer → Retarget

## VI. Target bằng content

Target rộng + content nói đúng vấn đề cụ thể = content gạn lọc người phù hợp.
Bỏ target sâu theo hành vi/sở thích truyền thống (ngày càng sai lệch, đắt).

## VII. Content Funnel đa kênh

Facebook/Instagram: Reach + Conversion
TikTok: TOFU, viral, khám phá
Zalo OA: Nurture, retention — 2 loại tin khác nhau: **Broadcast** (quảng cáo, cần follower đồng ý, giới hạn 2-3 lần/tuần để tránh giảm follow rate) và **ZNS** (Zalo Notification Service — giao dịch/xác nhận đơn/lịch hẹn, không phải quảng cáo, độ tin cậy cao hơn). Nội dung phải ngắn, trực tiếp hơn Email vì thói quen kiểm tra Zalo nhiều lần/ngày.
Email: Nurture sequence, conversion — phù hợp nội dung sâu, case study dài mà Zalo không phù hợp.
Group/Forum: Seeding, social proof
Kênh Founder: Trust building, FGC

## VIII. Community — kênh Retention/Referral

Community không phải kênh acquisition, đừng đo bằng lead ngay. 3 loại theo tầng phễu:
- **TOFU (Open)**: giáo dục, growth-focused — đo bằng reach/growth, không kỳ vọng chuyển đổi cao
- **MOFU (Semi-closed)**: Q&A, poll — đo bằng tỉ lệ tham gia + chuyển đổi nhẹ sang lead
- **BOFU (Closed, chỉ KH đã mua)**: đo bằng tỉ lệ tham gia hoạt động + referral phát sinh + repeat purchase

Quy tắc nội dung trong community: 80% giá trị thật / 20% soft mention sản phẩm — vi phạm tỉ lệ này, community sẽ giống spam và mất tương tác thật.

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Content Script

## 1. Triggers
- "viết script video TikTok/Reels", "kịch bản video", "hook video"
- User mô tả idea video → cần script hóa; Video thấp view → hook yếu

## 2. Context Requirements
- [ ] **[BẮT BUỘC]** Topic / idea của video
- [ ] **[BẮT BUỘC]** Tầng phễu: TOFU / MOFU / BOFU
- [ ] **[BẮT BUỘC]** Độ dài target (15s / 30s / 60s / 90s)
- [ ] **[NẾU CÓ]** Brand Voice, KH mục tiêu

## 3. Execution Steps

### Bước 1: Xác định Hook (3-5 giây đầu)
6 loại hook:
1. Pain: "Sao [vấn đề X] vẫn không hết dù đã thử..."
2. Curiosity: "Điều này sẽ thay đổi cách bạn nghĩ về [X]"
3. Contradiction: "Tại sao làm đúng mà vẫn thất bại?"
4. Number: "3 lý do [X] không work với hầu hết người"
5. Story: "Tháng trước tôi đã [tình huống cụ thể]..."
6. Question: "Bạn có đang mắc [lỗi X] không?"

TOFU: Pain + Curiosity + Contradiction hiệu quả nhất.
MOFU/BOFU: Story + Social proof hiệu quả hơn.

### Bước 2: Xây dựng Body (80% thời lượng)

**TOFU Body**: Problem → Insight → Tease solution
- Không bán hàng, không mention sản phẩm
- Value thật: insight, knowledge
- Kết thúc: gợi mở, KH tự muốn biết thêm

**MOFU Body**: Problem → Solution → Proof
- Mention sản phẩm QUA kết quả, không phải tính năng
- Social proof cụ thể (số, tên, trước/sau)

**BOFU Body**: Problem reminder → Solution → Offer → Urgency
- CTA rõ ràng, một lần; Urgency thật

Pace: 1 ý = 1-2 câu. Ghi visual note bên cạnh mỗi đoạn.

### Bước 3: CTA
- TOFU: "Follow để xem thêm" / "Save lại" / "Comment [keyword]"
- MOFU: "Inbox tôi để biết [X]" / "Link bio"
- BOFU: "[Action cụ thể] trước [deadline]"

### Bước 4: Format script
```
[HOOK — 0-3s]
Text: [Câu hook]
Visual: [Cảnh quay]

[BODY — 3s đến X]
Text: [Câu 1]
Visual: [...]

[CTA — X đến cuối]
Text: [CTA]
```

## 4. Examples

### Example 1 — Generic: TOFU 60s dịch vụ website
```
SCRIPT: Tại sao website đẹp vẫn không ra KH? (60s TOFU)

[HOOK] "Website của bạn đẹp nhưng không ra KH — đây là lý do thật sự"
Visual: Google Analytics bounce rate 90%

[BODY]
"Hầu hết SME nghĩ vấn đề là website chưa đẹp đủ..."
"Nhưng thực ra 3 lý do phổ biến là:"
"1 — Không có CTA rõ. KH vào không biết làm gì"
"2 — Load quá chậm. Mỗi giây trễ = 7% KH bỏ đi"
"3 — Không nói đúng điều KH cần trong 5 giây đầu"
"Fix 3 điểm này trước khi nghĩ đến redesign"

[CTA] "Save video này. Comment 'Website' tôi gửi checklist"
Nhạc: Upbeat 120BPM / Hashtag: #webdesign #marketing
```

### Example 2 — Giáo dục: MOFU 30s IELTS
```
SCRIPT: Học viên 5.5 → 7.0 trong 3 tháng (30s MOFU)

[HOOK] "Chị Lan thi IELTS 4 lần dưới 6.0. Lần thứ 5 có gì khác?"
Visual: Chị Lan cầm kết quả 7.0

[BODY]
"Không phải học nhiều hơn..."
"Mà tập trung đúng kỹ năng yếu: Reading timed practice"
"Sau 3 tháng — Reading tăng từ 5.0 lên 7.5"
Visual: Score before/after

[CTA] "Link trial class miễn phí ở bio — thử trước quyết định sau"
```

## 5. Edge Cases & Error Handling

**Case 1: Hook không đủ mạnh**
→ Đọc hook một mình — tò mò không? Nếu không → viết lại.

**Case 2: Body quá dài**
→ 1 video = 1 insight chính. Nhiều ý → series video.

**Case 3: Script BOFU nhưng audience cold**
→ BOFU script không work với cold audience.
→ Retarget BOFU chỉ target warm audience.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `HOOK_WRITING` | Viết 3 hook options |
| `BODY_BUILDING` | Viết Body theo tầng |
| `CTA_WRITING` | Viết CTA phù hợp |
| `FORMATTING` | Format script hoàn chỉnh |
| `DONE` | Deliver |

## References
- `brandformance-content.md` → Phần III (Hook framework)
- `brandformance-customer.md` → Phần III (Câu nói nội tâm = nguồn hook tốt nhất)

Hook tốt: Dừng scroll vì TÒ MÒ hoặc VÌ HỌ.
Hook tệ: Bắt đầu bằng "Hôm nay tôi sẽ chia sẻ..." hay tên brand.
