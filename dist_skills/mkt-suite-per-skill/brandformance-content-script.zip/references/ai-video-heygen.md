# Sản xuất Video-AI toàn diện với HeyGen (Blueprint)
Distil từ "Nội Dung Video AI — HeyGen Blueprint" (TAS / Chiến Binh Fullstack Marketing).

Dùng khi cần sản xuất video số lượng lớn, cá nhân hoá, hoặc đa ngôn ngữ mà không cần studio/diễn viên thật.

## Studio Video-AI "All in one" — 4 trụ
1. **Sản xuất nội dung:** tạo Avatar Podcast chuyên nghiệp + video UGC (review) tự nhiên để tối ưu quảng cáo.
2. **Mở rộng quy mô:** Batch Mode (sản xuất hàng loạt) + PDF-to-Video (chuyển tài liệu thành video nhanh).
3. **Toàn cầu hoá:** dịch đa ngôn ngữ tự động + Lip-sync đồng bộ khẩu hình.
4. **Tương tác realtime:** LiveAvatar đối thoại trực tiếp — nâng trải nghiệm CSKH.

## Casting diễn viên ảo hyper-realistic
- **Tạo sinh Avatar:** MC ảo chân thực cao, bỏ chi phí thuê diễn viên.
- **Custom Photo:** biến ảnh tĩnh thành video nói chuyện.
- **Face Swap:** đổi diện mạo nhân vật cho hợp định vị thương hiệu.

## Định dạng chủ lực
- **Avatar Podcast (long-form):** tự động tạo hội thoại giữa 2 diễn viên ảo — giải bài toán content dài không cần studio.
- **UGC Ad Video:** video review sản phẩm chân thực, tối ưu cho TikTok / Facebook Reels / Instagram → tăng chuyển đổi nhờ nội dung gần gũi, cá nhân hoá.

## Khi nào dùng
Kết hợp với `short-video-playbook.md`: dùng framework hook/phễu/kịch bản của video ngắn, rồi HeyGen để **sản xuất & nhân bản** hàng loạt (nhiều biến thể UGC để test creative, hoặc bản đa ngôn ngữ khi mở rộng thị trường).
