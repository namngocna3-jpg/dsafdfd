# Playbook Video Ngắn bán hàng (TikTok / Reels / YouTube Shorts)
Distil từ khoá "Bùng nổ doanh thu với Video ngắn" — Chiến Binh Fullstack Marketing (GV Việt Ngô).

## 1. Tư duy nền: vì sao video ngắn bán được
- **3 giây đầu quyết định:** giữ chân được thì thuật toán mới đẩy tiếp. Hook yếu = lướt = sản phẩm không có cơ hội xuất hiện.
- **Não người xử lý theo 2 pha:** Pha 1 (0–3s) phản ứng **cảm xúc** (tò mò, đồng cảm, bực bội, thích thú); Pha 2 (3–10s trở đi) mới **phân tích logic** (đánh giá sản phẩm). ⇒ Không tạo cảm xúc ngay đầu → người xem lướt.
- **Sản phẩm chỉ là lý do — câu chuyện mới tạo lượt xem + chuyển đổi.** Người tiêu dùng không mua sản phẩm, họ mua **"lý do phải sở hữu nó"**.
- Trình tự đúng: **Cảm xúc bật trước → câu chuyện kích hoạt cảm xúc → mới đến sản phẩm.**

## 2. Ba kỹ năng cốt lõi của người làm video bán hàng
1. **Content Creator cho chính sản phẩm mình** — nội dung: kể chuyện, chân thực, có giá trị.
2. **Tư duy marketing cho thương hiệu** — brand, social, content, media (không chỉ quay cho vui).
3. **Phân tích hành vi mua trên nền tảng video** — TikTok/Reels/Shorts đều chạy trên tín hiệu video; không hiểu video ngắn = không hiểu hành vi tiêu dùng mới.

## 3. Thiết kế nội dung THEO PHỄU (mục đích → dạng video)
| Giai đoạn phễu | Mục đích | Dạng video |
|---|---|---|
| **Nhận biết (Awareness)** | Kéo người lạ | Brand intro, teaser/pre-order, unboxing, kể câu chuyện, yếu tố giải trí, "thử sự khác biệt" |
| **Cân nhắc (Consideration)** | Tạo tin tưởng | Product review (looker), user feedback, DIY/hướng dẫn dùng |
| **Chuyển đổi (Conversion)** | Chốt đơn | Seasonal promotion, demo tính năng + ưu đãi, video có CTA rõ |

## 4. Công thức HOOK (nhóm Thu hút — kéo người lạ)
Mẫu hook đã được chứng minh:
- "3 dấu hiệu bạn đang chọn sai [X]…"
- "90% người mua nhầm [X] vì…"
- "Đừng mua [X] nếu bạn thuộc nhóm này…"
Nguyên tắc: chạm nỗi đau/tò mò/phản biện trong ≤3 giây, có con số, gọi đúng tệp (không "cho tất cả mọi người").

## 5. Thuật toán TikTok (hiểu để tối ưu)
Dữ liệu tương tác người dùng + hồ sơ & biểu đồ sở thích → **học máy** → phân tích nội dung video (âm thanh, hình ảnh, phụ đề) → phân loại kho nội dung → đẩy lên **"Dành cho bạn" (FYP)** cá nhân hoá. ⇒ Tối ưu cả 3 tín hiệu: âm thanh (trend sound), hình ảnh (giữ chân), phụ đề (rõ keyword).

## 6. Lộ trình 30 ngày thực chiến
- **Tuần 1 — Khởi động:** lập kênh có mục tiêu rõ (chọn 1 mục tiêu chính, đừng "vừa viral vừa bán vừa brand"), xác định tệp khách.
- **Tuần 2 — "Tìm format thắng":** đăng đều 5–7 video/tuần, chọn ra **2 format** có tín hiệu tốt nhất (giữ chân + comment).
- **Tuần 3 — "Series hóa":** đẩy 1 series chủ lực (5–7 tập), bắt đầu Q&A trả lời comment.
- **Tuần 4 — "Gắn chuyển đổi nhẹ":** 2–3 video có CTA (xin tư vấn / nhận checklist / đặt lịch), tạo landing/form đơn giản + trả lời inbox.

## 7. Sai lầm người mới hay mắc (checklist tránh)
**Tư duy/mục tiêu:** mở kênh không mục tiêu; nhầm "nhiều view = ra đơn"; không hiểu tệp khách (làm cho "tất cả" → không chạm ai); bán lộ liễu ngay giây đầu; đổi hướng liên tục theo cảm hứng → thuật toán khó hiểu kênh.
**Nội dung:** hook yếu; dài dòng không vào thẳng vấn đề; không có lợi ích rõ ràng; thiếu proof (hình thật/kết quả/feedback); không làm series; chất lượng video thấp; copy trend 100% không gắn sản phẩm; chỉ làm 1 kiểu video → nhanh bão hoà; bỏ qua bình luận của người xem.
