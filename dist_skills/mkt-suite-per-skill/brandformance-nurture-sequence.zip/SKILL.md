---
name: brandformance-nurture-sequence
description: "Kích hoạt khi cần thiết kế chuỗi nuôi dưỡng lead đa kênh Email + Zalo OA theo hành vi và nhiệt độ. Trigger: 'chuỗi nuôi dưỡng', 'nurture sequence', 'chăm sóc lead chưa chuyển đổi', 'chuỗi Zalo OA', 'nuôi lead theo hành vi', 'lead im lặng phải làm sao', 'trigger theo nhiệt độ lead'."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Nurture Sequence

## 1. Triggers

### Explicit triggers
- "chuỗi nuôi dưỡng", "nurture sequence", "chăm sóc lead"
- "lead im lặng phải làm sao?", "chuỗi Zalo OA"
- "trigger theo nhiệt độ lead", "nuôi lead theo hành vi"

### Implicit triggers
- Lead vào phễu nhiều nhưng phần lớn "nguội" dần vì không ai follow-up đúng lúc
- Email Plan đã có nhưng chỉ chạy theo lịch cố định — không phản ứng theo hành vi thực tế
- Lead xem pricing/hỏi giá rồi biến mất, không có cơ chế kéo lại

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Nguồn lead và các hành vi đang track được
- [ ] **[BẮT BUỘC]** Customer Insight 3 nhóm Cold/Warm/Hot đã có
- [ ] **[BẮT BUỘC]** Kênh đang dùng: Email / Zalo OA / cả hai
- [ ] **[NẾU CÓ]** Tỉ lệ mở, CTR hiện tại

## 3. Execution Steps

### Bước 1: Phân biệt Nurture Sequence với Email Plan
Email Plan = lịch cố định theo ngày. Nurture Sequence = phản ứng theo **hành vi thực tế**, không theo lịch. Một lead có thể nhảy thẳng vào chuỗi Hot nếu vừa xem pricing 2 lần trong 1 ngày.

### Bước 2: Xây Trigger Map theo nhiệt độ

**Trigger Cold → Warm:**
- Mở email 2 lần liên tiếp → gửi thêm 1 case study
- Click vào 1 bài blog/case study → gắn tag quan tâm chủ đề đó

**Trigger Warm → Hot:**
- Xem pricing page ≥1 lần → gửi FAQ + risk reversal trong 24h
- Hỏi giá qua inbox rồi im lặng → follow-up sau 2 ngày với objection-handling content

**Trigger Im lặng (Re-engagement):**
- Không mở email 14 ngày → gửi "win-back" content, đổi chủ đề khác hẳn
- Không mở email 30 ngày → chuyển sang list riêng, giảm tần suất

### Bước 3: Phân vai kênh Email vs Zalo OA
- **Email**: nội dung sâu, case study dài, sequence giáo dục
- **Zalo OA**: ngắn gọn, urgency, phù hợp thói quen kiểm tra thường xuyên của người Việt
- Không gửi cùng nội dung trùng lặp trên 2 kênh cùng ngày

### Bước 4: Viết message theo từng trigger
Mỗi message giữ tỉ lệ Brand/Performance đúng theo nhiệt độ. Không phải mọi trigger đều là bán hàng.

### Bước 5: Exit conditions và escalation sang Sales
- Lead đạt ngưỡng Hot → escalate cho Sales gọi trong 24h, dừng nurture tự động
- Lead mua hàng → chuyển sang Retention sequence
- Lead unsubscribe → dừng ngay

### Bước 6: Build Nurture Flow document

| Trigger | Kênh | Delay | Mục tiêu message | Điều kiện thoát |
|---|---|---|---|---|
| Xem pricing 2 lần | Zalo OA | Ngay | FAQ + risk reversal | Đã inbox hỏi giá |
| Không mở email 14 ngày | Email | — | Win-back content khác chủ đề | Mở lại email |
| Hỏi giá rồi im lặng | Email + Zalo | 48h | Objection handling + case study | Trả lời hoặc mua |

## 4. Examples

### Example 1 — Dịch vụ tư vấn tài chính cá nhân
```
TRIGGER MAP:
Đăng ký Lead Magnet → Email Welcome (ngay) → Case study Ngày 3
Xem pricing page → Zalo OA ngay: "Anh/chị đang cân nhắc gói nào? Em gửi bảng so sánh nhé"
Không phản hồi Zalo 3 ngày → Email: "3 câu hỏi khách hàng hay hỏi trước khi bắt đầu"

ESCALATION: Click link "Đặt lịch tư vấn" → Sales gọi trong 2h, dừng nurture
```

### Example 2 — Khóa học tiếng Anh online
```
TRIGGER MAP:
Tải Lead Magnet → Email 1: Deliver + giới thiệu phương pháp
Click vào email 2 lần nhưng chưa hỏi gì → Zalo OA: "Tài liệu có hữu ích không ạ?"
Đăng ký học thử nhưng không tham gia → Email: "Bạn bận quá à? Đây là link xem lại buổi học thử"
Tham gia học thử, không mua → Zalo OA sau 24h: "Ưu đãi học thử chỉ còn hôm nay"
```

## 5. Edge Cases & Error Handling

**Lead im lặng hoàn toàn sau mọi nurture attempt**: Sau 60 ngày → chuyển vào list "Cold storage", dừng nurture chủ động.
**Lead re-engage sau thời gian dài**: Coi như lead mới — bắt đầu lại từ trigger phù hợp.
**Gửi trùng lặp đa kênh**: Kiểm tra "đã gửi gì trong 48h qua trên kênh khác" trước khi trigger thêm.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `TRIGGER_MAPPING` | Xây trigger map theo nhiệt độ |
| `CHANNEL_SPLIT` | Phân vai Email vs Zalo OA |
| `MESSAGE_WRITING` | Viết message theo trigger |
| `EXIT_RULES` | Xác định exit + escalation |
| `DONE` | Nurture Flow document hoàn chỉnh |

## References
- `brandformance-email-plan.md` → Welcome/BOFU sequence theo lịch
- `brandformance-customer.md` → Phần IV (3 nhóm KH)
- `brandformance-lead-scoring.md` → Ngưỡng escalate sang Sales
