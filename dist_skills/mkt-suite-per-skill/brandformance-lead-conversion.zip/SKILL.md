---
name: brandformance-lead-conversion
description: "Kích hoạt khi cần viết script tư vấn/chốt sale và xử lý objection theo tư duy Brandformance. Trigger: 'script tư vấn', 'script chốt sale', 'xử lý objection', 'lead không chốt', 'script trả lời inbox', 'khách hỏi giá rồi im lặng', 'chuyển đổi lead thành khách hàng'."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: content</summary>

# brandformance-content

> Kiến thức về hệ thống nội dung Brandformance — đọc trước khi chạy bất kỳ skill content hoặc community.

## I. 4 Content Pillar theo mục đích phễu

Pillar 1: Nhận diện & Thu hút (TOFU) — không đề cập sản phẩm trực tiếp
Pillar 2: Giáo dục & Tin tưởng (MOFU) — đề cập sản phẩm gián tiếp
Pillar 3: Chuyển đổi (BOFU) — CTA rõ, offer cụ thể
Pillar 4: Giữ chân & Referral — nuôi dưỡng KH cũ

## II. Trục nội dung

Công thức: Trục nội dung = Mục tiêu truyền thông × Vấn đề KH × Thế mạnh thương hiệu

## III. Nguồn sản xuất content

FGC (Founder Generated Content) — lợi thế SME lớn nhất
BGC (Brand Generated Content) — kênh brand chính thức
EGC (Employee Generated Content) — nhân sự nội bộ
UGC (User Generated Content) — KH thật tạo content
KOC/KOL — người review trả phí

## IV. Ma trận content theo 3 tầng phễu

TOFU: Brand 80% / Perf 20% — CPM, View Rate
MOFU: Brand 50% / Perf 50% — CTR, CPL
BOFU: Brand 30% / Perf 70% — CPA, Conversion Rate

## V. Hook → Lead Magnet → Offer

Hook: thu hút attention (mọi giai đoạn)
Lead Magnet: đổi info lấy tài nguyên giá trị
Offer: gói SP/DV kèm giá trị, giảm rào cản ra quyết định
Chuỗi: Hook → LM → Thank-you page → Email/Zalo nurture → Core Offer → Retarget

## VI. Target bằng content

Target rộng + content nói đúng vấn đề cụ thể = content gạn lọc người phù hợp.
Bỏ target sâu theo hành vi/sở thích truyền thống (ngày càng sai lệch, đắt).

## VII. Content Funnel đa kênh

Facebook/Instagram: Reach + Conversion
TikTok: TOFU, viral, khám phá
Zalo OA: Nurture, retention — 2 loại tin khác nhau: **Broadcast** (quảng cáo, cần follower đồng ý, giới hạn 2-3 lần/tuần để tránh giảm follow rate) và **ZNS** (Zalo Notification Service — giao dịch/xác nhận đơn/lịch hẹn, không phải quảng cáo, độ tin cậy cao hơn). Nội dung phải ngắn, trực tiếp hơn Email vì thói quen kiểm tra Zalo nhiều lần/ngày.
Email: Nurture sequence, conversion — phù hợp nội dung sâu, case study dài mà Zalo không phù hợp.
Group/Forum: Seeding, social proof
Kênh Founder: Trust building, FGC

## VIII. Community — kênh Retention/Referral

Community không phải kênh acquisition, đừng đo bằng lead ngay. 3 loại theo tầng phễu:
- **TOFU (Open)**: giáo dục, growth-focused — đo bằng reach/growth, không kỳ vọng chuyển đổi cao
- **MOFU (Semi-closed)**: Q&A, poll — đo bằng tỉ lệ tham gia + chuyển đổi nhẹ sang lead
- **BOFU (Closed, chỉ KH đã mua)**: đo bằng tỉ lệ tham gia hoạt động + referral phát sinh + repeat purchase

Quy tắc nội dung trong community: 80% giá trị thật / 20% soft mention sản phẩm — vi phạm tỉ lệ này, community sẽ giống spam và mất tương tác thật.

</details>

---

# Lead Conversion

## 1. Triggers

### Explicit triggers
- "script tư vấn/chốt sale", "xử lý objection"
- "khách hỏi giá rồi im lặng", "script trả lời inbox"

### Implicit triggers
- Lead nhiều, inbox nhiều nhưng tỉ lệ chốt thấp (< 10%)
- Sale mới chưa quen cách trả lời, cần script chuẩn
- Khách hay so sánh giá với đối thủ rồi biến mất
- Lead đạt SQL cần script để chốt

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Core Offer + giá cụ thể
- [ ] **[BẮT BUỘC]** Kênh tư vấn: inbox / gọi điện / gặp trực tiếp
- [ ] **[NẾU CÓ]** 3-5 objection thường gặp nhất từ data cũ
- [ ] **[NẾU CÓ]** Tỉ lệ chốt hiện tại và script cũ để cải thiện

## 3. Execution Steps

### Bước 1: Xác định điểm vào của lead conversion
Lead đến từ đâu ảnh hưởng đến cách mở đầu: từ ads inbox trực tiếp (chưa qualify) khác với lead đã qua Tripwire (đã có trust nhất định).

### Bước 2: Script framework theo 5 giai đoạn
```
1. MỞ ĐẦU — Qualify nhanh (không hỏi dồn dập)
 "Chào [tên], mình thấy bạn quan tâm [sản phẩm] — bạn đang gặp vấn đề gì để mình tư vấn đúng nhất?"

2. ĐÀO SÂU VẤN ĐỀ
 Đặt 1-2 câu hỏi mở để hiểu đúng tình huống, không vội present offer

3. PRESENT OFFER ĐÚNG INSIGHT
 Chỉ nói phần offer liên quan trực tiếp đến vấn đề vừa nghe — không đọc hết bảng giá

4. XỬ LÝ OBJECTION
 (xem Bước 3)

5. CLOSE
 CTA rõ ràng, một hành động cụ thể, có deadline hợp lý — không mập mờ
```

### Bước 3: Framework xử lý Objection — Nghe → Đồng cảm → Reframe → Bằng chứng → Hỏi lại

**Objection "Giá cao quá":**
- Nghe: để khách nói hết, không cắt ngang
- Đồng cảm: "Mình hiểu, đây là khoản đầu tư cần cân nhắc"
- Reframe: quy đổi giá theo giá trị/thời gian tiết kiệm được, không giảm giá ngay
- Bằng chứng: case study KH tương tự đã đầu tư và có kết quả gì
- Hỏi lại: "Nếu giá không phải vấn đề, điều gì khiến bạn còn băn khoăn?"

**Objection "Để suy nghĩ thêm":**
- Thường là lời từ chối lịch sự — hỏi thẳng: "Được ạ, để mình hỗ trợ đúng — bạn đang cân nhắc điều gì cụ thể?"

**Objection "Đối thủ rẻ hơn":**
- Không nói xấu đối thủ — làm rõ sự khác biệt cụ thể và để KH tự so sánh

### Bước 4: Tripwire → Core Offer bridge script
Nếu KH đã mua Tripwire: "Sau khi trải nghiệm [Tripwire], đây là bước tiếp theo phù hợp để [kết quả đầy đủ]..."

### Bước 5: Follow-up cadence cho lead chưa chốt ngay
- Ngày 1: Follow-up nhẹ, không lặp lại y hệt tin nhắn cũ
- Ngày 3: Gửi thêm bằng chứng mới (case study khác)
- Ngày 7: Câu hỏi trực tiếp cuối cùng trước khi chuyển sang nurture dài hạn

### Bước 6: Build script document + tracking sheet
Theo dõi: Objection nào gặp nhiều nhất, tỉ lệ chốt theo từng loại objection → dùng để cải thiện script định kỳ.

## 4. Examples

### Example 1 — Dịch vụ thiết kế nội thất
```
MỞ ĐẦU: "Chào anh, em thấy anh quan tâm gói thiết kế trọn gói — anh đang làm nhà mới hay cải tạo ạ?"
ĐÀO SÂU: "Anh đang gặp khó khăn gì nhất — chọn phong cách, ngân sách, hay tiến độ thi công?"
OFFER: Present đúng gói phù hợp với diện tích + ngân sách anh vừa chia sẻ

OBJECTION "Giá cao": "Em hiểu đây là khoản đầu tư lớn. Gói này bao gồm cả giám sát thi công —
tránh phát sinh chi phí do sai sót, nhiều khách tiết kiệm được 15-20%. Chị Hoa làm nhà 80m² năm
ngoái ban đầu cũng cân nhắc y như anh, giờ chị rất hài lòng — em gửi ảnh thực tế nhé."

CLOSE: "Để giữ lịch khảo sát tuần này, anh xác nhận giúp em trước thứ 5 nhé — slot khảo sát miễn phí có hạn."
```

### Example 2 — Khóa học IELTS
```
MỞ ĐẦU: "Chào em, em đang target band mấy và thi khi nào để chị tư vấn đúng lộ trình?"
ĐÀO SÂU: "Em đã thi thử chưa, kỹ năng nào em thấy yếu nhất?"

OBJECTION "Để em suy nghĩ thêm": "Dạ được, để chị hỗ trợ đúng hơn — em đang băn khoăn về
lộ trình có phù hợp không, hay về thời gian sắp xếp học ạ?"

OBJECTION "Trung tâm khác rẻ hơn": "Chị hiểu em đang so sánh. Khác biệt ở đây là lớp tối đa 8 người
và có theo dõi tiến độ riêng từng bạn. Em có thể tham gia buổi học thử miễn phí để tự đánh giá."

CLOSE: "Lớp tháng này còn 3 slot, chị giữ chỗ cho em đến hết tuần này nhé?"
```

## 5. Edge Cases & Error Handling

**Lead ghost hoàn toàn sau khi hỏi giá**: Follow-up tối đa 3 lần theo cadence, sau đó chuyển vào nurture-sequence.
**Sale mới chưa quen xử lý objection**: Luyện tập với script mẫu trước, ghi âm/review cuộc gọi thật.
**Khách so sánh giá công khai trong nhóm/comment**: Trả lời ngắn gọn, chuyển về inbox riêng.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `QUALIFY` | Xác định điểm vào + qualify nhanh |
| `SCRIPT_BUILD` | Xây script 5 giai đoạn |
| `OBJECTION_HANDLING` | Framework xử lý objection cụ thể |
| `FOLLOWUP_CADENCE` | Thiết kế follow-up |
| `TRACKING` | Setup tracking objection/tỉ lệ chốt |
| `DONE` | Deliver script document |

## References
- `brandformance-customer.md` → Phần III (câu nói nội tâm nhóm Nóng)
- `brandformance-offer-design.md` → Tripwire → Core Offer
- `brandformance-lead-scoring.md` → Lead đạt SQL mới áp dụng script này
- `brandformance-nurture-sequence.md` → Lead chưa chốt ngay
