---
name: brandformance-brand-bible
description: "Kích hoạt khi cần tạo hoặc cập nhật Brand Bible theo tư duy Brandformance — tài liệu nền tảng định nghĩa voice, tone, personality và từ điển thương hiệu. Trigger: 'tạo brand bible', 'brand voice', 'tone of voice', 'tài liệu thương hiệu', 'từ được/cấm dùng', 'brand guidelines', 'định hướng content', 'viết content sao cho đúng brand', 'brand personality'. Kích hoạt cả khi content/ads bị nhận xét là không đúng tone brand, hoặc khi chuẩn bị launch campaign mà chưa có tài liệu thương hiệu."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: content</summary>

# brandformance-content

> Kiến thức về hệ thống nội dung Brandformance — đọc trước khi chạy bất kỳ skill content hoặc community.

## I. 4 Content Pillar theo mục đích phễu

Pillar 1: Nhận diện & Thu hút (TOFU) — không đề cập sản phẩm trực tiếp
Pillar 2: Giáo dục & Tin tưởng (MOFU) — đề cập sản phẩm gián tiếp
Pillar 3: Chuyển đổi (BOFU) — CTA rõ, offer cụ thể
Pillar 4: Giữ chân & Referral — nuôi dưỡng KH cũ

## II. Trục nội dung

Công thức: Trục nội dung = Mục tiêu truyền thông × Vấn đề KH × Thế mạnh thương hiệu

## III. Nguồn sản xuất content

FGC (Founder Generated Content) — lợi thế SME lớn nhất
BGC (Brand Generated Content) — kênh brand chính thức
EGC (Employee Generated Content) — nhân sự nội bộ
UGC (User Generated Content) — KH thật tạo content
KOC/KOL — người review trả phí

## IV. Ma trận content theo 3 tầng phễu

TOFU: Brand 80% / Perf 20% — CPM, View Rate
MOFU: Brand 50% / Perf 50% — CTR, CPL
BOFU: Brand 30% / Perf 70% — CPA, Conversion Rate

## V. Hook → Lead Magnet → Offer

Hook: thu hút attention (mọi giai đoạn)
Lead Magnet: đổi info lấy tài nguyên giá trị
Offer: gói SP/DV kèm giá trị, giảm rào cản ra quyết định
Chuỗi: Hook → LM → Thank-you page → Email/Zalo nurture → Core Offer → Retarget

## VI. Target bằng content

Target rộng + content nói đúng vấn đề cụ thể = content gạn lọc người phù hợp.
Bỏ target sâu theo hành vi/sở thích truyền thống (ngày càng sai lệch, đắt).

## VII. Content Funnel đa kênh

Facebook/Instagram: Reach + Conversion
TikTok: TOFU, viral, khám phá
Zalo OA: Nurture, retention — 2 loại tin khác nhau: **Broadcast** (quảng cáo, cần follower đồng ý, giới hạn 2-3 lần/tuần để tránh giảm follow rate) và **ZNS** (Zalo Notification Service — giao dịch/xác nhận đơn/lịch hẹn, không phải quảng cáo, độ tin cậy cao hơn). Nội dung phải ngắn, trực tiếp hơn Email vì thói quen kiểm tra Zalo nhiều lần/ngày.
Email: Nurture sequence, conversion — phù hợp nội dung sâu, case study dài mà Zalo không phù hợp.
Group/Forum: Seeding, social proof
Kênh Founder: Trust building, FGC

## VIII. Community — kênh Retention/Referral

Community không phải kênh acquisition, đừng đo bằng lead ngay. 3 loại theo tầng phễu:
- **TOFU (Open)**: giáo dục, growth-focused — đo bằng reach/growth, không kỳ vọng chuyển đổi cao
- **MOFU (Semi-closed)**: Q&A, poll — đo bằng tỉ lệ tham gia + chuyển đổi nhẹ sang lead
- **BOFU (Closed, chỉ KH đã mua)**: đo bằng tỉ lệ tham gia hoạt động + referral phát sinh + repeat purchase

Quy tắc nội dung trong community: 80% giá trị thật / 20% soft mention sản phẩm — vi phạm tỉ lệ này, community sẽ giống spam và mất tương tác thật.

</details>

---

# Brand Bible

## 1. Triggers

### Explicit triggers
- Người dùng yêu cầu: "tạo brand bible", "brand guidelines", "xây brand voice"
- Người dùng hỏi: "tone of voice nên như thế nào?", "từ nào được/không được dùng?"
- Người dùng cần: "định hướng content", "viết như thế nào cho đúng brand"
- Người dùng muốn: "cập nhật brand bible cũ", "review lại brand voice hiện tại"

### Implicit triggers
- Content hoặc caption bị nhận xét là "nghe như robot", "không đúng tone", "viết như ads rẻ tiền"
- Chuẩn bị launch campaign lớn nhưng team content viết không nhất quán
- Brand Bible cũ hơn 12 tháng hoặc doanh nghiệp vừa thay đổi định hướng
- Team mới gia nhập cần tài liệu tham chiếu khi viết
- Nhiều người viết content → mỗi bài ra một kiểu tone khác nhau

## 2. Context Requirements

Kiểm tra trước khi thực hiện. Thiếu mục BẮT BUỘC → dừng và hỏi ngay:

- [ ] **[BẮT BUỘC]** Tên thương hiệu + lĩnh vực kinh doanh chính
- [ ] **[BẮT BUỘC]** Sản phẩm/dịch vụ cụ thể đang bán và mức giá tương đối
- [ ] **[BẮT BUỘC]** Target audience chính (mô tả tối thiểu: ai, vấn đề gì, giai đoạn nào)
- [ ] **[BẮT BUỘC]** 2-4 tính từ mô tả cảm xúc/tính cách brand mà founder muốn
- [ ] **[NẾU CÓ]** 3-5 đối thủ cạnh tranh chính để tránh trùng lặp tone
- [ ] **[NẾU CÓ]** 1-2 ví dụ content đã làm TỐT — brand thấy đúng tone
- [ ] **[NẾU CÓ]** 1-2 ví dụ content KHÔNG muốn trông như vậy (của đối thủ hoặc của chính brand)

Đọc trước khi thực hiện:
- `brandformance-framework.md` → Phần II (Bản chất Brandformance), Phần III (Phễu 4 giai đoạn)
- `brandformance-customer.md` → Phần IV (3 nhóm KH), Phần III (Câu nói nội tâm)

## 3. Execution Steps

### Bước 1: Thu thập thông tin và xác định vị thế
1.1 Nếu thiếu thông tin bắt buộc → hỏi từng mục, không hỏi tất cả cùng lúc.
1.2 Tổng hợp ngữ cảnh: ngành, sản phẩm, giai đoạn kinh doanh (mới/tăng trưởng/ổn định).
1.3 Đọc "ngôn ngữ thật" của founder từ những gì họ đã mô tả — đây là nguyên liệu thô cho brand voice.
1.4 Xác định góc khác biệt: brand này khác đối thủ ở điểm gì?
1.5 Flag ngay nếu có mâu thuẫn (ví dụ: muốn "sang trọng" nhưng giá rất rẻ) → phải resolve trước khi tiếp tục.

### Bước 2: Định nghĩa Brand Personality (5 chiều)
2.1 Đánh giá brand trên 5 chiều theo thang 1-10:

| Chiều personality | Cực 1 (điểm 1) | Điểm | Cực 10 |
|---|---|---|---|
| Độ tuổi cảm xúc | Truyền thống, cổ điển | _/10 | Trẻ trung, hiện đại |
| Khoảng cách với KH | Chuyên gia xa cách | _/10 | Người bạn thân thiết |
| Độ nghiêm túc | Hài hước, nhẹ nhàng | _/10 | Nghiêm túc, chuyên nghiệp |
| Độ táo bạo | An toàn, dễ đoán | _/10 | Sáng tạo, phá cách |
| Phân khúc giá | Bình dân, đại chúng | _/10 | Premium, cao cấp |

2.2 Chọn đúng 5 tính từ mô tả brand personality — phải khác với đối thủ chính.
2.3 Với mỗi tính từ, viết 1 câu giải thích: "Điều này có nghĩa là brand sẽ [hành động cụ thể]..."
2.4 Kiểm tra consistency: 5 tính từ có "hài hòa" với nhau không?

### Bước 3: Xây dựng Brand Voice Matrix theo tầng phễu Brandformance

3.1 **TOFU (Awareness — KH Lạnh)**
- Mục tiêu tone: Chạm vào vấn đề KH chưa gọi được tên, tạo nhận diện brand
- Nguyên tắc: KHÔNG bán hàng, KHÔNG mention sản phẩm trực tiếp
- Cảm xúc cần tạo: "Ừ, đúng là mình đang gặp vấn đề này"
- Viết 2 câu mở đầu mẫu TOFU cho brand cụ thể

3.2 **MOFU (Consideration — KH Ấm)**
- Mục tiêu tone: Xây credibility, proof-based, giúp KH so sánh và tin tưởng
- Nguyên tắc: Đề cập sản phẩm qua kết quả/case study, không qua tính năng
- Cảm xúc cần tạo: "Brand này hiểu và có thể giúp mình"
- Viết 2 câu mở đầu mẫu MOFU cho brand cụ thể

3.3 **BOFU (Conversion — KH Nóng)**
- Mục tiêu tone: Rõ ràng, có urgency thật (không fake), reassuring
- Nguyên tắc: Offer cụ thể + deadline có lý do + giảm rào cản cuối
- Cảm xúc cần tạo: "Giờ là đúng lúc để hành động"
- Viết 2 câu mở đầu mẫu BOFU cho brand cụ thể

### Bước 4: Xây Từ điển thương hiệu
4.1 **Từ ĐƯỢC DÙNG** (tối thiểu 10 từ/cụm từ):
- Từ phản ánh đúng personality đã xác định ở Bước 2
- Từ KH hay dùng khi mô tả vấn đề của họ
- Từ tạo cảm giác thân thiết, đúng ngữ cảnh văn hóa

4.2 **Từ CẤM DÙNG** (tối thiểu 8 từ/cụm từ + LÝ DO):
- Từ quá generic: "uy tín hàng đầu", "chất lượng cao", "giải pháp toàn diện"
- Từ không phản ánh personality
- Từ đối thủ hay dùng → gây confusion brand

4.3 **Bảng từ thay thế** (tối thiểu 8 cặp):

| Từ cấm | Thay bằng | Lý do thay |
|---|---|---|
| "sản phẩm chất lượng cao" | [cụ thể hóa kết quả] | Quá chung chung, KH không tin |
| "dịch vụ chuyên nghiệp" | [bằng chứng cụ thể] | Ai cũng nói vậy |

### Bước 5: Compile Brand Bible hoàn chỉnh
5.1 **Brand Overview** — đoạn văn 3-5 câu: brand là ai, phục vụ ai, và tại sao brand này tồn tại theo cách khác biệt.
5.2 **Positioning Statement** — 1 câu duy nhất:
> "[Brand] là [loại hình] duy nhất giúp [target audience cụ thể] [kết quả đo được] bằng cách [phương pháp khác biệt]."

5.3 **Ví dụ caption cặp đôi** — tối thiểu 3 cặp (ĐÚNG tone + SAI tone, cùng thông điệp).

5.4 **Visual Direction** — 3-4 câu đủ để designer hình dung: màu sắc, font direction, ảnh style.

5.5 Hỏi founder xác nhận trước khi finalize.
5.6 Đề xuất lưu Brand Bible vào Notion Project Knowledge.

## 4. References

- `brandformance-framework.md` — Phần II (Bản chất Brandformance), Phần III (Phễu 4 giai đoạn)
- `brandformance-customer.md` — Phần III (Câu nói nội tâm thật của KH)
