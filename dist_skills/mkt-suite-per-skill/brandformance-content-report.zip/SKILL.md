---
name: brandformance-content-report
description: "Kích hoạt khi cần báo cáo hiệu quả content social — pattern hook/format nào work, so sánh Pillar, đề xuất action cho kỳ tới. Trigger: 'báo cáo content', 'content report', 'content nào work', 'đánh giá content tháng', 'review content plan', 'content không ai xem'. Kích hoạt cả khi kết thúc tuần/tháng cần tổng kết content social."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Content Report

## 1. Triggers

### Explicit triggers
- "báo cáo content tháng/tuần này", "content report"
- "content nào đang work?", "review content plan"

### Implicit triggers
- Kết thúc chu kỳ content (tuần/tháng) → cần tổng kết trước khi lên lịch mới
- Reach giảm dần không rõ nguyên nhân
- Chuẩn bị dùng `brandformance-next-cycle.md` → cần content report làm input

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Data content theo platform (reach, engagement, save, comment) trong khoảng thời gian
- [ ] **[BẮT BUỘC]** Content Strategy/Pillars đang áp dụng
- [ ] **[NẾU CÓ]** Số liệu kỳ trước để so sánh trend

Đọc trước khi thực hiện:
- `brandformance-content.md` → Toàn bộ
- `brandformance-content-strategy.md` (nếu có — để đối chiếu Pillar)

## 3. Execution Steps

### Bước 1: Tổng hợp data theo Pillar và tầng phễu
Nhóm toàn bộ bài đăng trong kỳ theo Pillar (P1/P2/P3/P4) và tầng (TOFU/MOFU/BOFU), tính trung bình reach/engagement mỗi nhóm.

### Bước 2: Xác định top/bottom performers
Liệt kê 3-5 bài tốt nhất và 3-5 bài tệ nhất theo KPI phù hợp từng tầng (TOFU: view rate/reach; MOFU: save/comment; BOFU: CPL/inbox).

### Bước 3: Tìm pattern
- Hook dạng nào (Pain/Curiosity/Story/Number) xuất hiện nhiều nhất trong top performers?
- Format nào (video ngắn/carousel/text) hiệu quả hơn?
- Ngày/giờ đăng nào có reach tốt hơn?
- Pillar nào đang under-perform so với tỉ trọng đầu tư?

### Bước 4: So sánh với kỳ trước
Trend tăng/giảm theo từng KPI chính, không chỉ nhìn con số tuyệt đối của kỳ này.

### Bước 5: Đề xuất action cụ thể cho kỳ tới
Mỗi insight phải đi kèm hành động rõ ràng: "Hook dạng Pain đang work tốt hơn Number 40% → tăng tỉ lệ Pain hook trong lịch tuần tới", không dừng ở nhận xét chung chung.

### Bước 6: Build report document
Report dùng làm input trực tiếp cho `brandformance-next-cycle.md` và `brandformance-content-calendar.md` kỳ tới.

## 4. Examples

### Example 1 — Generic: Thương hiệu thực phẩm healthy (báo cáo tháng)
```
TỔNG QUAN: 20 bài đăng — TOFU 14, MOFU 4, BOFU 2. Reach trung bình TOFU: 3.2K (kỳ trước 2.1K, +52%)

TOP PERFORMER: "Sao ăn ít mà vẫn không giảm?" (Pain hook, video 45s) — Reach 12K, View rate 38%
BOTTOM PERFORMER: "Giới thiệu sản phẩm mới" (không hook, ảnh tĩnh) — Reach 400

PATTERN: 4/5 bài top đều dùng Pain hook trong 3 giây đầu. Carousel MOFU có save rate cao gấp 2 lần video MOFU.

ACTION KỲ TỚI: Tăng tỉ lệ Pain hook trong TOFU lên 70%. Chuyển content MOFU từ video sang carousel.
Pillar "Câu chuyện KH" đang under-perform (reach thấp nhất) → thử format testimonial video ngắn thay vì text.
```

### Example 2 — Giáo dục: Trung tâm kỹ năng (báo cáo tuần)
```
TỔNG QUAN: 6 bài — TikTok 4, Facebook 2. TikTok view rate trung bình 22% (target 30%)

TOP: "3 lỗi khi thuyết trình mà không ai nói cho bạn" (Contradiction hook) — View rate 41%, 200 comment
BOTTOM: Video quay lại buổi học (không hook rõ, mở đầu chậm) — View rate 8%

PATTERN: Video có hook trong 2 giây đầu (không phải intro giới thiệu) có view rate gấp 3-4 lần.
Video BTS lớp học không có hook rõ đang kéo trung bình xuống.

ACTION: Bỏ hoàn toàn kiểu mở đầu "giới thiệu bản thân" trong video TOFU.
Áp dụng hook Contradiction/Pain cho toàn bộ video tuần tới — đối chiếu `brandformance-content-script.md`.
```

## 5. Edge Cases & Error Handling

**Reach cao nhưng không ra lead**: Đây là hành vi bình thường của TOFU — TOFU không nên đo bằng lead, chỉ đo bằng reach/view rate/follower growth. Nếu MOFU/BOFU cũng reach cao mà không ra lead mới cần lo.

**Thiếu data 1 kênh (ví dụ TikTok chưa có insight đầy đủ)**: Ghi rõ giới hạn, không suy diễn số liệu thiếu.

**Nhầm lẫn organic và bài được boost**: Tách riêng 2 loại khi tính trung bình — bài boost sẽ làm sai lệch đánh giá pattern organic thật.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `DATA_AGGREGATE` | Tổng hợp theo Pillar + tầng |
| `TOP_BOTTOM` | Xác định top/bottom performers |
| `PATTERN_FIND` | Tìm pattern hook/format/timing |
| `TREND_COMPARE` | So sánh kỳ trước |
| `ACTION_PROPOSE` | Đề xuất action cụ thể |
| `DONE` | Content Report hoàn chỉnh |

## References
- `brandformance-content.md` → Toàn bộ
- `brandformance-content-calendar.md` → Áp dụng action vào lịch kỳ tới
- `brandformance-next-cycle.md` → Dùng report này làm evidence
