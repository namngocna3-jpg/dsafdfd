---
name: brandformance-customer-insight
description: "Kích hoạt khi cần xây dựng chân dung khách hàng sâu theo tư duy Brandformance — 3 nhóm Cold/Warm/Hot với câu nói nội tâm thật, rào cản và trigger hành động theo từng tầng phễu. Trigger: 'xây chân dung KH', 'customer persona', 'insight KH', 'KH đang nghĩ gì', 'phân tầng KH', 'cold warm hot', 'câu nói nội tâm', 'trigger mua hàng', 'lý do KH không chốt'. Kích hoạt cả khi content/ads đang fail do không chạm đúng vấn đề KH, hoặc khi CPL cao do target sai tệp."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Customer Insight

## 1. Triggers

### Explicit triggers
- "xây chân dung KH", "customer persona cho brand của tôi"
- "KH đang nghĩ gì?", "câu nói nội tâm của KH là gì?"
- "phân tầng Cold/Warm/Hot", "trigger mua hàng"
- "tại sao KH không chốt dù đã inbox nhiều?"

### Implicit triggers
- Content đang reach nhiều nhưng engagement thấp, ít inbox → không chạm đúng vấn đề
- CPL cao liên tục → đang target sai tệp hoặc messaging sai
- Nhiều người inbox nhưng tỉ lệ chốt thấp → đang lẫn lộn giữa các nhóm KH
- Team content không biết "viết cho ai" → mỗi bài nhắm một kiểu người khác nhau
- Vừa hoàn thành Market Research → cần đi sâu vào phân khúc đã chọn

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Phân khúc/tệp KH cụ thể cần xây insight
- [ ] **[BẮT BUỘC]** Sản phẩm/dịch vụ và vấn đề nó giải quyết
- [ ] **[NẾU CÓ]** Nội dung inbox/comment/review thật của KH — đây là nguồn vàng
- [ ] **[NẾU CÓ]** Tỉ lệ chuyển đổi hiện tại (để biết đang có vấn đề ở tầng nào)
- [ ] **[NẾU CÓ]** Top 3 objection KH hay nêu ra khi tư vấn

Đọc trước khi thực hiện:
- `brandformance-customer.md` → Phần IV (3 nhóm KH), Phần II (Cắt lớp), Phần V (Lead chất lượng)
- `brandformance-framework.md` → Phần IV (Bypass Lead), Phần V (AAARRR)

## 3. Execution Steps

### Bước 1: Thu thập và phân tích "ngôn ngữ thật" của KH
1.1 Nếu user có inbox/comment/review → đọc và extract pattern ngôn ngữ thật.
1.2 Chú ý: Cách KH mô tả vấn đề thường không phải cách brand nghĩ KH mô tả.
   Brand nghĩ KH nói "muốn tăng doanh thu", KH thật ra nói "sao tháng này lại ế thế này"
1.3 Từ ngữ thật của KH → sẽ trở thành input cho Brand Bible (từ điển thương hiệu).
1.4 Nếu không có data → dùng empathy mapping: đặt mình vào vị trí KH ở từng giai đoạn.

### Bước 2: Phân tầng 3 nhóm theo nhiệt độ

**Nhóm LẠNH (Cold) — Chưa biết brand hoặc chưa nhận ra vấn đề**
- Câu nói nội tâm dạng: "Sao mình cứ [symptom] hoài vậy?" (không phải "tôi cần [giải pháp]")
- Rào cản: Không biết có giải pháp / Không tin giải pháp nào có thể help
- Mục tiêu content: Đặt tên vấn đề cho họ, tạo nhận diện
- KPI: CPM, Video View Rate, organic reach, follower growth
- KHÔNG: Mention sản phẩm, offer, giảm giá

**Nhóm ẤM (Warm) — Đã biết brand hoặc đang tìm giải pháp**
- Câu nói nội tâm dạng: "Brand A thì như thế này, Brand B thì như thế kia... mình nên chọn ai?"
- Rào cản: Không đủ trust / Chưa chắc brand này có phù hợp với mình không
- Mục tiêu content: Xây trust, tạo differentiation, xử lý objection gián tiếp
- KPI: CTR, CPL, engagement depth (comment, save)
- CÓ: Mention sản phẩm qua kết quả/case study, không phải tính năng

**Nhóm NÓNG (Hot) — Sẵn sàng ra quyết định**
- Câu nói nội tâm dạng: "Giá có hơi cao, nhưng thấy cũng được... mà chưa chắc lắm..."
- Rào cản: Giá / Thời điểm / Lo ngại cụ thể về sản phẩm
- Mục tiêu content: Urgency thật, xử lý objection trực tiếp, giảm rào cản cuối
- KPI: CPA, CPO, tỉ lệ Inbox → Chốt
- CÓ: Offer rõ, deadline có lý do, reassurance, guarantee

### Bước 3: Vẽ Customer Journey cho từng nhóm
3.1 AWARE: Họ lần đầu tiếp xúc với vấn đề/brand ở đâu?
3.2 CONSIDER: Họ đang so sánh với gì? Tiêu chí so sánh là gì?
3.3 INTENT: Điều gì khiến họ từ "cân nhắc" sang "muốn mua"?
3.4 ACTION: Rào cản cuối trước khi chốt là gì? Bao lâu để ra quyết định?
3.5 LOYAL: Sau khi mua, điều gì khiến họ quay lại hoặc giới thiệu người khác?

### Bước 4: Xây ma trận Câu nói nội tâm × Content
4.1 Với mỗi nhóm, viết 3-5 "câu nói nội tâm thật":
- Dùng ngôn ngữ của KH, không phải ngôn ngữ của brand
- Câu tốt: "Mình đã thử [X] rồi nhưng vẫn không ăn thua, chắc tại mình làm sai gì đó"
- Câu tệ: "Tôi muốn tìm giải pháp hiệu quả"

4.2 Với mỗi câu nói nội tâm, map sang Content Type phù hợp:
- Cold: Bài đặt tên vấn đề, observation, câu hỏi khai mở
- Warm: Case study, FAQ, so sánh, giải thích cơ chế
- Hot: Testimonial cụ thể, offer + deadline, risk reversal

### Bước 5: Xác định MQL/SQL criteria
5.1 MQL (Marketing Qualified Lead): Tín hiệu nào cho thấy KH đủ điều kiện để nurture?
5.2 SQL (Sales Qualified Lead): Hành vi nào cho thấy KH đang chuyển từ Warm → Hot?
   - Ví dụ: Xem pricing page / Hỏi về timeline cụ thể / Inbox hỏi "còn slot không?"
5.3 Điều kiện cần (MQL) và điều kiện đủ (SQL) theo đặc thù ngành.

## 4. Edge Cases & Error Handling

**Case 1: Không có data thật từ KH**
→ Dùng empathy mapping, ghi rõ: "Đây là insight ước tính. Cần validate sau khi có 10-20 inbox đầu tiên."

**Case 2: User muốn xây 1 persona cho tất cả KH**
→ Flag: "1 persona = không ai cảm thấy content này 'nói về mình'."
→ Tối thiểu 3 nhóm (Cold/Warm/Hot).

**Case 3: Phân khúc có nhiều nhóm nhân khẩu học rất khác nhau**
→ Ưu tiên nhóm chiếm 60-70% doanh thu để build insight trước.

**Case 4: Câu nói nội tâm nghe "quá âm" (toàn lo lắng)**
→ Cân bằng với câu Desire: "Mình muốn đến buổi họp có thể nói được ý kiến mà không cần chuẩn bị mấy ngày trước"

**Case 5: User hỏi "KH của tôi là ai?" mà không có ngữ cảnh**
→ Đây là câu hỏi của Market Research, redirect: "Nên bắt đầu với brandformance-market-research."

## References

- `brandformance-customer.md` → Toàn bộ — đây là knowledge doc nền tảng của skill này
- `brandformance-measurement.md` → Phần III (Lead Scoring, MQL/SQL)

Câu hỏi vàng để khai thác câu nói nội tâm:
- "Trước khi tìm đến sản phẩm này, bạn đã thử giải pháp nào và tại sao thất bại?"
- "Điều gì khiến bạn bắt đầu tìm kiếm [giải pháp] vào lúc đó?"
- "Nếu vấn đề này không được giải quyết, điều tệ nhất có thể xảy ra là gì?"
