# IMC · Big Idea · Creative Brief — Playbook chiến dịch tích hợp

Distil từ khóa "Chiến Binh Fullstack Marketing" (buổi 5–6, GV Nguyễn Thùy Khanh & cộng sự). Dùng khi lên kế hoạch một chiến dịch truyền thông tích hợp có Big Idea, không phải chỉ chạy ads lẻ.

---

## I. Phân biệt 3 loại kế hoạch (đừng nhầm)

| Loại | Mục tiêu | Tầm |
|---|---|---|
| **Marketing Plan** | Đạt mục tiêu kinh doanh (doanh thu, thị phần). Bao gồm cả 4P: Product, Price, Place, Promotion | Rộng nhất — 1 năm+ |
| **Brand Plan** | Xây & quản lý giá trị, hình ảnh, định vị thương hiệu | Trung — theo brand |
| **IMC Plan** | Tích hợp các kênh truyền thông để truyền tải **một thông điệp nhất quán** | Hẹp — theo chiến dịch |

→ IMC nằm bên trong Promotion của Marketing Plan. Đừng gọi một kế hoạch chạy ads là "marketing plan". Xác định đúng loại trước khi làm để không lệch scope.

## II. Nguyên tắc IMC — nhất quán đa kênh

Mọi điểm chạm (TVC, social, PR, POSM, landing page, sale script) phải truyền cùng **một** thông điệp cốt lõi. Khách chạm 7–10 lần ở nhiều kênh trước khi mua; nếu mỗi kênh nói một kiểu, thông điệp loãng và không đọng lại.

- Một chiến dịch = một Big Idea = một thông điệp đơn hướng (SMP).
- Kênh khác nhau → cách thể hiện khác nhau, nhưng lõi không đổi.
- Nhất quán từ **copy đến visual đến tone** — đây là lý do Creative Brief phải khóa Tone of Voice + Mandatory Elements.

## III. Phân tầng ý tưởng sáng tạo (đừng lẫn 4 khái niệm)

Đây là lỗi phổ biến nhất khi brief creative — gọi tên sai → team làm sai altitude.

1. **Big Idea** — Tư tưởng lớn, "linh hồn" của cả chiến dịch. Trừu tượng, bền, có thể sống nhiều năm (vd Dove "Real Beauty"). Trả lời: *chiến dịch này nói về điều gì lớn lao?*
2. **Concept** — Cách hiện thực hóa Big Idea trong một mùa/đợt cụ thể. Một Big Idea đẻ ra nhiều Concept.
3. **Execution** — Sản phẩm sáng tạo cụ thể: TVC, key visual, viral clip, activation. Concept đẻ ra nhiều Execution.
4. Phân biệt tiếp **Tagline vs Key Message vs Slogan**:
   - **Slogan** — gắn với thương hiệu, sống lâu dài, xuyên nhiều chiến dịch (định vị brand).
   - **Tagline** — gắn với một chiến dịch cụ thể, đổi theo campaign.
   - **Key Message** — thông điệp cốt lõi chiến dịch cần khách ghi nhớ; tagline là cách nói ngắn gọn của key message.

→ Kiểm tra altitude: nếu "Big Idea" của bạn thay được bằng một TVC thì đó là Execution, không phải Big Idea.

## IV. Creative Brief chuẩn — 12 mục bắt buộc

Bản brief đầy đủ để giao cho team/creative agency. Thiếu mục nào → vòng lặp sửa vô tận.

| # | Mục | Yêu cầu | Ghi chú thực hành |
|---|---|---|---|
| 1 | **Background** | Bối cảnh kinh doanh, thị trường, thách thức | Chỉ chọn thông tin **liên quan trực tiếp** đến chiến dịch. Không kể lịch sử công ty. |
| 2 | **Business Objective** | Mục tiêu kinh doanh cụ thể (doanh thu, thị phần) | Nhiều mục tiêu → chia Primary & Secondary. |
| 3 | **Communication Objective** | Mục tiêu truyền thông (nhận diện, đổi nhận thức, kích mua thử) | Phải link được với Business Objective. |
| 4 | **Target Audience (TA)** | Chân dung KH chi tiết: nhân khẩu, tâm lý, hành vi | Mô tả bằng Persona hoặc 5W1H (Who/What/When/Where/Why/How). |
| 5 | **Key Insight** | Sự thật ngầm hiểu chạm tâm lý/nỗi đau TA | Không dừng ở "thích giá rẻ" — đào sâu hơn. |
| 6 | **Single-minded Proposition (SMP)** | Thông điệp cốt lõi — **chỉ 1 ý lớn nhất** | Tập trung cao độ, tránh thông điệp đa hướng. |
| 7 | **Supporting Reasons (RTB)** | Bằng chứng củng cố SMP: chứng nhận, tính năng, kết quả | Hợp lý hóa lý trí sau khi cảm xúc đã bị chạm. |
| 8 | **Tone of Voice** | Phong cách ngôn ngữ: vui/gần gũi/truyền cảm hứng/nghiêm túc | Đảm bảo đồng bộ copy → visual. |
| 9 | **Deliverables** | Danh sách đầu ra: TVC, Print, Social Post, Landing Page, Activation | Càng rõ càng dễ dự trù nhân sự + budget. |
| 10 | **Timeline** | Brief-in → Concept Approval → Production → Launch | Có buffer phòng rủi ro. |
| 11 | **Budget** | Ngân sách cả chiến dịch hoặc từng giai đoạn | — |
| 12 | **Mandatory Elements** | Bắt buộc phải có: logo, màu brand guideline, slogan, key visual, ràng buộc pháp lý | Ghi càng cụ thể càng tránh vòng lặp sửa. |

## V. Quy trình sáng tạo Big Idea

1. Đọc kỹ Creative Brief — đặc biệt **Key Insight** (5) và **SMP** (6): Big Idea nảy từ insight, không nảy từ sản phẩm.
2. Brainstorm nhiều hướng Big Idea → kiểm tra mỗi hướng: (a) có bắt nguồn từ insight thật không? (b) đủ lớn để đẻ nhiều Concept/Execution không? (c) đối thủ dùng được không — nếu được thì chưa đủ khác biệt.
3. Chốt 1 Big Idea → triển ra Concept theo mùa → Execution theo kênh (Key Assets).
4. Toàn bộ Execution phải reinforce cùng SMP — đây là điểm nối về nguyên tắc IMC (mục II).

## VI. Kết nối skill

- Insight cho mục 5 Creative Brief → `brandformance-customer-insight`.
- Chân dung TA cho mục 4 → `brandformance-market-research`.
- Hành trình KH + content theo điểm chạm (triển khai Execution) → `brandformance-content-strategy` (xem `references/customer-journey-7-stage.md`).
- Deliverables sản xuất (script, caption, creative) → `brandformance-content-script`, `brandformance-caption-writing`, `brandformance-creative-review`.
- Đo lường chiến dịch → `brandformance-kpi-setup`, `brandformance-report`.
