---
name: brandformance-campaign-plan
description: >
  Lên kế hoạch chiến dịch marketing 5 phase (Chuẩn bị→Teasing→Bung nhẹ→Bung mạnh→Duy trì), tính ngược KPI từ doanh thu mục tiêu. Kích hoạt khi: "kế hoạch chiến dịch", "campaign plan", "lên plan campaign", "brief chiến dịch", "campaign brief", "kế hoạch launch sản phẩm", "launch campaign". Output: file .md đầy đủ — team nhận là triển khai được ngay.
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Campaign Plan  
  
## 1. Triggers  
  
### Explicit triggers  
- "lên kế hoạch campaign", "plan campaign tháng/quý này"  
- "kế hoạch launch sản phẩm/dịch vụ mới"  
- "campaign plan Brandformance", "plan marketing tổng thể"  
  
### Implicit triggers  
- Vừa hoàn thành Funnel Design → cần kế hoạch triển khai cụ thể  
- Đầu tháng/quý mới → cần campaign plan cho kỳ tới  
- Sắp ra mắt sản phẩm nhưng chưa có plan cụ thể  
- Budget vừa được phê duyệt → cần phân bổ thành plan  
  
## 2. Context Requirements  
  
- [ ] **[BẮT BUỘC]** Mục tiêu doanh thu/KPI cụ thể cần đạt  
- [ ] **[BẮT BUỘC]** Ngân sách marketing tổng  
- [ ] **[BẮT BUỘC]** Thời gian campaign (ngày bắt đầu → kết thúc)  
- [ ] **[BẮT BUỘC]** Sản phẩm/offer chính của campaign  
- [ ] **[NẾU CÓ]** Funnel Design và Positioning đã có  
- [ ] **[NẾU CÓ]** Data từ campaign trước (CPL, tỉ lệ chốt, ROAS)  
  
Đọc trước khi thực hiện:  
- `brandformance-framework.md` → Phần III (Phễu 4 giai đoạn + tỉ lệ Brand/Performance)  
- `brandformance-measurement.md` → Phần II (Mapping ngược từ doanh thu)  
- `references/imc-bigidea-creative-brief.md` → khi chiến dịch cần Big Idea + thông điệp tích hợp đa kênh: phân biệt MKT/Brand/IMC Plan, phân tầng Big Idea–Concept–Execution, Creative Brief chuẩn 12 mục  
  
## 3. Execution Steps  
  
### Bước 1: Mapping KPI ngược từ doanh thu  
1.1 Bắt đầu từ mục tiêu doanh thu → tính ngược lên:  
- Mục tiêu doanh thu: X triệu  
- AOV (giá trị đơn hàng trung bình): Y triệu  
- Số đơn cần: X/Y = Z đơn  
- Tỉ lệ chốt từ lead: A%  
- Số lead qualified cần: Z / A% = B lead  
- CPL benchmark: C  
- Ngân sách cần cho acquisition: B × CPL  
  
1.2 So sánh ngân sách cần vs ngân sách có → điều chỉnh target hoặc strategy.  
1.3 Nếu ngân sách không đủ → flag ngay và đề xuất điều chỉnh.  
  
### Bước 2: Phân chia campaign theo 5 Phase Brandformance  
  
**Phase 1 — Chuẩn bị (1-2 tuần trước launch)**  
- Hoàn thiện creative assets, setup tracking, warm up audience  
- Ngân sách: 5-10% tổng  
  
**Phase 2 — Teasing (1-2 tuần)**  
- Brand 80% / Performance 20%  
- Content TOFU: tạo awareness, chưa bán hàng  
- KPI: Reach, Follower, Email signups  
  
**Phase 3 — Bung nhẹ (1-2 tuần)**  
- Brand 60% / Performance 40%  
- Introduce offer nhẹ, social proof, case study  
- KPI: CPL, Inbox rate  
  
**Phase 4 — Bung mạnh (1-2 tuần)**  
- Brand 30% / Performance 70%  
- Full offer, urgency thật, retarget mạnh  
- KPI: CPA, CPO, ROAS, Revenue  
  
**Phase 5 — Duy trì + Wrap-up (sau launch)**  
- Brand 50% / Performance 50%  
- Nurture lead chưa chốt, retention KH đã mua  
- KPI: Tỉ lệ Inbox → Chốt (sau launch)  
  
### Bước 3: Phân bổ ngân sách theo Phase  
- Phase 1 (Chuẩn bị): 5%  
- Phase 2 (Teasing): 15%  
- Phase 3 (Bung nhẹ): 20%  
- Phase 4 (Bung mạnh): 45%  
- Phase 5 (Duy trì): 15%  
  
Điều chỉnh: Sản phẩm mới, chưa có brand → tăng Phase 2+3.  
  
### Bước 4: Xây dựng Brand Message Framework  
- Phase 2: Cảm xúc/Problem awareness  
- Phase 3: Social proof + Credibility  
- Phase 4: Offer + Urgency thật  
  
Đảm bảo brand message nhất quán xuyên suốt.  
  
### Bước 5: Compile Campaign Plan document  
5.1 Tóm tắt: Mục tiêu, timeline, ngân sách, KPI chính.  
5.2 Bảng Phase × Thời gian × Ngân sách × Kênh × Brand Message × KPI.  
5.3 Chỉ số cảnh báo: "Nếu [KPI] sau [thời gian] dưới [ngưỡng] → điều chỉnh [X]."  
  
## 4. Examples  
  
### Example 1 — Generic: Campaign launch dịch vụ tư vấn tài chính  
**Input:** Mục tiêu 20 KH mới, doanh thu 200 triệu. Ngân sách 30 triệu. Timeline 01/08-31/08. CPL cũ 500K, tỉ lệ chốt 25%.  
  
**Output:**  
```  
CAMPAIGN PLAN — Tư Vấn Tài Chính Tháng 8  
  
KPI Mapping:  
200 triệu / 10 triệu = 20 đơn  
Tỉ lệ chốt 25% → cần 80 lead inbox  
CPL 500K → ngân sách cần 40 triệu  
⚠️ 30 triệu < 40 triệu cần → Điều chỉnh: Target 15 đơn HOẶC focus warm audience để tăng tỉ lệ chốt lên 35%  
  
Phase Plan (target 15 đơn):  
Phase 1 (27/7-31/7): 2 triệu — setup pixel, warm audience  
Phase 2 (1/8-7/8): 5 triệu — TOFU "3 lỗi tài chính phổ biến người đi làm 30 tuổi"  
Phase 3 (8/8-15/8): 6 triệu — Testimonial + Case study KH cũ  
Phase 4 (16/8-26/8): 14 triệu — Full offer + deadline + retarget  
Phase 5 (27/8-31/8): 3 triệu — Follow up inbox chưa chốt  
  
KPI cảnh báo:  
→ Sau 7 ngày Phase 4: CPL > 700K → thay creative  
→ Sau 3 ngày Phase 4: CTR < 1% → dừng, A/B test hook mới  
```  
  
### Example 2 — Giáo dục: Campaign khai giảng khóa học AI  
**Input:** Mục tiêu 30 học viên (5 triệu/người). Ngân sách 20 triệu. Timeline 3 tuần, khai giảng 15/8. Lần đầu launch.  
  
**Output:**  
```  
CAMPAIGN PLAN — Launch Khóa AI Marketing  
  
KPI Mapping:  
30 học viên × 5 triệu = 150 triệu  
Tỉ lệ chốt từ webinar ~10-15% → cần 200-300 người dự webinar  
CPL webinar: 20 triệu / 240 ≈ 83K — lead giáo dục thực tế 80-150K  
⚠️ Điều chỉnh target xuống 20 học viên để an toàn hơn  
  
Phase Plan:  
Phase 1 (25/7-30/7): 1.5 triệu — chuẩn bị  
Phase 2 (31/7-6/8): 3 triệu — "Founder không cần code để dùng AI"  
Phase 3 (7/8-11/8): 4 triệu — Webinar miễn phí ngày 12/8 + email sequence  
Phase 4 (12/8-14/8): 9 triệu — Post-webinar offer + deadline 15/8  
Phase 5: 2.5 triệu — Follow up học viên chưa đăng ký  
  
KPI cảnh báo:  
→ Đăng ký webinar < 100 người vào 10/8 → chạy thêm reach ads  
→ Tỉ lệ chốt < 8% sau webinar → cần Q&A bổ sung  
```  
  
## 5. Edge Cases & Error Handling  
  
**Case 1: Ngân sách không đủ**  
→ Không giảm cả target lẫn ngân sách cùng lúc. Chọn 1 trong 2 để thay đổi.  
→ 3 phương án: Giảm target / Tăng ngân sách / Kéo dài timeline.  
  
**Case 2: Campaign quá ngắn (< 2 tuần)**  
→ Bỏ Phase 2, gộp Phase 3+4.  
→ Phải có warm audience sẵn.  
  
**Case 3: Lần đầu launch, không có data benchmark**  
→ Không đặt KPI cứng cho lần đầu — đặt target "data collection."  
→ Campaign đầu = tháng học: thu thập CPL thật, tỉ lệ chốt thật.  
  
**Case 4: User muốn bỏ Phase Teasing**  
→ Flag: "Phase Teasing là Brand investment — bỏ thường tăng CPO 20-40% do audience lạnh."  
  
## 6. State Management  
  
| State | Mô tả | Claude làm gì |  
|---|---|---|  
| `KPI_MAPPING` | Tính ngược từ doanh thu | Chạy Bước 1, flag nếu không khả thi |  
| `PHASE_DESIGN` | Phân chia 5 Phase | Chạy Bước 2 |  
| `BUDGET_ALLOCATION` | Phân bổ ngân sách | Chạy Bước 3 |  
| `MESSAGE_FRAMEWORK` | Xây Brand Message | Chạy Bước 4 |  
| `COMPILING` | Compile Campaign Plan | Chạy Bước 5 |  
| `DONE` | Plan hoàn chỉnh | Đề xuất: "Bước tiếp theo: brandformance-campaign-timeline" |  
  
## References  
  
- `brandformance-framework.md` → Phần III (5 Phase campaign, tỉ lệ Brand/Perf)  
- `brandformance-measurement.md` → Phần II (Mapping ngược từ doanh thu)  
- `references/imc-bigidea-creative-brief.md` → IMC · Big Idea · Creative Brief 12 mục (Fullstack Marketing buổi 5–6)  
  
Formula mapping ngược: Revenue → Đơn → Lead Qualified → Lead Tổng → Reach  
Ngân sách required = Số lead × CPL benchmark + contingency 20%
