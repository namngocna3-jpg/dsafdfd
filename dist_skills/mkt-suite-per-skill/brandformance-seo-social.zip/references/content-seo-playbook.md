# Content SEO Playbook (chuẩn 3 WIN + tối ưu AI)
Distil từ "Content SEO online Buổi 1+2" — TAS Global / SEONGON.

## 1. Nguyên tắc 3 WIN
Content SEO bền vững phải thắng cả 3 bên cùng lúc:
- **Người dùng:** trả lời đúng vấn đề họ tìm + mở rộng thông tin họ có thể quan tâm.
- **Google/AI:** đáp ứng technical để bot đọc hiểu nhanh & chính xác; được dẫn nguồn ở AI Overview.
- **Doanh nghiệp:** phục vụ mục tiêu marketing/bán hàng (dẫn khách vào phễu).

## 2. Bối cảnh: SEO không còn chỉ là SEO
Google = kênh người dùng **chủ động tìm kiếm** (khác Facebook "bị động"). Ranking đến từ **content chất lượng**. Nay phải tối ưu cho 3 lớp:
| | Viết tắt | Là gì | Xuất hiện ở |
|---|---|---|---|
| **SEO** | Search Engine Optimization | Nâng thứ hạng website trên trang kết quả | 10 link xanh truyền thống |
| **AEO** | Answer Engine Optimization | Tối ưu để nội dung thành **câu trả lời trực tiếp** | AI Overview, Featured Snippets |
| **GEO** | Generative Engine Optimization | Tối ưu để xuất hiện trong câu trả lời do AI tổng hợp | Google Gemini, ChatGPT, Perplexity |

**Kết luận:** content nay phải tối ưu cho cả SEO + AI; nhưng ở mọi thời điểm, **content chất lượng vẫn là gốc** để Google/AI đề xuất.

## 3. Content chuẩn SEO = Content + SEO
- **Content:** chuẩn nhu cầu tìm kiếm của người dùng **+** mục tiêu truyền thông/marketing/bán hàng của DN.
- **SEO:** đáp ứng tiêu chí Technical để Google đọc hiểu trang đích nhanh & chính xác.
Một bài SEO **tốt** = tốt cho người đọc + tốt cho Google (SEO truyền thống + được AI dẫn nguồn ở AIO) + tốt cho doanh nghiệp.

## 4. Quy trình triển khai nội dung trên website
1. **Nghiên cứu từ khoá & search intent** → nhóm theo cụm chủ đề (topic cluster).
2. **Lên dàn ý chuẩn SEO** (xem mục 5) — làm trước khi viết.
3. **Sản xuất nội dung** bám dàn ý, tối ưu on-page (title, heading H1/H2/H3, meta, internal link, hình ALT).
4. **Tối ưu cho AI:** trả lời trực tiếp câu hỏi, có định nghĩa rõ, bảng/list dễ trích, thể hiện E-E-A-T để được dẫn nguồn.
5. **Quản lý sản xuất số lượng lớn:** template dàn ý + AI hỗ trợ viết/biên tập → kiểm duyệt chất lượng con người trước khi đăng.

## 5. Quy trình lên dàn ý chuẩn SEO (khung)
- Xác định **từ khoá chính + phụ** và **search intent** (thông tin / điều hướng / giao dịch) + vị trí phễu.
- Phân tích Top 10 đang xếp hạng: các H2 họ cover → tìm khoảng trống để làm tốt hơn.
- Dàn ý theo mạch giải quyết vấn đề của người đọc → dẫn tự nhiên tới sản phẩm/CTA (không nhồi bán).
- Mỗi H2 = 1 ý người đọc cần; thêm FAQ để bắt Featured Snippet/AEO.

## 6. Ứng dụng AI (giữ chất lượng)
Dùng AI để nghiên cứu, phác thảo dàn ý, viết nháp, biên tập, mở rộng — nhưng **con người quyết định insight, kiểm duyệt, thêm trải nghiệm thật & giọng thương hiệu** (mô hình AI-Human Hybrid). Xem thêm skill brandformance-content-brief để chuẩn hoá brief trước khi giao AI viết.

## 7. Kết nối
- Structured data để được AI/Google đọc hiểu: skill schema (EN) hoặc ai-seo (EN).
- Brief bài viết SEO chi tiết: brandformance-content-brief (`references/brief-templates.md` mục 3.1).
