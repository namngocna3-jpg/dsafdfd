---
name: brandformance-bypass-lead-system
description: "Kích hoạt khi cần xây hệ thống nhận diện và tracking Bypass Lead — khách đến không qua phễu chính thức (Zalo cá nhân, network, giới thiệu tự phát). Trigger: 'bypass lead', 'khách đến không qua phễu', 'tracking khách giới thiệu quen biết', 'Zalo cá nhân founder', 'khách quen inbox trực tiếp', 'khách không biết đến từ đâu'."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Bypass Lead System

## 1. Triggers

### Explicit triggers
- "bypass lead là gì", "khách đến không qua phễu"
- "tracking khách giới thiệu/quen biết", "Zalo cá nhân founder dùng để bán hàng thế nào"

### Implicit triggers
- Doanh thu thực tế cao hơn nhiều so với số lead ghi nhận được từ phễu chính thức
- Founder/Sale có nhiều khách quen tự nhắn hỏi qua Zalo cá nhân, không qua kênh chính thức
- Chuẩn bị referral program nhưng chưa biết hiện trạng referral tự phát ra sao

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Các kênh không chính thức hiện có KH đang đến qua
- [ ] **[NẾU CÓ]** Ước tính % doanh thu hiện tại đến từ nguồn này

## 3. Execution Steps

### Bước 1: Nhận diện các nguồn Bypass Lead phổ biến
- Zalo cá nhân của founder/sale (KH quen biết nhắn trực tiếp, không qua fanpage/OA)
- Network cá nhân (bạn bè, đối tác, cộng đồng founder tham gia)
- Khách cũ giới thiệu miệng, ngoài chương trình referral chính thức
- Đối tác/nhà cung cấp giới thiệu chéo

### Bước 2: Thiết kế cơ chế thu thập nguồn
Đơn giản nhất: **luôn hỏi 1 câu** khi tiếp nhận KH mới — "Anh/chị biết đến [brand] qua đâu ạ?" — áp dụng cho mọi kênh tiếp nhận. Không cần công cụ phức tạp, chỉ cần kỷ luật hỏi đều.

### Bước 3: Gắn tag CRM riêng cho Bypass Lead
Không gộp chung với lead từ phễu chính thức — hành vi mua và LTV khác nhau đáng kể. Gộp chung sẽ làm sai lệch phân tích hiệu quả phễu.

### Bước 4: Zalo cá nhân founder/sale làm kênh Bypass Lead chủ động
Khác với Zalo OA (broadcast, tự động hóa), Zalo cá nhân là kênh 1-1, mang tính con người cao — chia sẻ giá trị thật (không spam bán hàng), giữ mối quan hệ trước khi có nhu cầu mua.

### Bước 5: Đo lường riêng Bypass Lead
- % doanh thu đến từ Bypass Lead / Tổng doanh thu
- So sánh LTV Bypass Lead vs Lead phễu chính thức
- Tỉ lệ chốt Bypass Lead (thường cao hơn đáng kể)

### Bước 6: Build Bypass Lead Tracking Sheet + quy trình chuẩn
Cột cần có: Tên KH | Nguồn Bypass | Người tiếp nhận | Ngày | Kết quả | Giá trị đơn hàng.

## 4. Examples

### Example 1 — Dịch vụ tư vấn tài chính cá nhân
```
NHẬN DIỆN: Founder có network cũ từ công việc trước, nhiều người quen tự nhắn Zalo cá nhân hỏi tư vấn

QUY TRÌNH THU THẬP: Founder luôn hỏi ngay đầu buổi — "Anh/chị nghe đến em qua ai/đâu vậy?"
→ Ghi vào CRM ngay trong buổi nói chuyện

KẾT QUẢ SAU 1 THÁNG: 35% doanh thu đến từ Bypass Lead, LTV trung bình cao hơn 40%

HÀNH ĐỘNG: 2h/tuần để founder chủ động giữ liên lạc với network cũ qua Zalo cá nhân
```

### Example 2 — Trung tâm kỹ năng nhỏ (2 người)
```
NHẬN DIỆN: Nhiều học viên cũ giới thiệu bạn bè qua Zalo cá nhân của giáo viên

TRACKING SHEET:
| Tên | Nguồn | Người tiếp nhận | Kết quả |
| Chị Lan | Học viên cũ giới thiệu (Zalo GV) | GV Minh | Đã đăng ký |
| Anh Tuấn | Bạn của học viên cũ | GV Minh | Đang cân nhắc |

PHÁT HIỆN: 25% học viên mới đến từ Bypass Lead nhưng KHÔNG có chương trình referral chính thức
→ Đề xuất: Chuyển sang brandformance-referral-program.md để chính thức hóa
```

## 5. Edge Cases & Error Handling

**Sale quên hỏi nguồn**: Thêm câu hỏi nguồn vào script chuẩn như bước bắt buộc đầu buổi.
**KH không nhớ rõ biết đến qua đâu**: Ghi nhận nguồn "gần nhất"/"quyết định nhất" theo cảm nhận.
**Bypass Lead cao nhưng không có cách nhân rộng**: Đây chính là dấu hiệu nên chuyển sang referral program.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `SOURCE_IDENTIFY` | Nhận diện nguồn Bypass Lead |
| `COLLECTION_SETUP` | Thiết kế cơ chế thu thập nguồn |
| `CRM_TAGGING` | Gắn tag riêng trong CRM |
| `OUTREACH_DESIGN` | Thiết kế outreach Zalo cá nhân |
| `MEASUREMENT` | Đo lường % doanh thu + LTV so sánh |
| `DONE` | Bypass Lead Tracking Sheet hoàn chỉnh |

## References
- `brandformance-framework.md` → Phần IV
- `brandformance-customer.md` → Phần VI
- `brandformance-referral-program.md` → Chính thức hóa khi Bypass Lead đủ lớn
- `brandformance-lead-scoring.md` → Bypass Lead thường có điểm Intent cao sẵn
