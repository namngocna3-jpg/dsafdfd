---
name: brandformance-campaign-timeline
description: >
  Timeline chi tiết D-28 đến D+14, phân công task theo phase, pre-launch checklist. Kích hoạt khi: "timeline chiến dịch", "lịch triển khai campaign", "phân công task campaign", "campaign timeline", "ai làm gì trong campaign", "lịch làm việc team", "gantt marketing".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Campaign Timeline

## 1. Triggers

### Explicit triggers
- "timeline campaign", "lịch triển khai campaign"
- "phân công task campaign", "ai làm gì trong campaign"
- "gantt marketing", "D-day plan"

### Implicit triggers
- Có Campaign Plan rồi → cần chi tiết hóa thành timeline
- Launch gần → cần checklist công việc
- Team không biết ai làm gì, khi nào

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Campaign Plan đã có (hoặc ít nhất ngày launch + mục tiêu)
- [ ] **[BẮT BUỘC]** Team members và vai trò
- [ ] **[NẾU CÓ]** Campaign Plan đầy đủ 5 phase

## 3. Execution Steps

### Bước 1: Xác định D-Day và đếm ngược

D-Day = Ngày bắt đầu phase Bung mạnh (Phase 4).
Tất cả task đếm ngược từ D-Day.

### Bước 2: Timeline D-28 đến D+14

**D-28 đến D-21 (Phase 1 — Chuẩn bị):**
- D-28: Brief creative team, xác định hook + message
- D-25: First draft creative assets
- D-21: Setup pixel, tracking, landing page
- D-21: Audience warm-up bắt đầu (video views, engagement)

**D-21 đến D-14 (Phase 1 tiếp):**
- D-18: Approve creative assets
- D-14: Pre-launch checklist hoàn thành
- D-14: Email sequence setup xong

**D-14 đến D-7 (Phase 2 — Teasing):**
- D-14: Launch TOFU content + TOFU ads nhẹ
- D-12: KOC/seeding bắt đầu
- D-10: Kiểm tra pixel data, audience size
- D-7: Review teasing KPI (Reach, Follower growth)

**D-7 đến D-Day (Phase 3 — Bung nhẹ):**
- D-7: Launch MOFU content + Lead Gen ads
- D-5: Testimonial + Case study content live
- D-3: Retarget campaign setup
- D-1: Final check toàn bộ

**D-Day đến D+14 (Phase 4 — Bung mạnh):**
- D+0: Launch full offer + BOFU ads
- D+1: Morning check KPI (spend, CTR, CPL)
- D+3: First optimization (pause weak creatives)
- D+7: Mid-campaign review + adjust
- D+10: Scale winners, pause losers
- D+14: End campaign / Transition Phase 5

**D+14 trở đi (Phase 5 — Duy trì):**
- Follow up inbox chưa chốt
- Retention cho KH đã mua
- Collect testimonial mới

### Bước 3: Pre-Launch Checklist (D-3)

**Tracking:**
- [ ] Pixel active và ghi nhận event đúng
- [ ] UTM tracking cho tất cả link
- [ ] Conversion event test OK

**Creative:**
- [ ] Tất cả creative approved
- [ ] Copy đã được proofreading
- [ ] CTA links hoạt động

**Ads:**
- [ ] Campaign structure setup xong
- [ ] Budget đã phân bổ đúng
- [ ] Audience đã setup (Lookalike, Retarget)

**Funnel:**
- [ ] Landing page load nhanh (< 3s)
- [ ] Form hoạt động
- [ ] Email automation active
- [ ] Zalo OA / inbox team ready

### Bước 4: Build Timeline document

| D-Day | Task | Owner | Deadline | Status |
|---|---|---|---|---|
| D-28 | Brief creative | Marketing Lead | [date] | ⬜ |
| D-21 | Setup pixel + tracking | Dev/Marketing | [date] | ⬜ |
| D-14 | Launch TOFU ads | Ads Manager | [date] | ⬜ |
| D-0 | Launch BOFU campaign | Ads Manager | [date] | ⬜ |

## 4. Examples

### Example 1 — Campaign launch khóa học (D-Day = 15/8)
```
TIMELINE — Launch Khóa AI Marketing

D-28 (18/7): Brief creative, xác định hook "Founder không cần code để dùng AI"
D-21 (25/7): Creative done, pixel setup, LP test
D-14 (1/8): Launch TOFU "AI là gì với người không technical?"
D-7 (8/8): Webinar Free ngày 12/8 → Launch lead gen ads
D-3 (12/8): Webinar xong → BOFU email sequence bắt đầu
D-0 (15/8): Full offer launch, deadline 18/8
D+3 (18/8): Deadline + Follow up inbox
D+14 (29/8): Khai giảng + Alumni community

PRE-LAUNCH CHECKLIST D-3 (12/8):
[ ] Pixel ghi conversion OK
[ ] Webinar link hoạt động
[ ] Email sequence test gửi thành công
[ ] Zalo team sẵn sàng reply inbox
```

### Example 2 — Campaign Tết (D-Day = 1/1)
```
D-42 (20/11): Brief creative "Tết cùng gia đình"
D-28 (4/12): Creative assets hoàn thành
D-21 (11/12): Audience warm-up
D-14 (18/12): Teasing content + TOFU ads
D-7 (25/12): Bung nhẹ + Social proof
D-0 (1/1): Full Tết campaign
D+7 (8/1): Follow up + dọn hàng tồn
```

## 5. Edge Cases & Error Handling

**Launch gấp (< 2 tuần):**
→ Cắt Phase 2, gộp Phase 3+4.
→ Phải có warm audience sẵn (từ organic hoặc retarget cũ).

**Team nhỏ (1-2 người):**
→ Ưu tiên task theo impact: Tracking > Creative > Ads > Social.
→ Batch task: Làm tất cả creative 1 ngày.

**KPI Phase 2 tệ (reach thấp):**
→ Không tăng budget Phase 2 — review hook và creative.
→ Xem xét kéo dài Phase 2 thêm 3-5 ngày.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `D_DAY_SET` | Xác định D-Day |
| `TIMELINE_BUILD` | Build D-28 → D+14 |
| `CHECKLIST_BUILD` | Pre-launch checklist |
| `GANTT_BUILD` | Build bảng task per owner |
| `DONE` | Export sang Google Sheets / Notion |

## References
- `brandformance-campaign-plan.md` → Input cho Timeline
- `brandformance-content-calendar.md` → Content tasks trong timeline

Rule: Timeline không có owner = task không được làm. Mỗi task phải có 1 người chịu trách nhiệm.
