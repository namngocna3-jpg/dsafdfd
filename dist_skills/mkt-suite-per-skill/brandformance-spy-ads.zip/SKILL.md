---
name: brandformance-spy-ads
description: "Kích hoạt khi cần phân tích quảng cáo đối thủ từ Meta Ads Library — tìm hook đang work, angle phổ biến trong ngành, khoảng trống creative chưa ai khai thác. Trigger: 'spy ads đối thủ', 'xem ads đối thủ đang chạy', 'ads library', 'đối thủ đang chạy quảng cáo gì', 'phân tích creative đối thủ', 'hook nào đang work trong ngành', 'dán ads đối thủ vào đây', 'tìm insight từ ads thị trường'. Kích hoạt cả khi user paste nội dung ads từ Ads Library vào chat — dù không nói rõ 'spy ads'."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Spy Ads

## 1. Triggers

### Explicit triggers
- "spy ads đối thủ", "xem đối thủ đang chạy gì"
- "phân tích creative/ads đối thủ", "ads library [tên brand]"
- "hook nào đang work trong ngành [X]?"
- "tìm insight từ ads thị trường"

### Implicit triggers
- User paste nội dung quảng cáo (copy ads, mô tả creative) vào chat → đang chờ phân tích
- User chuẩn bị viết ads mới → cần benchmark ngành trước
- CTR đang thấp dù đã test nhiều → cần xem ngành đang dùng angle gì
- Sắp launch campaign → cần tránh trùng lặp với đối thủ

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Tên page/brand đối thủ muốn spy HOẶC nội dung ads đã copy về
- [ ] **[BẮT BUỘC]** Ngành hàng / sản phẩm để có context phân tích đúng
- [ ] **[NẾU CÓ]** Phân khúc KH đang target
- [ ] **[NẾU CÓ]** Mục đích spy: tìm hook / tìm offer / tìm angle / tìm format / toàn diện

Hướng dẫn lấy data từ Meta Ads Library:
- Vào: facebook.com/ads/library
- Search: tên brand/page của đối thủ
- Filter: "All ads" + Country: Vietnam + Status: Active
- Chú ý: Ads chạy lâu nhất = ads đang profitable nhất

## 3. Execution Steps

### Bước 1: Thu thập và phân loại ads
1.1 Nếu user đã paste nội dung → phân tích trực tiếp.
1.2 Nếu chưa có → hướng dẫn lấy data từ Meta Ads Library.
1.3 Phân loại ads theo tầng phễu:
- TOFU: hook về vấn đề/insight, không offer cụ thể
- MOFU: social proof, comparison, case study
- BOFU: offer cụ thể, deadline, discount
1.4 Ghi chú: Đối thủ đang tập trung ở tầng phễu nào nhiều nhất?

### Bước 2: Phân tích từng ads theo framework HOOK-BODY-CTA

**HOOK (3-5 giây đầu / dòng đầu tiên):**
- Hook dạng gì? (Câu hỏi / Shock statement / Số liệu / Pain point / Contradiction / Story opening)
- Hook nhắm vào Pain hay Desire?
- Hook cụ thể hay chung chung?

**BODY (phần giữa):**
- Cấu trúc: Problem → Solution → Proof? Hay trực tiếp vào offer?
- Có bằng chứng xã hội không? (Số liệu / Testimonial / Before-after)
- Nói về Feature, Benefit hay Transformation (kết quả sau khi dùng)?

**CTA (kêu gọi hành động):**
- CTA là gì? Có urgency đi kèm không?
- Offer cụ thể hay mơ hồ?

### Bước 3: Tổng hợp pattern ngành
3.1 Sau khi phân tích 5-10+ ads, tìm pattern:
- **Pattern Hook**: Dạng hook nào xuất hiện nhiều nhất?
- **Pattern Angle**: Góc tiếp cận nào phổ biến?
- **Pattern Offer**: Offer dạng nào đang nhiều nhất?
- **Pattern Format**: Static / Video / Carousel?

3.2 Ads chạy LÂU NHẤT = ads đang profitable nhất.

3.3 Điểm bão hòa: Angle nào đang được dùng QUÁ NHIỀU → KH đã quen/nhàm?

### Bước 4: Tìm khoảng trống creative
4.1 Dạng hook nào chưa ai dùng trong ngành?
4.2 Góc tiếp cận nào chưa ai thử?
   - Tất cả đang nói về lợi ích → thử nói về rủi ro khi không dùng
   - Tất cả dùng expert tone → thử peer tone (người đã trải qua kể lại)
4.3 Cảm xúc nào chưa ai khai thác?
4.4 Format nào chưa ai làm tốt?

### Bước 5: Đề xuất hypothesis để test
5.1 Đề xuất 3-5 hypothesis cụ thể:
- "Thử hook dạng [X] vì hiện tại chưa ai dùng trong ngành"
- "Thử angle [Y] vì angle hiện tại [Z] đang bão hòa"
5.2 Với mỗi hypothesis, đề xuất ad copy mẫu để test.
5.3 Gắn với framework testing: chỉ test 1 yếu tố mỗi lần.

## 4. Edge Cases & Error Handling

**Case 1: User không có ads cụ thể, chỉ muốn "insight ngành"**
→ Hướng dẫn: "Vào facebook.com/ads/library, search 3-5 đối thủ, copy nội dung ads đang active, paste vào đây."
→ Không thể phân tích nếu không có data thật.

**Case 2: User paste quá nhiều ads cùng lúc (> 10 ads)**
→ Phân tích 5 ads chạy lâu nhất trước (lâu = profitable).
→ Sau đó tổng hợp pattern tổng thể.

**Case 3: Ads của đối thủ trông rất giống nhau**
→ Đây là pattern quan trọng: "Ngành này đang có ad fatigue — tất cả trông như nhau."
→ Khoảng trống: bất kỳ điều gì khác biệt đều có cơ hội.

**Case 4: User muốn copy ads đối thủ**
→ Flag: "Copy ads thường fail vì KH đã quen với original và tạo confusion brand."
→ Mục tiêu spy ads là tìm insight, không phải copy.

## References

- `brandformance-ads.md` → Phần VII (Content Brandformance trong Ads)
- `brandformance-content.md` → Phần IV (Ma trận content theo tầng phễu)

Framework đánh giá ads nhanh:
- Ads chạy > 2 tuần = đang có ROI
- Ads có nhiều biến thể = brand đang test → học từ cái nào có nhiều version nhất
- Hook dạng Pain Point hiệu quả với TOFU; Desire hiệu quả với MOFU/BOFU
