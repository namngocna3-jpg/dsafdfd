---
name: brandformance-lead-scoring
description: "Kích hoạt khi cần xây bảng điểm phân loại lead MQL/SQL và quy trình phối hợp Marketing-Sale. Trigger: 'lead scoring', 'phân loại MQL SQL', 'bảng điểm lead', 'lead nào nên chuyển sale', 'chấm điểm lead', 'sale không biết lead nào ưu tiên gọi'."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Lead Scoring

## 1. Triggers

### Explicit triggers
- "lead scoring", "bảng điểm lead", "phân loại MQL/SQL"
- "lead nào nên chuyển cho sale?", "chấm điểm lead"

### Implicit triggers
- Sale phàn nàn "lead marketing gửi qua toàn rác"
- Marketing không biết ưu tiên follow-up lead nào trước
- Tỉ lệ lead → chốt thấp dù số lượng lead nhiều
- Chưa có quy trình rõ ràng giữa lúc nào Marketing nurture, lúc nào Sale tiếp nhận

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Nguồn lead và hành vi có thể track
- [ ] **[BẮT BUỘC]** Quy trình Sale hiện tại (ai nhận lead, gọi trong bao lâu)
- [ ] **[NẾU CÓ]** Data lịch sử: lead có hành vi nào thường chốt cao nhất

## 3. Execution Steps

### Bước 1: Phân biệt tiêu chí Explicit vs Implicit
- **Explicit (Fit)**: Đúng persona, đúng ngân sách, đúng địa lý/ngành
- **Implicit (Intent)**: Hành vi thực tế — xem pricing, tải nhiều tài liệu, mở email liên tục

Fit cao + Intent thấp = MQL (cần nurture thêm). Fit cao + Intent cao = SQL (chuyển Sale ngay).

### Bước 2: Build bảng điểm cụ thể theo ngành

| Tiêu chí | Loại | Điểm tối đa |
|---|---|---|
| Đúng Customer Persona | Explicit | 20 |
| Có ngân sách phù hợp mức giá | Explicit | 20 |
| Intent signal rõ (xem pricing, hỏi giá) | Implicit | 25 |
| Tiếp xúc brand ≥2 lần | Implicit | 20 |
| Phản hồi nhanh khi được liên hệ | Implicit | 15 |

Với B2B/giá cao: tăng trọng số Fit. Với B2C/giá thấp: tăng trọng số Intent.

### Bước 3: Ngưỡng phân loại và handoff rule

| Điểm | Phân loại | Hành động |
|---|---|---|
| ≥ 80 | SQL (Hot) | Sale gọi trong 2-4h |
| 60-79 | MQL (Warm) | Tiếp tục nurture, review lại sau 3 ngày |
| < 60 | Cold | Đưa vào nurture dài hạn, không chuyển Sale |

SLA bắt buộc: Lead đạt SQL mà Sale không liên hệ trong ngưỡng thời gian → escalate lên quản lý.

### Bước 4: Setup tracking
Cột cần có trong Sheet/CRM: Tên lead | Nguồn | Điểm Fit | Điểm Intent | Tổng điểm | Phân loại | Ngày đạt ngưỡng | Người phụ trách | Trạng thái | Kết quả cuối.

### Bước 5: Phối hợp Marketing–Sale
- Marketing chuyển lead kèm **lý do đạt điểm** để Sale biết nói chuyện gì
- Sale phản hồi ngược: lead này có thực sự chất lượng không → dùng để hiệu chỉnh lại trọng số
- Review hàng tháng: đối chiếu điểm số dự đoán với tỉ lệ chốt thực tế

## 4. Examples

### Example 1 — Dịch vụ B2B tư vấn thuế cho SME
```
LEAD A: Chủ shop online, doanh thu 200 triệu/tháng, đã tải bảng giá + hỏi trực tiếp
Fit: 20 + 20 = 40 / Intent: 25 + 20 = 45 / TỔNG: 85 → SQL → Sale gọi trong 2h

LEAD B: Sinh viên tải ebook miễn phí, chưa tương tác gì thêm
Fit: 5 + Intent: 0 / TỔNG: 5 → Cold → Vào nurture dài hạn
```

### Example 2 — Khóa học kỹ năng online
```
LEAD: Đăng ký học thử, tham gia đầy đủ, hỏi Zalo "học phí bao nhiêu, có trả góp không?"
Fit: 20 + 15 = 35 / Intent: 25 + 20 + 15 = 60 / TỔNG: 95 → SQL → Sale liên hệ ngay trong buổi

REVIEW SAU 1 THÁNG: Lead có điểm Intent > 60 chốt 45%; lead Intent < 40 chốt 8%
→ Điều chỉnh: tăng trọng số cho "tham gia học thử" lên 25 điểm
```

## 5. Edge Cases & Error Handling

**Lead điểm cao nhưng Sale không chốt được**: Vấn đề nằm ở Sales process/script, không phải chất lượng lead.
**Điểm số bị "lạm phát" do bot/spam**: Thêm bước xác thực số điện thoại/email thật.
**Một KH tương tác qua nhiều kênh bị tính điểm trùng**: Hợp nhất theo số điện thoại/email.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `CRITERIA_SETUP` | Xác định tiêu chí Fit + Intent |
| `SCORING_TABLE` | Build bảng điểm cụ thể |
| `THRESHOLD_SET` | Ngưỡng phân loại + SLA |
| `TRACKING_BUILD` | Setup Sheet/CRM tracking |
| `HANDOFF_RULE` | Quy trình Marketing-Sale |
| `DONE` | Lead Scoring Sheet hoàn chỉnh |

## References
- `brandformance-measurement.md` → Phần III (khung điểm gốc)
- `brandformance-customer.md` → Phần V (MQL/SQL)
- `brandformance-lead-conversion.md` → Xử lý sau khi lead thành SQL
- `brandformance-nurture-sequence.md` → Xử lý lead chưa đạt ngưỡng SQL
