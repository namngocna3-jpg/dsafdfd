---
name: brandformance-ads-tracking-setup
description: "Kích hoạt khi cần setup hoặc chẩn đoán hệ thống tracking cho ads — Pixel, Conversion API, Event Match Quality, UTM. Trigger: 'setup tracking ads', 'pixel không chạy đúng', 'conversion API', 'mất data ads sau iOS', 'event không khớp', 'tracking ads bị lỗi', 'không biết ads có track đúng không'. Kích hoạt cả khi số liệu ads bất thường mà nghi ngờ do lỗi tracking chứ không phải creative/audience."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: ads</summary>

# brandformance-ads

> Kiến thức về hệ thống Performance Ads trong Brandformance — đọc trước khi chạy bất kỳ skill ads.

## I. Khi nào nên chạy Ads

Ads là bước cuối cùng, không phải khởi đầu. Chỉ chạy khi: SP rõ + biết bán cho ai + có content đúng insight + có nơi để KH đi tiếp.

## II. Cấu trúc Campaign Meta Ads

Campaign (1 mục tiêu) → Ad Set (1 audience + 1 ngân sách) → Ad (1 creative)
Mỗi cấp chỉ có 1 biến để test. Không trộn mục tiêu trong cùng Campaign.

## III. Giai đoạn 1 — Testing

Mục tiêu: tìm content + audience work. Không tối ưu chi phí ở giai đoạn này.
Cấu trúc: 1 Campaign → 2-3 Ad Set → 2-3 Ads/Ad Set = 4-9 ads tổng.
Ngân sách: 100-300K/ngày/Ad Set. Tối thiểu 3-5 ngày. ~1-2 triệu để có data.
A/B Testing: thay 1 yếu tố/lần. Không đánh giá trước 3 ngày. Không sửa ad đang chạy ổn.

## IV. Giai đoạn 2 — Đo lường & Tối ưu

Vào sau khi Ads chạy ≥3 ngày, mỗi Ad Set ≥1.000 impressions.
Tắt: CTR < 0.8% sau 3 ngày không có lead.
Gom ngân sách về top performers.
Nhân bản Ads tốt sang audience khác.

## V. Giai đoạn 3 — Scale Up

Điều kiện scale: CTR > 2% + CPL ổn định 5-7 ngày + tỉ lệ chốt > 20%.
Scale dọc: tăng ngân sách ≤20-30%/lần, cách 2-3 ngày.
Scale ngang: nhân bản sang audience mới hoặc content mới.
Retarget: xem video >3s / nhắn tin chưa chốt / vào landing chưa để lại thông tin.

## VI. Ngưỡng chỉ số tham chiếu

CTR tốt: > 2% / Cần xem lại: < 0.8%
Frequency tốt: < 3 / Cần xem lại: > 3 trong 7 ngày
Tỉ lệ chốt tốt: > 20% / Cần xem lại: < 10%

Creative lifespan: audience nhỏ + ngân sách cao → mệt nhanh (1-2 tuần); audience lớn + ngân sách vừa → 4-6 tuần. Nên có creative mới sẵn sàng TRƯỚC khi frequency chạm ngưỡng 3.

## VII. Content Brandformance trong Ads

Mỗi ads = "2 trong 1": Branding (cảm xúc, câu chuyện) + Performance (CTA rõ, trigger hành động).
Mỗi tầng gắn Content Pillar chính + Angle cụ thể để dễ nhân bản theo tuần/tháng.

## VIII. Tracking & Attribution

Bắt buộc: Pixel + Conversion API chạy song song. Chỉ dùng Pixel (browser-side) không còn đủ tin cậy từ iOS 14.5+ và ad blocker — có thể mất 15-30% data thực tế. Conversion API (server-side) bù đắp phần mất.

Event Match Quality (EMQ) — tăng bằng cách gửi kèm email/SĐT đã hash trong sự kiện. EMQ thấp làm giảm hiệu quả tối ưu của thuật toán Meta dù creative/audience đúng.

UTM chuẩn hóa theo cấu trúc cố định (source/medium/campaign/content) cho mọi campaign để so sánh được qua thời gian.

## IX. Ngoài Meta — Google Search Ads

Meta/TikTok = Interruption — chen vào feed người chưa chủ động tìm kiếm, cần Hook mạnh để dừng scroll.
Google Search = Intent Capture — người dùng đã chủ động gõ từ khóa, không cần hook, cần đúng lúc đúng chỗ.

Chỉ chạy ads cho từ khóa Commercial investigation/Transactional. Không chạy cho Informational — dùng SEO/content thay thế.

Quality Score (ảnh hưởng CPC) phụ thuộc vào mức khớp giữa Từ khóa → Ad → Landing page.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Ads Tracking Setup

## 1. Triggers

### Explicit triggers
- "setup tracking ads", "cài pixel", "conversion API"
- "mất data ads sau iOS", "event không khớp"

### Implicit triggers
- Số liệu ads (lead/purchase) trên Meta thấp hơn nhiều so với thực tế ghi nhận thủ công
- Chuẩn bị chạy campaign mới, cần đảm bảo tracking đúng trước khi đổ ngân sách
- CPL tăng đột biến không rõ lý do — có thể do mất tracking chứ không phải creative/audience yếu

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Nền tảng ads đang dùng (Meta/TikTok) và website/landing page bán hàng
- [ ] **[BẮT BUỘC]** Sự kiện cần track theo funnel (ViewContent / Lead / Purchase)
- [ ] **[NẾU CÓ]** Google Tag Manager đã cài chưa, CMS/nền tảng landing page đang dùng

## 3. Execution Steps

### Bước 1: Xác định sự kiện cần track theo funnel
ViewContent (xem landing page) → Lead (điền form/inbox) → Purchase (mua hàng). Mỗi sự kiện cần track riêng, không gộp chung "Lead = Purchase".

### Bước 2: Setup Pixel + Conversion API song song
Chỉ dùng Pixel (browser-side) không còn đủ tin cậy từ khi iOS 14.5+ và ad blocker phổ biến — mất trung bình 15-30% data thực tế. Conversion API (server-side) gửi lại cùng sự kiện từ server, bù đắp phần mất, tăng độ chính xác tối ưu hóa của Meta.

### Bước 3: Kiểm tra Event Match Quality (EMQ)
EMQ đo mức độ Meta khớp được sự kiện với đúng người dùng. Tăng EMQ bằng cách gửi kèm thông tin đã hash: email, số điện thoại, tên. EMQ càng cao, thuật toán tối ưu càng chính xác.

### Bước 4: UTM structure chuẩn
```
utm_source=facebook (hoặc tiktok/google)
utm_medium=paid_social (hoặc cpc)
utm_campaign=[tên campaign]
utm_content=[tên ad/creative để phân biệt A/B test]
```
Không đổi cấu trúc UTM giữa các campaign — giữ nhất quán để so sánh được qua thời gian.

### Bước 5: Test tracking trước khi launch
Dùng Meta Events Manager Test Events (hoặc TikTok Events Manager) để xác nhận sự kiện bắn đúng, đúng giá trị, trước khi đổ ngân sách thật.

### Bước 6: Build Tracking Health Checklist định kỳ
Checklist kiểm tra hàng tháng: Pixel còn hoạt động? Conversion API còn gửi data? EMQ có giảm không? Có sự kiện nào bị duplicate không?

## 4. Examples

### Example 1 — Website WordPress bán dịch vụ sửa chữa nhà
```
SETUP:
- Pixel Meta cài qua plugin, bắn ViewContent khi vào trang dịch vụ
- Conversion API cài qua plugin CAPI — gửi lại sự kiện Lead khi form submit
- Form submit gửi kèm email + SĐT đã hash → EMQ tăng từ 4.2 lên 7.8/10

UTM: utm_source=facebook&utm_medium=paid_social&utm_campaign=sua_nha_thang8&utm_content=hook_pain_v1

TEST: Dùng Test Events — xác nhận Lead bắn đúng giá trị ước tính (300K/lead) trước khi launch thật
```

### Example 2 — Landing page đăng ký khóa học (Ladipage/GHL)
```
VẤN ĐỀ PHÁT HIỆN: CPL tăng gấp đôi trong 2 tuần dù creative không đổi
CHẨN ĐOÁN: Kiểm tra Events Manager → EMQ giảm còn 2.1/10, phát hiện form mới không gửi kèm SĐT/email hash

FIX: Cấu hình lại form để gửi Advanced Matching data → EMQ tăng lại 6.5/10 → CPL giảm về mức cũ sau 5 ngày

BÀI HỌC: Mỗi lần đổi landing page builder/form, PHẢI kiểm tra lại EMQ trước khi kết luận creative/audience có vấn đề.
```

## 5. Edge Cases & Error Handling

**Conversion API set up sai gây duplicate event**: Kiểm tra Event ID trùng khớp giữa Pixel và Conversion API (deduplication).

**Landing page builder không cho chèn code tùy chỉnh**: Ưu tiên chọn nền tảng hỗ trợ Conversion API tích hợp sẵn.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `EVENT_DEFINE` | Xác định sự kiện cần track |
| `PIXEL_CAPI_SETUP` | Setup Pixel + Conversion API |
| `EMQ_CHECK` | Kiểm tra và cải thiện EMQ |
| `UTM_STRUCTURE` | Chuẩn hóa UTM |
| `TEST_VERIFY` | Test trước khi launch |
| `DONE` | Tracking Health Checklist hoàn chỉnh |

## References
- `brandformance-ads-setup.md` → Checklist pre-setup
- `brandformance-ads-report.md` → Số liệu chỉ đáng tin khi tracking đúng
- `brandformance-landing-page.md` → Nơi đặt tracking code
