---
name: brandformance-competitor-map
description: "Kích hoạt khi cần vẽ bản đồ cạnh tranh theo tư duy Brandformance — phân tích đối thủ 5 góc, tìm khoảng trống brand chưa ai chiếm và khoảng trống offer chưa ai khai thác. Trigger: 'phân tích đối thủ', 'competitor map', 'đối thủ đang làm gì', 'khoảng trống thị trường', 'so sánh với đối thủ', 'tôi khác đối thủ ở điểm nào', 'đối thủ đang định vị ra sao'. Kích hoạt cả khi chuẩn bị tạo positioning hoặc khi CPL tăng do cạnh tranh trong ngách tăng."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Competitor Map

## 1. Triggers

### Explicit triggers
- "phân tích đối thủ cạnh tranh", "competitor map"
- "đối thủ đang làm gì?", "đối thủ đang định vị ra sao?"
- "tôi khác đối thủ ở điểm nào?", "khoảng trống thị trường là gì?"
- "so sánh với [tên đối thủ cụ thể]"

### Implicit triggers
- CPL đang tăng dần dù không thay đổi gì → cạnh tranh trong ngách đang tăng
- KH hay so sánh brand với đối thủ cụ thể trong inbox
- Sắp launch positioning mới → cần map để tránh trùng lặp
- Đối thủ vừa chạy campaign lớn → cần đánh giá tác động

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Danh sách 3-5 đối thủ cạnh tranh chính (tên brand + website/fanpage)
- [ ] **[BẮT BUỘC]** Ngành hàng và sản phẩm/dịch vụ của brand đang phân tích
- [ ] **[NẾU CÓ]** Phân khúc KH đang target
- [ ] **[NẾU CÓ]** Objection KH hay so sánh
- [ ] **[NẾU CÓ]** Điểm mạnh hiện tại của brand

Đọc trước khi thực hiện:
- `brandformance-framework.md` → Phần II (Bản chất Brandformance)
- `brandformance-customer.md` → Phần II (Cắt lát) — để biết đối thủ đang serve phân khúc nào

## 3. Execution Steps

### Bước 1: Thu thập thông tin về từng đối thủ
1.1 Với mỗi đối thủ, thu thập:
- Họ đang nói gì với KH? (tagline, messaging chính)
- Sản phẩm/dịch vụ chính và mức giá (nếu public)
- Kênh marketing chính đang dùng
- Điểm mạnh từ reviews/testimonials
- Điểm yếu từ reviews tiêu cực hoặc comment phàn nàn

1.2 Phân loại đối thủ theo 3 tầng:
- **Trực tiếp**: Cùng sản phẩm, cùng phân khúc KH
- **Gián tiếp**: Khác sản phẩm nhưng cùng giải quyết vấn đề
- **Thứ cấp**: KH có thể chọn thay thế (kể cả "tự làm" hoặc "không làm gì")

### Bước 2: Phân tích 5 góc cạnh tranh Brandformance

**Góc 1 — BRAND POSITIONING: Họ đang định vị là ai?**
- Tagline/slogan chính là gì?
- Personality: nghiêm túc/vui vẻ, cao cấp/bình dân, expert/friend?

**Góc 2 — CONTENT & MESSAGING: Họ đang nói gì và nói như thế nào?**
- Điểm đau KH họ đang khai thác là gì?
- Hook/angle thường dùng nhất?
- Tầng phễu chủ yếu: TOFU / MOFU / BOFU?

**Góc 3 — OFFER & PRICING: Họ đang bán gì và như thế nào?**
- Offer structure và mức giá?
- Lead magnet / hook offer đang dùng?

**Góc 4 — CHANNEL & DISTRIBUTION: Họ reach KH từ đâu?**
- Kênh chủ lực?
- Có kênh nào mình chưa có?

**Góc 5 — BRAND PERCEPTION: KH thật sự nghĩ gì về họ?**
- Review tích cực hay nhắc điều gì nhiều nhất?
- Review tiêu cực hay phàn nàn điều gì?

### Bước 3: Tạo bảng Competitor Map tổng hợp

| Đối thủ | Brand Positioning | Content Angle | Price Point | Kênh chủ lực | Điểm mạnh | Điểm yếu |
|---|---|---|---|---|---|---|
| Đối thủ A | | | | | | |
| Đối thủ B | | | | | | |
| [Brand của bạn] | | | | | | |

### Bước 4: Tìm khoảng trống Brandformance
4.1 **Khoảng trống BRAND**: Góc positioning nào chưa ai chiếm?
4.2 **Khoảng trống CONTENT**: Topic/angle nào chưa ai khai thác?
4.3 **Khoảng trống OFFER**: Có nhu cầu nào chưa được phục vụ?
4.4 **Khoảng trống CHANNEL**: Kênh nào đối thủ chưa khai thác tốt?

### Bước 5: Xác định góc khác biệt hóa
5.1 Đề xuất 2-3 góc khác biệt hóa khả thi dựa trên khoảng trống.
5.2 Với mỗi góc, đánh giá:
- Phù hợp với thực lực hiện tại của brand không?
- Đủ phân khúc KH để tạo doanh thu không?
- Bền vững không (đối thủ có copy được dễ không)?
5.3 Recommend góc tốt nhất với lý do cụ thể.
5.4 Đề xuất: "Mang góc này vào brandformance-positioning."

## 4. Edge Cases & Error Handling

**Case 1: Không biết đối thủ là ai**
→ Hỏi: "Khi KH không chọn bạn, họ thường chọn gì thay thế?" → Tiết lộ đối thủ thật sự.

**Case 2: Thị trường có quá nhiều đối thủ nhỏ lẻ**
→ Dấu hiệu chưa có "category leader" → cơ hội chiếm vị trí đó.
→ Phân tích pattern chung thay vì phân tích từng đối thủ.

**Case 3: Đối thủ lớn hơn nhiều (startup vs đa quốc gia)**
→ Tìm "vùng bỏ ngỏ" mà đối thủ lớn không serve vì quá nhỏ với họ.

**Case 4: User muốn copy chiến lược đối thủ**
→ Flag: "Copy chiến lược = luôn đi sau và không bao giờ dẫn đầu."
→ Mục tiêu của competitor map là TÌM KHOẢNG TRỐNG, không phải copy.

**Case 5: Không có thông tin public về đối thủ**
→ Dùng proxy: Review Google Maps, comment Facebook page.
→ "Điều KH phàn nàn về đối thủ" thường là cơ hội lớn nhất.

## References

- `brandformance-framework.md` → Phần II (Bản chất Brandformance: differentiation = conversion lever)
- `brandformance-customer.md` → Phần II (Cắt lát) — đối thủ đang serve phân khúc nào

Nguyên tắc tìm khoảng trống:
- Brand: "Cảm xúc nào chưa ai tạo ra trong ngành này?"
- Content: "Câu hỏi nào KH hay hỏi mà không ai trả lời tốt?"
- Offer: "KH phải tự 'ghép' gì vì không có giải pháp đầy đủ?"
- Channel: "KH đang ở đâu mà đối thủ chưa có mặt?"
