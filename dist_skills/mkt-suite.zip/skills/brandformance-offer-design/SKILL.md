---
name: brandformance-offer-design
description: >
  Thiết kế Offer Ladder 5 tầng: Hook Offer→Lead Magnet→Tripwire→Core Offer→Upsell. Kích hoạt khi: "thiết kế offer", "offer ladder", "offer strategy", "tạo offer", "hook offer", "lead magnet", "tripwire", "upsell strategy", "offer cho từng giai đoạn phễu".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Offer Design

## 1. Triggers

### Explicit triggers
- "thiết kế offer / lead magnet", "mồi câu / hook"  
- "chuỗi chuyển đổi", "tripwire offer"  
- "offer có hấp dẫn không?", "tôi nên cho gì miễn phí?"  

### Implicit triggers
- Ads đang chạy nhưng không có ai để lại thông tin → Lead Magnet không hấp dẫn  
- KH vào landing page nhưng không điền form → Offer không đủ giá trị  
- Tỉ lệ từ free → paid rất thấp → Tripwire không bridge tốt  

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Sản phẩm/dịch vụ chính (Core Offer)  
- [ ] **[BẮT BUỘC]** Customer Insight đã có (3 nhóm Cold/Warm/Hot)  
- [ ] **[BẮT BUỘC]** Positioning đã có  
- [ ] **[NẾU CÓ]** Ngân sách offer và tỉ lệ chuyển đổi hiện tại  

Đọc trước: `brandformance-customer.md` → Phần III (Câu nói nội tâm)  

## 3. Execution Steps

### Bước 1: Xác định vấn đề mà từng tầng offer phải giải quyết
- Pain Point lớn nhất của nhóm Lạnh → Làm Hook  
- Vấn đề ngay trước khi mua của nhóm Ấm → Làm Lead Magnet  
- Rào cản cuối của nhóm Nóng → Làm Tripwire / Risk Reversal  

Nguyên tắc: Offer phải phản ánh Positioning, không chỉ là ưu đãi giảm giá.  

### Bước 2: Thiết kế 5 tầng Offer Ladder

**Tầng 1 — Hook (Không tốn tiền, tốn chú ý)**  
- Không phải offer, là content TOFU  
- Format: "Câu hỏi khiến KH nói 'đúng là mình đang gặp vấn đề này'"  

**Tầng 2 — Lead Magnet (Miễn phí, đổi thông tin liên lạc)**  
- Điều kiện tốt: Giải quyết 1 vấn đề cụ thể / Dùng được ngay / Gợi nhu cầu về Core Offer  
- Format: Checklist / Template / Mini-course / Webinar / Audit / Free consultation  

**Tầng 3 — Tripwire (Giá thấp: 99K-500K)**  
- Mục tiêu: Chuyển KH từ "tin miễn phí" → "đã trả tiền" → tâm lý committed  
- Giá phải đủ thấp để "mua không cần suy nghĩ nhiều"  
- Tripwire ≠ Core Offer rẻ đi — phải là sản phẩm/dịch vụ riêng  

**Tầng 4 — Core Offer (Giá chính)**  
- Giải quyết vấn đề hoàn toàn, tạo transformation  
- Nhất quán với Positioning và Lead Magnet  

**Tầng 5 — Upsell/Cross-sell (Sau khi KH mua)**  
- Timing: Ngay sau khi KH mua hoặc sau khi đạt kết quả đầu tiên  
- Upsell = "cấp độ tiếp theo" tự nhiên  

### Bước 3: Viết 5 Hook options cho brand cụ thể
- Hook dạng Pain: "[Vấn đề X] mà nhiều người không biết tại sao"  
- Hook dạng Contradiction: "Tại sao [kết quả Y] không đến dù đã làm đúng?"  
- Hook dạng Số liệu: "[Z%] người gặp vấn đề X mà không biết giải pháp"  
- Hook dạng Câu hỏi: "Bạn có đang mắc [lỗi X] không?"  
- Hook dạng Story: "Cách [person] giải quyết [vấn đề X]"  

Chọn 2 hook để test.  

### Bước 4: Thiết kế Lead Magnet cụ thể
Brainstorm 3-5 LM options, đánh giá theo:  
- Dễ consume (< 20 phút để get value) — không phải ebook 50 trang  
- Actionable ngay — làm được trong ngày hôm nay  
- Bridge đến Core Offer — sau khi dùng LM, KH tự thấy cần Core Offer hơn  

### Bước 5: Compile Offer Design document
- Offer Ladder đầy đủ với mô tả, giá, format.  
- Chuỗi: LM → Thank-you page → Email sequence.  
- Tripwire → Core Offer bridge.  

## 4. Examples

### Example 1 — Generic: Dịch vụ thiết kế logo và brand identity
**Input:** Core Offer: Brand identity 15-40 triệu. Positioning: "Không phải thiết kế đẹp — là thiết kế giúp brand được nhớ." Insight KH: "Lo sợ brief sai → tốn tiền sửa"  

**Output:**  
```
OFFER LADDER — Brand Identity

HOOK:
"Tại sao logo SME trông giống nhau dù đã thuê designer đắt tiền?"

LEAD MAGNET — Miễn phí:
"Brand Brief Template: 2 trang để brief designer chính xác — giảm sửa đi sửa lại"
→ Bridge: Sau khi có brief tốt → KH tự thấy cần designer giỏi để execute

TRIPWIRE — 299K:
"Brand Audit 30 phút: Review logo/brand hiện tại — chỉ ra 3 điểm cần sửa ngay"
→ Tạo trust → Bridge đến Core Offer

CORE OFFER — 15-40 triệu:
"Gói Brand Identity toàn diện: Logo + Brand Guide + 5 collateral"

UPSELL:
"Brand Extension Package: Social media kit + Email template + Pitch deck" — 5-8 triệu

HOOK OPTIONS (2 để test):
1. "Bạn đã trả X triệu cho logo nhưng KH vẫn không nhớ brand? Tại sao?"
2. "5 lý do logo SME VN trông amateur dù thuê designer professional"
```

### Example 2 — Giáo dục: Khóa học kỹ năng thuyết trình
**Input:** Core Offer: Khóa online 4 tuần 3.5 triệu. Positioning: "Dành cho người có nội dung tốt nhưng không truyền được cảm hứng."  

**Output:**  
```
OFFER LADDER — Khóa Thuyết Trình

HOOK:
"Sao chuẩn bị kỹ mà buổi presentation vẫn không thuyết phục được sếp/KH?"

LEAD MAGNET — Miễn phí:
"Presentation Scorecard: Tự chấm điểm 10 kỹ năng thuyết trình trong 5 phút"
→ KH biết chính xác mình yếu ở đâu → cần khóa học để fix đúng điểm

TRIPWIRE — 199K:
"Mini-course 1 giờ: 3 kỹ thuật giúp phần mở đầu gây ấn tượng ngay"

CORE OFFER — 3.5 triệu:
"Khóa học 4 tuần: Từ nervous → confident presenter"

UPSELL: "3 buổi 1-on-1 coaching" — 1.5 triệu

HOOK OPTIONS:
1. "Bạn có nội dung tốt nhưng audience vẫn nhìn điện thoại khi bạn thuyết trình?"
2. "Điểm thuyết trình của bạn là mấy? [Link Scorecard]"
```

## 5. Edge Cases & Error Handling

**Case 1: KH không download Lead Magnet**  
→ A/B test title LM trước (không phải toàn bộ LM).  
→ Checklist: Title < 8 từ, lợi ích rõ dòng đầu, form < 3 trường.  

**Case 2: KH download LM nhưng không mua Core Offer**  
→ LM đang giải quyết quá hoàn chỉnh → KH không cần Core Offer nữa.  
→ Fix: LM chỉ giải quyết 1 bước đầu, không phải toàn bộ.  

**Case 3: Không có resource tạo LM phức tạp**  
→ LM đơn giản: Consultation miễn phí 20-30 phút.  
→ Hoặc: Checklist text thuần, không cần design.  

**Case 4: Ngành không phù hợp với "tải về"**  
→ Ví dụ: F&B, thời trang → "thử trực tiếp" phù hợp hơn.  
→ Thay LM bằng: Sample miễn phí, Discount code, Trải nghiệm thử.  

## 6. State Management

| State | Mô tả | Claude làm gì |  
|---|---|---|  
| `INSIGHT_READING` | Đọc Customer Insight | Chạy Bước 1 |  
| `LADDER_DESIGN` | Thiết kế 5 tầng | Chạy Bước 2 |  
| `HOOK_WRITING` | Viết 5 hook options | Chạy Bước 3 |  
| `LM_DESIGN` | Thiết kế Lead Magnet | Chạy Bước 4 |  
| `COMPILING` | Compile Offer Design | Chạy Bước 5 |  
| `DONE` | Hoàn chỉnh | Đề xuất: "brandformance-landing-page để thiết kế trang thu lead" |  

## References

- `brandformance-customer.md` → Phần III (Câu nói nội tâm = input cho Hook)  
- `brandformance-framework.md` → Phần VI (Offer Ladder)  

Lead Magnet chuẩn:  
- Specific: "Checklist 10 bước để X" tốt hơn "Guide về X"  
- Immediate: KH nhận giá trị trong 24h sau khi tải  
- Bridge: Sau khi dùng LM → KH tự hỏi "cần [Core Offer] để làm tốt hơn nữa"  
