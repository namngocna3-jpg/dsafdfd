---
name: brandformance-next-cycle
description: "Kích hoạt khi cần lập kế hoạch chu kỳ marketing tiếp theo dựa trên bằng chứng từ Campaign Memory — nhân bản winner, loại bỏ loser, test hypothesis mới. Đây là skill 'Data-Driven Next Action': BẮT BUỘC quét Campaign Memory/Retrospective trước, không lập plan từ ngữ cảnh chung. Trigger: 'plan chu kỳ tiếp theo', 'next cycle', 'campaign tiếp theo dựa trên data cũ', 'nhân bản winner', 'lên kế hoạch dựa trên bài học lần trước'. LUÔN quét Campaign Memory TRƯỚC KHI viết plan mới — đây là điểm khác biệt cốt lõi của skill này."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Next Cycle

## Triết lý cốt lõi

Chu kỳ marketing tốt nhất không bắt đầu từ trang giấy trắng — nó **đúc kết từ chu kỳ trước**. Skill này bắt buộc phải quét Campaign Memory trước khi viết bất kỳ dòng plan nào.

## 1. Triggers

### Explicit triggers
- "plan chu kỳ tiếp theo", "next cycle", "campaign tiếp theo dựa trên data cũ"
- "nhân bản winner", "lên kế hoạch dựa trên bài học lần trước"

### Implicit triggers
- Vừa hoàn thành `brandformance-campaign-retrospective.md` → bước tự nhiên tiếp theo
- Đầu tháng/quý mới, cần plan nhưng có sẵn data chu kỳ trước
- Đã chạy nhiều campaign nhưng mỗi lần đều lập plan lại từ đầu, không tận dụng bài học cũ

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Campaign Retrospective / Campaign Memory từ chu kỳ trước — nếu chưa có, PHẢI chạy `brandformance-campaign-retrospective.md` trước
- [ ] **[BẮT BUỘC]** Mục tiêu của chu kỳ mới (doanh thu/KPI)
- [ ] **[NẾU CÓ]** Ngân sách mới, thay đổi thị trường/mùa vụ

Đọc trước khi thực hiện:
- `brandformance-campaign-retrospective.md` → Bắt buộc quét trước
- `brandformance-campaign-plan.md` → Template để áp dụng evidence vào

## 3. Execution Steps

### Bước 1 (BẮT BUỘC) — Quét Campaign Memory trước khi làm gì khác
Không được viết plan mới nếu chưa quét retrospective gần nhất. Nếu user chưa cung cấp và chưa từng chạy retrospective → dừng lại, đề xuất chạy `brandformance-campaign-retrospective.md` trước, hoặc nếu đây là chu kỳ đầu tiên → chuyển sang dùng `brandformance-campaign-plan.md` thông thường.

### Bước 2: Tổng hợp Evidence Summary
```
WINNER cần nhân bản: [Hook/audience/creative/kênh nào đã proven]
LOSER cần loại bỏ: [Cái gì đã thử và không work — không lặp lại]
INSIGHT KH MỚI: [Câu hỏi/objection/ngôn ngữ mới phát hiện chu kỳ trước]
HYPOTHESIS MỚI cần test: [Ý tưởng chưa thử, dựa trên khoảng trống nhìn thấy]
```

### Bước 3: Thiết kế chu kỳ mới dựa trên evidence
Áp dụng vào cấu trúc Campaign Plan (`brandformance-campaign-plan.md`) nhưng mỗi quyết định phải trace được về 1 dòng evidence cụ thể — không phải best practice chung chung.

### Bước 4: Dành 20-30% ngân sách/nỗ lực cho hypothesis mới
Nguyên tắc: không chỉ lặp lại y hệt chu kỳ trước dù nó work — thị trường bão hòa dần. Giữ phần lớn ngân sách cho winner đã proven, nhưng luôn dành phần nhỏ để test điều mới.

### Bước 5: Compile Next Cycle Plan
Bao gồm section đặc trưng "ĐÃ HỌC TỪ CHU KỲ TRƯỚC" ở đầu document — đây là dấu hiệu nhận diện của skill này.

### Bước 6: Confirm với user trước khi finalize
Hỏi lại: Evidence summary có đúng thực tế không? Có insight quan trọng nào bị bỏ sót không?

## 4. Examples

### Example 1 — Generic: Dịch vụ tư vấn tài chính (chu kỳ Q4 dựa trên Q3)
```
QUÉT MEMORY (từ brandformance-campaign-retrospective Q3):
Winner: Hook "3 lỗi tài chính phổ biến" (CTR 2.1%), Retarget video viewers 75%+ (chốt 35%)
Loser: Audience Broad trong mùa cao điểm (CPM cao gấp đôi)
Insight mới: KH ở tỉnh quan tâm tư vấn online nhưng ngại hỏi

NEXT CYCLE PLAN Q4:
ĐÃ HỌC TỪ Q3: Nhân bản hook "3 lỗi phổ biến" dạng mới cho nhóm KH khác; bỏ hẳn Broad targeting;
khai thác insight "tư vấn online cho tỉnh" thành 1 angle riêng.

70% ngân sách: Nhân bản công thức đã proven (hook dạng lỗi phổ biến + Retarget video viewers)
30% ngân sách: Test hypothesis mới — Campaign riêng "Tư vấn tài chính online cho KH tỉnh xa"
```

### Example 2 — Giáo dục: Khóa học AI (chu kỳ khai giảng tiếp theo)
```
QUÉT MEMORY: Winner: Webinar là cầu nối chuyển đổi chính (60% webinar attendee → đăng ký)
Loser: Email FAQ dài dòng, CTR thấp
Insight mới: Học viên đăng ký nhiều sau khi xem recording, không chỉ live

NEXT CYCLE PLAN:
ĐÃ HỌC: Giữ webinar làm trục chính; rút gọn FAQ theo đúng câu hỏi thật; gửi recording sớm hơn (D+1)

75% ngân sách: Lặp lại mô hình Webinar → Nurture → BOFU đã proven, cải thiện email FAQ và
timing gửi recording theo insight mới
25% ngân sách: Test hypothesis — mở thêm 1 buổi Q&A nhỏ riêng cho nhóm xem recording
(chưa từng thử ở chu kỳ trước) để xem có tăng tỉ lệ chuyển đổi thêm không
```

## 5. Edge Cases & Error Handling

**Không có Campaign Memory/Retrospective từ trước (lần đầu chạy)**: Không thể dùng skill này — chuyển sang `brandformance-campaign-plan.md` thông thường và đề xuất chạy retrospective ngay sau khi chu kỳ này kết thúc để có evidence cho lần sau.

**Thị trường thay đổi lớn khiến data cũ không còn relevant** (mùa vụ khác hẳn, đối thủ mới xuất hiện): Vẫn quét Memory nhưng gắn cờ rõ "evidence này có thể không còn áp dụng do [lý do]" — không bỏ qua hoàn toàn nhưng giảm trọng số.

**User muốn thử hoàn toàn hướng mới, không nhân bản gì từ chu kỳ trước**: Vẫn nên giữ tối thiểu 1 kênh baseline đã proven để không mất hoàn toàn nguồn thu trong lúc test hướng mới — không all-in vào chưa biết.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `MEMORY_SCAN` | Quét Campaign Retrospective — BẮT BUỘC đầu tiên |
| `EVIDENCE_SUMMARY` | Tổng hợp Winner/Loser/Insight/Hypothesis |
| `PLAN_DESIGN` | Thiết kế chu kỳ mới dựa trên evidence |
| `BUDGET_SPLIT` | Phân bổ 70-80% nhân bản / 20-30% test mới |
| `CONFIRM` | Xác nhận evidence với user |
| `DONE` | Next Cycle Plan hoàn chỉnh |

## Lưu ý quan trọng

- **Không bao giờ** bắt đầu viết plan trước khi quét Campaign Memory — đây là quy tắc bất biến của skill này
- Nếu không có đủ evidence → nói thẳng: "Chưa có đủ dữ liệu từ chu kỳ trước để lập plan evidence-based, cần chạy Campaign Retrospective trước"
- Document luôn có section "ĐÃ HỌC TỪ CHU KỲ TRƯỚC" — dấu hiệu nhận diện skill này

## References
- `brandformance-campaign-retrospective.md` → Bắt buộc quét trước
- `brandformance-campaign-plan.md` → Template áp dụng evidence
- `brandformance-content-report.md`, `brandformance-ads-report.md`, `brandformance-email-report.md` → Nguồn evidence bổ sung
