---
name: brandformance-seasonal-plan
description: >
  Phân loại tháng A/B/C theo doanh thu, phân bổ ngân sách theo mùa vụ, prep timeline. Kích hoạt khi: "kế hoạch theo mùa", "seasonal plan", "phân bổ ngân sách theo tháng", "tháng cao điểm", "Tết", "lịch marketing năm", "phân loại tháng A B C".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Seasonal Plan

## 1. Triggers

### Explicit triggers
- "kế hoạch theo mùa", "seasonal plan", "phân loại tháng A B C"
- "phân bổ ngân sách theo tháng", "tháng cao điểm"
- "lịch marketing năm", "Tết", "lịch mùa vụ"

### Implicit triggers
- Đầu năm → cần plan marketing cho cả năm
- Sắp vào mùa cao điểm nhưng chưa chuẩn bị
- Budget đang phân bổ đều tháng → cần tối ưu theo mùa

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Ngành hàng và tính mùa vụ
- [ ] **[BẮT BUỘC]** Data doanh thu theo tháng (12 tháng gần nhất nếu có)
- [ ] **[BẮT BUỘC]** Ngân sách marketing năm
- [ ] **[NẾU CÓ]** Sự kiện ngành, ngày lễ quan trọng

## 3. Execution Steps

### Bước 1: Phân loại tháng A/B/C theo doanh thu

**Tháng A (Cao điểm — top 30% doanh thu):**
- Tăng ngân sách 130-150% so với baseline
- Focus: Conversion + Retention
- Prep: 4-6 tuần trước

**Tháng B (Trung bình — 40-60% doanh thu):**
- Ngân sách baseline
- Focus: Balanced brand + performance
- Duy trì hoạt động thường xuyên

**Tháng C (Thấp điểm — bottom 30% doanh thu):**
- Giảm ngân sách 70-80% so với baseline
- Focus: Brand building, content creation, chuẩn bị cho A
- Cơ hội: CPM/CPL rẻ hơn → build audience rẻ hơn

### Bước 2: Calendar mùa vụ theo ngành

**Ngành chung (VN):**
- Tháng A: Tháng 1 (Tết), 8-9 (Back to school), 11-12 (Year-end)
- Tháng B: Tháng 3-4, 6-7
- Tháng C: Tháng 2 (sau Tết), 5, 10

**Điều chỉnh theo ngành:**
- F&B: Mùa hè (5-8) là A; Sau Tết là C
- Giáo dục: 7-8 (khai giảng) là A; 1-2 là C
- Thời trang: 1 (Tết), 11-12 (winter) là A

### Bước 3: Phân bổ ngân sách theo mùa

Tổng ngân sách năm → phân bổ theo trọng số:
- Tháng A: 1.4× baseline/tháng
- Tháng B: 1.0× baseline/tháng
- Tháng C: 0.7× baseline/tháng

Verify: Tổng = 12 tháng × baseline. Điều chỉnh để khớp tổng ngân sách.

### Bước 4: Prep Timeline cho tháng A

- D-42 (6 tuần trước): Lên kế hoạch campaign, brief creative
- D-28 (4 tuần trước): Sản xuất creative, setup tracking
- D-14 (2 tuần trước): Warm up audience, teasing content
- D-7: Final check, approve assets
- D-Day: Launch full campaign
- D+14: Review, optimize

### Bước 5: Build Seasonal Calendar document

| Tháng | Loại | Ngân sách | Focus | Prep deadline |
|---|---|---|---|---|
| T1 (Tết) | A | X triệu | Conversion | 15/11 |
| T2 | C | Y triệu | Brand building | - |
| ... | ... | ... | ... | ... |

## 4. Examples

### Example 1 — Spa làm đẹp
```
PHÂN LOẠI:
Tháng A: T1 (Tết), T3 (8/3), T11 (Black Friday)
Tháng B: T4, T5, T9, T10
Tháng C: T2 (sau Tết), T6, T7, T8 (hè thấp điểm), T12

NGÂN SÁCH (24 triệu/tháng baseline):
T1: 34 triệu | T3: 30 triệu | T11: 34 triệu
Tháng B: 24 triệu/tháng
Tháng C: 17 triệu/tháng

PREP T1 (Tết):
15/11: Brief creative "Tết làm đẹp cùng gia đình"
01/12: Sản xuất xong creative
15/12: Warm up audience
25/12: Launch Phase 2 (Teasing)
01/01: Launch Phase 4 (Bung mạnh)
```

### Example 2 — Khóa học online
```
PHÂN LOẠI:
Tháng A: T7-T8 (back to school), T11-T12 (year-end upskill)
Tháng B: T1, T3-T4, T9-T10
Tháng C: T2, T5-T6

STRATEGY tháng C:
→ Sản xuất content hàng loạt (CPM rẻ → TOFU reach rẻ hơn)
→ Build email list (warm audience cho tháng A)
→ Testimonial collection từ học viên hiện tại
```

## 5. Edge Cases & Error Handling

**Không có data 12 tháng:**
→ Dùng calendar mùa vụ ngành làm baseline, điều chỉnh sau 3-6 tháng có data.

**Tháng C vẫn phải có doanh thu:**
→ Focus upsell/cross-sell KH cũ thay vì acquisition mới.
→ Offer đặc biệt cho existing customers.

**Budget không đủ để tăng tháng A:**
→ Giảm mạnh tháng C để "tích lũy" ngân sách cho tháng A.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `CLASSIFICATION` | Phân loại tháng A/B/C |
| `BUDGET_ALLOCATION` | Phân bổ theo mùa |
| `PREP_TIMELINE` | Tạo prep timeline tháng A |
| `CALENDAR_BUILD` | Build seasonal calendar |
| `DONE` | Đề xuất export vào Google Sheet |

## References

- `brandformance-framework.md` → Phần III (Campaign phases)
- `brandformance-budget-allocation.md` → Nguyên tắc phân bổ theo giai đoạn

Seasonal planning: Chuẩn bị tháng A từ 6 tuần trước. Tháng C không phải "nghỉ" — là thời gian build asset rẻ nhất.
