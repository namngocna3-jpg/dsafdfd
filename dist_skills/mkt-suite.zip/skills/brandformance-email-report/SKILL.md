---
name: brandformance-email-report
description: "Kích hoạt khi cần báo cáo hiệu quả Email/Zalo OA — open rate, CTR, unsubscribe theo từng email trong sequence, xác định điểm nghẽn. Trigger: 'báo cáo email', 'email report', 'open rate CTR', 'sequence nào không work', 'email không ai mở'. Kích hoạt cả khi kết thúc chu kỳ hoặc sequence chạy được 2-4 tuần cần đánh giá."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Email Report

## 1. Triggers

### Explicit triggers
- "báo cáo email tháng này", "email report", "open rate CTR sequence"
- "sequence nào đang không work?"

### Implicit triggers
- Welcome/Nurture/BOFU sequence đã chạy đủ lâu (≥2-4 tuần) cần đánh giá
- Unsubscribe rate tăng bất thường
- Chuẩn bị dùng `brandformance-next-cycle.md` hoặc cải thiện sequence hiện có

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Data từng email trong sequence: open rate, CTR, unsubscribe rate
- [ ] **[NẾU CÓ]** Benchmark từ `brandformance-email-plan.md` để so sánh
- [ ] **[NẾU CÓ]** Phân đoạn theo nguồn list (nếu có nhiều nguồn lead khác nhau)

Đọc trước khi thực hiện:
- `brandformance-email-plan.md` → Phần IV (KPIs benchmark Good/Excellent)
- `brandformance-nurture-sequence.md` (nếu có sequence theo hành vi)

## 3. Execution Steps

### Bước 1: Thu thập data theo từng email trong sequence
Không đánh giá trung bình cả sequence — phải nhìn từng email riêng để biết chính xác điểm rớt.

### Bước 2: So sánh với benchmark
| Metric | Good | Excellent |
|---|---|---|
| Open rate | > 20% | > 35% |
| CTR | > 2% | > 5% |
| Unsubscribe | < 0.5% | < 0.2% |

### Bước 3: Xác định điểm rớt cụ thể
- **Open rate thấp** ở 1 email cụ thể → vấn đề Subject line hoặc thời điểm gửi, không phải nội dung
- **CTR thấp** dù open rate tốt → vấn đề Body content hoặc CTA không đủ hấp dẫn/rõ ràng
- **Unsubscribe cao** tại 1 điểm trong sequence → email đó quá promotional hoặc tần suất dày quá

### Bước 4: Phân tích theo segment (nếu có nhiều nguồn)
So sánh open rate/CTR giữa các nguồn lead khác nhau (ví dụ: lead từ Lead Magnet A vs Lead Magnet B) — nguồn nào engage tốt hơn phản ánh chất lượng lead từ nguồn đó.

### Bước 5: Đề xuất A/B test tiếp theo
Ưu tiên test 1 biến tại điểm rớt lớn nhất: subject line mới, thời điểm gửi khác, hoặc CTA khác.

### Bước 6: Build report document

## 4. Examples

### Example 1 — Generic: Welcome Sequence dịch vụ tư vấn tài chính
```
EMAIL 1 (Welcome): Open 45% ✓ Excellent, CTR 8% ✓
EMAIL 2 (Founder story): Open 28% ✓ Good, CTR 3% ✓
EMAIL 4 (Soft offer): Open 18% ⚠️ Dưới benchmark, CTR 1.2% ⚠️
EMAIL 6 (CTA + deadline): Open 12% ✗ Thấp, Unsubscribe 0.8% ✗ Cao hơn ngưỡng

ĐIỂM RỚT: Từ Email 2 sang Email 4, open rate giảm 10 điểm — có thể do khoảng cách 3 ngày quá dài
khiến người đọc quên. Email 6 có unsubscribe cao vì đây là email offer sau 2 tuần — hơi dồn dập.

ĐỀ XUẤT: Rút ngắn khoảng cách Email 2→4 xuống 2 ngày. Test lại subject line Email 6
theo hướng ít "sales" hơn, thêm giá trị trước khi CTA.
```

### Example 2 — Giáo dục: BOFU Sequence khóa học online
```
D-7 (Mở cửa): Open 22%, CTR 2.1% — trong benchmark
D-5 (Social proof): Open 19%, CTR 4.5% ✓ CTR cao nhất trong sequence
D-3 (FAQ): Open 15%, CTR 1.8%
D-1 (Urgency): Open 25% ✓ tăng lại, CTR 6.2% ✓ Excellent — hiệu ứng urgency rõ
D-0 (Final push): Open 30% ✓ cao nhất, CTR 7%

NHẬN ĐỊNH: Email D-5 (social proof) có CTR tốt nhất dù open rate không cao nhất — nội dung
case study đang thực sự thuyết phục người đã mở. Email D-3 (FAQ) yếu nhất toàn sequence.

ĐỀ XUẤT: Rút gọn FAQ, chuyển 1-2 câu FAQ mạnh nhất sang ngay sau Social proof
thay vì để riêng 1 email cả sequence.
```

## 5. Edge Cases & Error Handling

**Open rate thấp toàn bộ do vào Spam (deliverability), không phải nội dung**: Kiểm tra domain reputation, SPF/DKIM setup trước khi kết luận vấn đề content. Đây là vấn đề kỹ thuật khác hoàn toàn.

**List quá nhỏ (< 200) để có ý nghĩa thống kê**: Ưu tiên build list trước, báo cáo chỉ mang tính tham khảo định hướng, chưa nên A/B test chính thức.

**So sánh Zalo OA và Email bằng cùng benchmark**: Sai — Zalo OA có tỉ lệ đọc (không phải "open") thường cao hơn Email nhiều do thói quen người Việt kiểm tra Zalo thường xuyên hơn; cần benchmark riêng.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `DATA_COLLECT` | Thu thập data từng email |
| `BENCHMARK_COMPARE` | So sánh với chuẩn Good/Excellent |
| `DROPOFF_FIND` | Xác định điểm rớt cụ thể |
| `SEGMENT_ANALYSIS` | Phân tích theo nguồn (nếu có) |
| `TEST_PROPOSE` | Đề xuất A/B test tiếp theo |
| `DONE` | Email Report hoàn chỉnh |

## References
- `brandformance-email-plan.md` → Benchmark gốc
- `brandformance-nurture-sequence.md` → Sequence theo hành vi
- `brandformance-next-cycle.md` → Dùng report này làm evidence
