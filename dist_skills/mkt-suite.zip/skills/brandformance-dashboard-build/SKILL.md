---
name: brandformance-dashboard-build
description: "Kích hoạt khi cần xây dashboard thực tế (Google Sheet/bảng theo dõi) từ KPI Framework đã có — khác với kpi-setup (định nghĩa nên đo gì), skill này xây công cụ thật để nhìn số liệu hàng ngày/tuần/tháng. Trigger: 'xây dashboard', 'dashboard marketing', 'làm bảng theo dõi KPI', 'setup Google Sheet dashboard', 'dashboard nhìn hàng ngày', 'không có công cụ theo dõi số liệu'. Kích hoạt sau khi đã có KPI Framework nhưng chưa có nơi tổng hợp nhìn thực tế."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Dashboard Build

## 1. Triggers

### Explicit triggers
- "xây dashboard marketing", "làm bảng theo dõi KPI"
- "setup Google Sheet dashboard", "dashboard nhìn hàng ngày"

### Implicit triggers
- Đã có KPI Framework (`brandformance-kpi-setup.md`) nhưng vẫn tính tay mỗi lần cần báo cáo
- Số liệu nằm rải rác nhiều nơi (Meta Ads Manager, Sheet thủ công, Notion) không ai tổng hợp
- Report tuần/tháng tốn quá nhiều thời gian vì phải gom số liệu lại từ đầu mỗi lần

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** KPI Framework đã có (từ `brandformance-kpi-setup.md`) — biết rõ NSM, OMTM, và các chỉ số theo AARRR
- [ ] **[BẮT BUỘC]** Nguồn data hiện có (Meta MCP, Sheet thủ công, Notion database)
- [ ] **[NẾU CÓ]** Công cụ đang dùng (Google Sheets/Looker Studio) và tần suất cần xem

Đọc trước khi thực hiện:
- `brandformance-kpi-setup.md` → Khung KPI đã định nghĩa, dùng làm input trực tiếp
- `brandformance-measurement.md` → Phần VI (Dashboard: đọc gì mỗi tuần/tháng)

## 3. Execution Steps

### Bước 1: Xác định 3 tầng dashboard theo tần suất
Không dồn tất cả chỉ số vào 1 view duy nhất — mỗi tầng phục vụ mục đích khác nhau:
- **Daily snapshot**: Spend pace, CPL tức thời — chỉ để phát hiện bất thường cần xử lý ngay
- **Weekly review**: CPL, tỉ lệ lead qualified, tỉ lệ chốt, ROAS, MER — dùng để ra quyết định điều chỉnh trong tuần
- **Monthly scorecard**: Brand KPI + toàn bộ Performance KPI + NSM — dùng để đánh giá tổng thể và báo cáo

### Bước 2: Thiết kế cấu trúc Sheet 3 lớp
```
TAB 1 — Raw Data: Dữ liệu thô (import từ Meta MCP hoặc dán thủ công theo cấu trúc cố định)
TAB 2 — Calculation: Công thức tính CPL, ROAS, MER, tỉ lệ chốt từ Raw Data
TAB 3 — Dashboard View: Chỉ hiển thị số đã tính, dễ nhìn, không lộ công thức phức tạp
```
Tách riêng 3 lớp giúp không ai vô tình sửa nhầm công thức khi chỉ cần xem số.

### Bước 3: Công thức tự động cho chỉ số then chốt
- CPL = Tổng chi phí / Số lead
- ROAS = Doanh thu từ ads / Chi phí ads
- MER = Tổng doanh thu / Tổng chi marketing (bao gồm cả kênh không phải ads)
- Tỉ lệ chốt = Số đơn / Số lead qualified

Viết công thức dùng tham chiếu ô (không hard-code số) để tự cập nhật khi Raw Data thay đổi.

### Bước 4: Thiết kế cảnh báo trực quan
Dùng conditional formatting theo ngưỡng đã đặt ở `brandformance-kpi-setup.md`: xanh (đạt target) / vàng (gần ngưỡng cảnh báo) / đỏ (vượt ngưỡng cần hành động ngay) — giúp người không chuyên số liệu vẫn nhìn phát biết vấn đề ở đâu.

### Bước 5: Quy trình cập nhật data
Xác định rõ: Ai cập nhật? Tần suất nào (hàng ngày cho Ads, hàng tuần cho Content)? Nguồn nào tự động (Meta MCP) và nguồn nào cần nhập tay (doanh thu thực tế, data offline)?

### Bước 6: Build Dashboard hoàn chỉnh + hướng dẫn sử dụng
Kèm theo hướng dẫn ngắn cho người không chuyên: xem tab nào, hiểu màu sắc thế nào, khi nào cần báo động cho ai.

## 4. Examples

### Example 1 — Generic: Spa làm đẹp (dashboard tuần)
```
TAB RAW DATA: Cột Ngày | Spend | Lead | Doanh thu | Số đơn (dán từ Meta MCP + nhập tay doanh thu)

TAB CALCULATION: CPL = Spend/Lead | ROAS = Doanh thu/Spend | Tỉ lệ chốt = Số đơn/Lead

TAB DASHBOARD VIEW (weekly):
CPL tuần này: 180K ✓ (target 200K)
Tỉ lệ chốt: 18% ⚠️ (target 25%, gần ngưỡng cảnh báo)
ROAS: 3.5x ✓

CẢNH BÁO TỰ ĐỘNG: Ô tỉ lệ chốt chuyển vàng khi < 20%, chuyển đỏ khi < 15%
→ Founder nhìn dashboard mỗi thứ 2 đầu tuần, biết ngay cần focus vào đâu.
```

### Example 2 — Giáo dục: Trung tâm ngoại ngữ (dashboard tháng)
```
MONTHLY SCORECARD TAB:
Brand: Reach tự nhiên 22K (✓ +45% so tháng trước) | Follower +800 (✓)
Performance: CPL 180K (✓) | ROAS 3.5x (✓) | Doanh thu 184tr/200tr (⚠️ 92% target)
NSM: Tỉ lệ học viên hoàn thành khóa 78% (✓ target 70%)

QUY TRÌNH CẬP NHẬT: Ads Manager cập nhật Raw Data Ads hàng ngày (5 phút/ngày) qua Meta MCP,
Kế toán cập nhật doanh thu thực tế mỗi thứ 6, Founder xem Monthly Scorecard đầu tháng sau.
```

## 5. Edge Cases & Error Handling

**Data từ nhiều nguồn không đồng bộ định dạng**: Chuẩn hóa format ngày tháng và đơn vị tiền tệ ngay từ Raw Data tab trước khi tính toán — sai định dạng là nguyên nhân phổ biến nhất khiến công thức lỗi.

**Dashboard quá phức tạp không ai dùng thường xuyên**: Ưu tiên tối giản Dashboard View — chỉ hiển thị 5-8 chỉ số quan trọng nhất theo OMTM hiện tại, không cố nhét hết mọi thứ có thể đo được.

**Công thức lỗi khi có ô trống/dữ liệu thiếu**: Dùng công thức có xử lý lỗi (IFERROR) để tránh dashboard hiển thị lỗi #DIV/0! gây hoang mang không cần thiết.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `TIER_DEFINE` | Xác định 3 tầng dashboard |
| `STRUCTURE_BUILD` | Thiết kế cấu trúc Sheet 3 lớp |
| `FORMULA_WRITE` | Viết công thức tự động |
| `ALERT_DESIGN` | Thiết kế cảnh báo trực quan |
| `UPDATE_PROCESS` | Quy trình cập nhật data |
| `DONE` | Dashboard hoàn chỉnh + hướng dẫn |

## References
- `brandformance-kpi-setup.md` → Nguồn khung KPI
- `brandformance-measurement.md` → Phần VI
- `brandformance-report.md` → Dùng Dashboard làm nguồn cho báo cáo
