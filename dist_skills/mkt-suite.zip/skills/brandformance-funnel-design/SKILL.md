---
name: brandformance-funnel-design
description: "Kích hoạt khi cần thiết kế phễu Brandformance 4 giai đoạn — chọn kênh theo chức năng Reach/Nurture/Convert, xác định điểm chạm brand và KPI từng tầng, tỉ lệ Brand/Performance phù hợp. Trigger: 'thiết kế phễu', 'xây phễu marketing', 'funnel design', 'hành trình khách hàng', 'kênh nào cho tầng nào', 'blueprint marketing', 'xây hệ thống marketing từ đầu', 'phễu chuyển đổi'. Kích hoạt cả khi brand chưa có hệ thống marketing rõ ràng hoặc đang muốn review lại cấu trúc."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Funnel Design

## 1. Triggers

### Explicit triggers
- "thiết kế phễu marketing", "xây phễu", "funnel design"
- "kênh nào cho tầng nào?", "hành trình khách hàng"
- "blueprint marketing", "xây hệ thống marketing từ đầu"
- "tôi nên dùng kênh gì?"

### Implicit triggers
- Brand đang có nhiều kênh nhưng không rõ mỗi kênh làm gì trong tổng thể
- CPL cao vì đang bỏ bước nurture, nhảy thẳng từ awareness sang bán hàng
- KH nhiều lần tương tác nhưng không chốt → phễu bị gãy ở đâu đó
- Vừa xây xong Positioning → cần thiết kế phễu để triển khai
- Budget mới được phân bổ → cần biết chia cho kênh nào

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Positioning và target audience đã có
- [ ] **[BẮT BUỘC]** Sản phẩm/dịch vụ và mức giá (ảnh hưởng đến độ dài phễu)
- [ ] **[BẮT BUỘC]** Ngân sách marketing tổng hàng tháng
- [ ] **[NẾU CÓ]** Nhân lực hiện có
- [ ] **[NẾU CÓ]** Kênh đang chạy và kết quả hiện tại

Đọc trước khi thực hiện:
- `brandformance-framework.md` → Phần III (Phễu 4 giai đoạn + tỉ lệ Brand/Performance)
- `brandformance-content.md` → Phần VII (Content Funnel đa kênh)
- `brandformance-customer.md` → Phần IV (3 nhóm KH)

## 3. Execution Steps

### Bước 1: Xác định đặc điểm sản phẩm ảnh hưởng đến thiết kế phễu
1.1 Độ phức tạp của quyết định mua:
- Giá thấp (< 500K) + Impulse buy → Phễu ngắn, TOFU → BOFU trực tiếp
- Giá trung (500K-5 triệu) → Phễu vừa, cần MOFU rõ ràng
- Giá cao (> 5 triệu) / B2B → Phễu dài, cần nhiều nurture touchpoints

1.2 Độ tin tưởng cần thiết:
- Sức khỏe / tài chính / giáo dục → Trust cao, cần nhiều proof trước khi mua

1.3 Cycle ra quyết định:
- < 1 ngày: single-touch / 1-7 ngày: retargeting + email / > 7 ngày: nurture sequence

### Bước 2: Thiết kế 4 giai đoạn với tỉ lệ Brand/Performance

**Giai đoạn 1 — Awareness + Acquisition (Brand 70% / Perf 30%)**
Mục tiêu: KH biết đến brand và bước đầu vào phễu
- Kênh Reach: Facebook/TikTok · YouTube · SEO Blog · PR
- Kênh Acquisition: Lead Magnet landing page · Webinar · Free tool
- Điểm chạm brand: Content giáo dục, câu chuyện, insight — KHÔNG bán hàng
- KPI: CPM · Reach · Video View Rate · Follower growth · Lead Magnet signups

**Giai đoạn 2 — Activation + Nurture (Brand 50% / Perf 50%)**
Mục tiêu: KH trải nghiệm giá trị, xây trust, sàng lọc lead chất lượng
- Kênh Nurture: Email sequence · Zalo OA · Community/Group · Retarget MOFU
- Điểm chạm brand: Case study, social proof, FAQ, comparison content
- KPI: Email open rate · CTR · Engagement depth · Lead scoring

**Giai đoạn 3 — Conversion (Brand 30% / Perf 70%)**
Mục tiêu: Chuyển lead nóng thành KH trả tiền
- Kênh Convert: Retarget BOFU · Email BOFU · Sales call · Landing page
- Điểm chạm brand: Guarantee/risk reversal · Testimonial cụ thể
- KPI: CPL → CPO · Tỉ lệ inbox → chốt · CPA · ROAS

**Giai đoạn 4 — Retention + Referral (Brand 60% / Perf 40%)**
Mục tiêu: Giữ KH cũ và kích hoạt referral
- Kênh Retain: Email retention · Community · Loyalty program
- Kênh Referral: Affiliate / Referral program · UGC campaign
- KPI: Tỉ lệ mua lần 2 · NPS · % lead từ giới thiệu

### Bước 3: Chọn kênh theo ngân sách và nhân lực
Nguyên tắc: Ít kênh làm tốt > Nhiều kênh làm tệ

Với ngân sách < 20 triệu/tháng → Chọn tối đa 3 kênh:
- 1 kênh Reach organic (TikTok hoặc Facebook organic)
- 1 kênh Convert paid (BOFU ads)
- 1 kênh Nurture (Email hoặc Zalo OA)

Với ngân sách 20-50 triệu/tháng → Có thể thêm:
- 1 kênh Reach paid (TOFU ads)
- 1 kênh Retarget MOFU

### Bước 4: Xác định điểm chuyển tiếp và tracking
4.1 Awareness → Activation: Lead Magnet opt-in, Follow fanpage, Subscribe email
4.2 Activation → Conversion: Lead Scoring đạt ngưỡng Hot, Xem pricing page, Inbox hỏi về giá
4.3 Conversion → Retention: Purchase → Onboarding email sequence
4.4 Tracking: UTM cho mỗi kênh · Pixel Meta · Email tag theo hành vi

### Bước 5: Compile Funnel Design document
5.1 Vẽ sơ đồ phễu:
```
[Awareness] → [Lead Magnet] → [Email Nurture] → [BOFU Retarget] → [Purchase] → [Retention]
```
5.2 Bảng KPI framework từng giai đoạn.
5.3 Thứ tự triển khai: "Bắt đầu với [X] vì dễ implement nhất, cho kết quả nhanh nhất."

## 4. Edge Cases & Error Handling

**Case 1: Ngân sách < 5 triệu/tháng**
→ Chỉ thiết kế 2 giai đoạn: GĐ1 (Organic) + GĐ3 (BOFU basic).
→ Focus organic content + database hiện có.

**Case 2: Brand muốn có mặt ở tất cả kênh**
→ Flag: "Mỗi kênh cần thời gian + nhân lực. Better to be amazing on 2 channels than mediocre on 10."

**Case 3: Phễu đang hoạt động nhưng muốn optimize**
→ Không thiết kế lại từ đầu — audit trước: "Giai đoạn nào đang drop-off nhiều nhất?"
→ Chỉ fix giai đoạn yếu nhất.

**Case 4: Sản phẩm giá thấp, impulse buy**
→ Phễu 2 bước đủ: Content TOFU → BOFU ads. Thêm complexity khi conversion đã ổn định.

## References

- `brandformance-framework.md` → Phần III (Phễu 4 giai đoạn + tỉ lệ Brand/Performance)
- `brandformance-content.md` → Phần VII (Vai trò từng kênh)

Nguyên tắc chọn kênh:
- Kênh Reach: Nơi KH đang SCROLL và khám phá (TikTok, Instagram, YouTube)
- Kênh Nurture: Nơi KH đã OPT-IN (Email, Zalo OA, Group)
- Kênh Convert: Nơi KH đang CÓ INTENT (Retarget, Search, Direct message)

Sai lầm phổ biến:
- Bỏ qua GĐ2 → nhảy thẳng từ awareness sang bán = CPO cao
- Dùng cùng 1 tone cho tất cả giai đoạn → không phù hợp nhiệt độ lead
- Không track điểm chuyển tiếp → không biết phễu gãy ở đâu
