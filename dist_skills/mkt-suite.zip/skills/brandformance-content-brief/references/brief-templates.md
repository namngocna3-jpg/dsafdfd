# Bộ mẫu Content Brief (Strategy → Plan → Execution)

Ví dụ xuyên suốt: ra mắt **AuraClean Smart Purifier** (máy lọc không khí, tệp mẹ bỉm lo bụi mịn PM2.5).

---

## CẤP 1 — BRIEF CHIẾN LƯỢC (Strategy Brief)
"Hiến pháp" của chiến dịch. Dùng để trình lãnh đạo, hoặc để AI đóng vai Giám đốc Chiến lược.

| Hạng mục | Nội dung |
|---|---|
| 1. Bối cảnh & Mục tiêu | Bối cảnh thị trường + Mục tiêu Kinh doanh (vd: bán 2.000 máy/3 tháng) + Mục tiêu Marketing (vd: 3 triệu reach, xây nhận thức) |
| 2. Đối tượng mục tiêu | Chân dung (Chị Lan, 32t, mẹ bé 3t, chung cư) + **Insight** ("Tôi bất an vì con hít không khí không an toàn ngay trong nhà") |
| 3. Big Idea & Key Messages | Big Idea ("Kiến tạo lá chắn, an tâm hít thở") + 3 key message |
| 4. Trụ cột nội dung | 4 pillar: Giáo dục → Giải pháp → Sản phẩm → Feedback |
| 5. Kênh & Phân bổ | Chủ lực (FB, Blog SEO) + Hỗ trợ (KOC, PR) + phân bổ theo giai đoạn Awareness/Consideration/Conversion |
| 6. KPIs | Reach, Engagement, Traffic, Leads, Conversion Rate |

**Câu lệnh AI:** "Dựa trên Brief Chiến lược này, đóng vai Giám đốc Marketing, đề xuất lộ trình triển khai chi tiết 3 tháng, chia rõ hoạt động 3 giai đoạn: Nhận biết – Cân nhắc – Chuyển đổi."

---

## CẤP 1.5 — BRIEF Ý TƯỞNG (Brainstorming Brief)
| Hạng mục | Nội dung |
|---|---|
| 1. Mục tiêu Brainstorm | vd: tạo 10 ý tưởng dễ viral giáo dục thị trường về ô nhiễm không khí trong nhà |
| 2. Đối tượng | Mẹ trẻ, hút bởi nội dung trực quan, gây ấn tượng mạnh, dễ share |
| 3. Insight cần xoáy sâu | Nỗi mơ hồ về thứ "không nhìn thấy" đang hại con |
| 4. "Hàng rào" sáng tạo | NÊN: hình ảnh so sánh, thí nghiệm trực quan, câu chuyện cảnh báo. KHÔNG NÊN: thuật ngữ khoa học khô khan |
| 5. Định dạng ưu tiên | Video ngắn (TikTok/Reels), Infographic, post "Bạn có biết?" |

---

## CẤP 2 — BRIEF KẾ HOẠCH NỘI DUNG (Plan Brief)
| Hạng mục | Nội dung |
|---|---|
| 1. Mục tiêu Kế hoạch | vd: tháng đầu tập trung giáo dục + nhận thức (TOFU), giới thiệu nhẹ giải pháp |
| 2. Tần suất & Thời gian | vd: 5 bài/tuần (T2–T6), 20h00 |
| 3. Cấu trúc theo ngày | T2 Cảnh báo (pillar 1) · T3 Tương tác/minigame · T4 Giải pháp (pillar 2) · T5 Giới thiệu nhẹ (pillar 3) · T6 Feedback (pillar 4) |
| 4. DS ý tưởng đã duyệt | [liệt kê ~20 ý tưởng đã brainstorm] |

**Câu lệnh AI:** "Đóng vai Social Media Manager. Dựa trên Brief Kế hoạch + 20 chủ đề cho sẵn, tạo Content Calendar chi tiết 4 tuần, tuân thủ cấu trúc đăng bài theo ngày."

---

## CẤP 3 — BRIEF SẢN XUẤT (Execution Brief)
Chọn đúng mẫu theo loại sản phẩm nội dung.

### 3.1 — Bài viết SEO
- **Chủ đề / Từ khoá chính / phụ**
- **Search Intent** + vị trí phễu (vd MOFU, người hoài nghi cần lý do thuyết phục)
- **Dàn ý (H2):** liệt kê các H2 giải quyết hoài nghi → dẫn tới sản phẩm tự nhiên
- **CTA**
- *Câu lệnh AI:* "Đóng vai SEO Content Writer, viết blog chuẩn SEO 1.500 từ trả lời [câu hỏi], tối ưu từ khoá chính/phụ, bám dàn ý, giọng chuyên gia nhưng đồng cảm."

### 3.2 — Bài PR báo chí
- WHY: xây uy tín từ bên thứ ba (báo) · WHO: độc giả báo lớn, tin số liệu & trích dẫn chuyên gia
- WHAT: thông điệp cốt lõi · WHERE: chuyên mục Sức khoẻ/Đời sống/Công nghệ
- **HOW — cấu trúc Kim tự tháp ngược:** (i) mở đầu nêu thực trạng + số liệu WHO/Bộ Y tế → (ii) thân bài phân tích tác nhân + trích chuyên gia → (iii) giới thiệu giải pháp khéo léo (2–3 công nghệ nổi bật) → (iv) kết + thông tin liên hệ
- Giọng: khách quan, chuẩn báo chí, KHÔNG quảng cáo lộ liễu
- *Câu lệnh AI:* "Đóng vai nhà báo mảng sức khoẻ, viết bài PR 800 từ, tiêu đề [giật tít], bám cấu trúc kim tự tháp ngược, lồng sản phẩm tự nhiên như giải pháp được chuyên gia gợi ý."

### 3.3 — Video Branding (60s)
- Mục tiêu: Brand Love, thể hiện triết lý/sứ mệnh (TOFU)
- Thông điệp = "tuyên ngôn" thương hiệu
- Cấu trúc: hình quay chậm nghệ thuật khoảnh khắc đời thường + hình vi mô bụi/vi khuẩn + voice-over trầm ấm đọc tuyên ngôn + sản phẩm chỉ thoáng qua ở cuối
- *Câu lệnh AI:* "Viết voice-over 60s giọng sâu lắng, triết lý, thể hiện sứ mệnh [X], thông điệp cốt lõi [Y]."

### 3.4 — Video Storytelling (2 phút)
- Mục tiêu: kết nối cảm xúc sâu (TOFU/MOFU)
- Cấu trúc 4 phần: Mở (nỗi đau) → Phát triển (tìm giải pháp) → Cao trào (kết quả/khoảnh khắc xúc động) → Kết (sản phẩm + thông điệp)
- *Câu lệnh AI:* "Viết kịch bản chi tiết (mô tả cảnh + lời thoại) video storytelling 2 phút theo cấu trúc 4 phần, chạm cảm xúc."

### 3.5 — Video Bán hàng (60–90s, công thức PAS)
- Mục tiêu: thuyết phục mua (BOFU), tệp "nóng"
- **P (15s):** cảnh vấn đề (ho, dị ứng, bụi) + "Gia đình bạn có đang gặp?"
- **A (20s):** khoét sâu bằng số liệu PM2.5 đáng báo động
- **S (40s):** demo nhanh sản phẩm + text overlay lợi ích
- **CTA (15s):** ưu đãi + kêu gọi hành động mạnh
- Phong cách: nhanh, năng động, nhạc sôi nổi
- *Câu lệnh AI:* "Viết kịch bản video quảng cáo bán hàng 90s theo công thức P-A-S, kết bằng CTA mạnh kèm ưu đãi."

### 3.6 — Landing Page (video testimonial + trang)
- Mục tiêu: tăng conversion, xây Trust & Empathy, phá rào "sản phẩm có hiệu quả thật không?" (BOFU)
- Concept video: câu chuyện khách hàng thật (nhân vật + bối cảnh thật)
- Cấu trúc Storytelling Arc: Mở (nỗi đau) → Phát triển (tìm giải pháp) → Cao trào (kết quả diệu kỳ) → Kết (lời khuyên chân thành)
- Tone: ấm áp, trong trẻo; **lời thoại tự nhiên như lời kể — TUYỆT ĐỐI không dùng ngôn ngữ quảng cáo**

### 3.7 — Social Post (Branding vs Bán hàng)
| | Branding (TOFU/MOFU) | Bán hàng (BOFU, công thức AIDA) |
|---|---|---|
| Mục tiêu | Xây cộng đồng, tương tác, gợi nhắc giá trị | Thúc đẩy chốt đơn ngay |
| Thông điệp | Cảm xúc ("Khoảnh khắc bình yên khi thấy con say giấc") | Ưu đãi có hạn ("Duy nhất hôm nay: giảm 20% + quà 500k") |
| Cấu trúc | Đoạn văn ngắn giàu cảm xúc + CTA tương tác | A: tiêu đề hút · I: 3 lợi ích · D: quà/số lượng giới hạn · A: "Inbox ngay!" |

---

## TƯ DUY PROMPT CHO AI (áp dụng cho mọi "Câu lệnh AI")
1. **Giao vai** — "Đóng vai chuyên gia marketing 10 năm ngành FMCG…"
2. **Bối cảnh** — mô tả sản phẩm, thương hiệu, mục tiêu chiến dịch, đối tượng
3. **Nhiệm vụ** — nêu rõ việc cần làm ("phân tích 5 đối thủ", "viết caption AIDA"…)
4. **Định dạng** — bảng / gạch đầu dòng / bài văn / kịch bản
5. **Ràng buộc** — độ dài, giọng văn, điều cấm (vd "≤500 từ, hài hước không dung tục, tránh thuật ngữ khó")
