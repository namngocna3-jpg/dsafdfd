---
name: brandformance-content-brief
description: "Kích hoạt khi cần xây Content Brief (bản định hướng nội dung) để giao cho người viết hoặc ra lệnh cho AI sản xuất content đúng ý, đúng mục tiêu. Trigger: 'content brief', 'xây content brief', 'brief nội dung', 'brief cho AI viết', 'dàn ý content chiến lược', 'tờ giao việc content', 'brief chiến lược nội dung', 'brief sản xuất', 'brief bài SEO', 'brief video', 'brief PR', 'brief landing page'. Dùng cả khi cần chuẩn hoá quy trình brief cho team hoặc khi content ra không đúng ý do brief mơ hồ."
metadata:
  version: 1.0.0
  source: "Khoá Chiến Binh Fullstack Marketing — Huỳnh Xuân Tùng (distilled)"
---

# Content Brief — Bản định hướng nội dung cho người & AI

Content Brief là tấm bản đồ tổng hợp mọi thông tin, mục tiêu, định hướng để người viết (hoặc AI) sản xuất ra nội dung đúng ý, đúng mục tiêu, nhất quán. **Với AI, brief chính là prompt tối thượng — brief càng rõ, AI càng thông minh.** Thiếu brief = xây nhà không bản vẽ.

## 1. Triggers
- "content brief", "xây/viết brief", "brief cho AI viết content", "dàn ý content"
- Content ra không đúng ý, phải sửa nhiều → thường do brief mơ hồ

## 2. Xương sống mọi brief: 5W1H
Bất kỳ brief nào cũng phải trả lời:
- **WHY (Mục tiêu):** Nội dung tạo ra để làm gì? (tăng nhận diện / thu lead / bán hàng) + vị trí phễu (TOFU/MOFU/BOFU).
- **WHO (Đối tượng):** Nói chuyện với ai? Chân dung + **insight** (nỗi đau, mong muốn thật).
- **WHAT (Thông điệp):** Muốn nói điều gì? Big Idea + Key Messages.
- **WHERE (Kênh):** Xuất hiện ở đâu? (Facebook, Blog SEO, TikTok, Email, PR báo...).
- **HOW (Hình thức & phong cách):** Format (bài/video/infographic), Tone of Voice, và **CTA** (muốn khán giả làm gì tiếp).

## 3. Ba cấp độ brief (vĩ mô → vi mô)
| Cấp | Tên | Vai trò |
|---|---|---|
| 1 | **Brief Chiến lược** (Strategy) | "Hiến pháp" cho cả chiến dịch — direction cho mọi brief bên dưới |
| 2 | **Brief Kế hoạch** (Plan) | Sắp ý tưởng đã duyệt thành lịch đăng bài / một tuyến nội dung |
| 3 | **Brief Sản xuất** (Execution) | "Tờ giao việc" cho từng sản phẩm nội dung cụ thể |

→ **Luôn làm từ Chiến lược xuống.** Brief Chiến lược là quan trọng nhất; sai ở đây thì mọi brief con lệch theo.

## 4. Ba bước thực thi

### Bước 1: Xác định cấp brief cần làm
Hỏi: đang cần định hướng cả chiến dịch (Chiến lược), lên lịch một tuyến/tháng (Kế hoạch), hay giao việc 1 sản phẩm (Sản xuất)? Chọn đúng mẫu ở `references/brief-templates.md`.

### Bước 2: Điền brief theo mẫu
Mở `references/brief-templates.md`, lấy đúng mẫu (Chiến lược / Brainstorm / Kế hoạch / hoặc 1 trong các Brief Sản xuất: bài SEO, PR báo chí, video branding, video storytelling, video bán hàng PAS, landing page, social post branding/bán hàng). Điền đủ 5W1H, không bỏ trống ô insight và CTA.

### Bước 3: Chuyển brief thành prompt cho AI (nếu dùng AI)
Mỗi mẫu trong references đã kèm sẵn **"Câu lệnh cho AI"**. Áp dụng tư duy prompt: **Giao vai** (đóng vai chuyên gia cụ thể) → **Bối cảnh** (sản phẩm/brand/đối tượng) → **Nhiệm vụ** rõ ràng → **Định dạng** đầu ra → **Ràng buộc** (độ dài, giọng văn, điều cấm).

## 5. Mô hình AI–Human Hybrid (nguyên tắc dùng AI)
Luôn hỏi: *"Phần nào cần tư duy chiến lược & thấu cảm (của tôi), phần nào cần xử lý dữ liệu & tốc độ (của AI)?"*
- **Con người:** tư duy phản biện, thấu cảm insight, quyết định thông điệp/kênh, kiểm duyệt & thêm cảm xúc thương hiệu.
- **AI:** nghiên cứu/tổng hợp, phác thảo nhiều bản, sản xuất hàng loạt, tối ưu SEO/tiêu đề/ngữ pháp.

## 6. Liên kết skill khác
Sau khi có brief: dùng brandformance-content-strategy (tuyến nội dung), brandformance-content-calendar (lịch đăng), brandformance-content-script (kịch bản video), brandformance-caption-writing (caption), brandformance-landing-page (landing). Brief Chiến lược nối với brandformance-campaign-plan.
