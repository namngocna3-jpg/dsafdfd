---
name: brandformance-content-strategy
description: >
  Lập chiến lược content đa kênh — pillars, angles, hook list, content mix, lịch tháng đầu. Kích hoạt khi: "content strategy", "chiến lược content", "xây hệ thống content", "content plan đa kênh", "content pillar strategy", "xây kênh content từ đầu", "lên plan content toàn diện".
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: content</summary>

# brandformance-content

> Kiến thức về hệ thống nội dung Brandformance — đọc trước khi chạy bất kỳ skill content hoặc community.

## I. 4 Content Pillar theo mục đích phễu

Pillar 1: Nhận diện & Thu hút (TOFU) — không đề cập sản phẩm trực tiếp
Pillar 2: Giáo dục & Tin tưởng (MOFU) — đề cập sản phẩm gián tiếp
Pillar 3: Chuyển đổi (BOFU) — CTA rõ, offer cụ thể
Pillar 4: Giữ chân & Referral — nuôi dưỡng KH cũ

## II. Trục nội dung

Công thức: Trục nội dung = Mục tiêu truyền thông × Vấn đề KH × Thế mạnh thương hiệu

## III. Nguồn sản xuất content

FGC (Founder Generated Content) — lợi thế SME lớn nhất
BGC (Brand Generated Content) — kênh brand chính thức
EGC (Employee Generated Content) — nhân sự nội bộ
UGC (User Generated Content) — KH thật tạo content
KOC/KOL — người review trả phí

## IV. Ma trận content theo 3 tầng phễu

TOFU: Brand 80% / Perf 20% — CPM, View Rate
MOFU: Brand 50% / Perf 50% — CTR, CPL
BOFU: Brand 30% / Perf 70% — CPA, Conversion Rate

## V. Hook → Lead Magnet → Offer

Hook: thu hút attention (mọi giai đoạn)
Lead Magnet: đổi info lấy tài nguyên giá trị
Offer: gói SP/DV kèm giá trị, giảm rào cản ra quyết định
Chuỗi: Hook → LM → Thank-you page → Email/Zalo nurture → Core Offer → Retarget

## VI. Target bằng content

Target rộng + content nói đúng vấn đề cụ thể = content gạn lọc người phù hợp.
Bỏ target sâu theo hành vi/sở thích truyền thống (ngày càng sai lệch, đắt).

## VII. Content Funnel đa kênh

Facebook/Instagram: Reach + Conversion
TikTok: TOFU, viral, khám phá
Zalo OA: Nurture, retention — 2 loại tin khác nhau: **Broadcast** (quảng cáo, cần follower đồng ý, giới hạn 2-3 lần/tuần để tránh giảm follow rate) và **ZNS** (Zalo Notification Service — giao dịch/xác nhận đơn/lịch hẹn, không phải quảng cáo, độ tin cậy cao hơn). Nội dung phải ngắn, trực tiếp hơn Email vì thói quen kiểm tra Zalo nhiều lần/ngày.
Email: Nurture sequence, conversion — phù hợp nội dung sâu, case study dài mà Zalo không phù hợp.
Group/Forum: Seeding, social proof
Kênh Founder: Trust building, FGC

## VIII. Community — kênh Retention/Referral

Community không phải kênh acquisition, đừng đo bằng lead ngay. 3 loại theo tầng phễu:
- **TOFU (Open)**: giáo dục, growth-focused — đo bằng reach/growth, không kỳ vọng chuyển đổi cao
- **MOFU (Semi-closed)**: Q&A, poll — đo bằng tỉ lệ tham gia + chuyển đổi nhẹ sang lead
- **BOFU (Closed, chỉ KH đã mua)**: đo bằng tỉ lệ tham gia hoạt động + referral phát sinh + repeat purchase

Quy tắc nội dung trong community: 80% giá trị thật / 20% soft mention sản phẩm — vi phạm tỉ lệ này, community sẽ giống spam và mất tương tác thật.

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Content Strategy

## 1. Triggers

### Explicit triggers
- "chiến lược content", "content strategy"
- "xây hệ thống content", "content pillar"

### Implicit triggers
- Content đang random, không nhất quán
- KPI content thấp không biết tại sao
- Vừa xây Brand Bible + Customer Insight → cần operationalize thành content

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Brand Bible (Voice, Tone, Positioning)
- [ ] **[BẮT BUỘC]** Customer Insight (3 nhóm Cold/Warm/Hot)
- [ ] **[BẮT BUỘC]** Kênh sẽ publish

Đọc trước: `brandformance-content.md` → Toàn bộ
Đọc thêm khi map content theo hành trình: `references/customer-journey-7-stage.md` → 7 giai đoạn Chưa biết→Trung thành + loại content mỗi điểm chạm + mô hình bánh đà

## 3. Execution Steps

### Bước 1: Xác định Content Mission
"Chúng tôi tạo content [dạng gì] để giúp [audience nào] [đạt được điều gì]."
Nhất quán với Positioning. Content không phục vụ Mission → không tạo.

### Bước 2: Xây 3-5 Content Pillars
Mỗi Pillar = 1 chủ đề lớn mà brand có authority và KH quan tâm.
- Brand giỏi về gì? (Expertise Pillars)
- KH đang thắc mắc gì? (Audience Need Pillars)
- Đối thủ đang nói gì mà mình nói tốt hơn? (Differentiation Pillars)

Với mỗi Pillar: Tên + Sub-topics (5-10) + Tỉ lệ % content mix.

### Bước 3: Ma trận content theo tầng phễu × kênh

| Tầng | Nhóm KH | Mục tiêu | Format |
|---|---|---|---|
| TOFU | Lạnh | Nhận ra vấn đề | Video ngắn, Insight post |
| MOFU | Ấm | Trust, comparison | Case study, Testimonial |
| BOFU | Nóng | Urgency, offer | Offer post, Email, Live |

Tỉ lệ: **60-70% TOFU + 20-25% MOFU + 10-15% BOFU.**

### Bước 4: Content Mix theo tuần (5-7 posts/tuần)
- 3-4 TOFU: Giáo dục / Insight / Observation
- 1-2 MOFU: Social proof / FAQ
- 0-1 BOFU: Chỉ khi đang trong phase bán hàng

Evergreen 70% + Timely 30%.

### Bước 5: Compile Content Strategy document
Mission + Pillars + Ma trận × kênh + Content mix + KPI per kênh.
→ Bước tiếp theo: `brandformance-content-calendar`

## 4. Examples

### Example 1 — Generic: Thương hiệu thực phẩm healthy
```
CONTENT MISSION: "Tạo content ăn uống lành mạnh thực tế cho người bận rộn — không hi sinh vị ngon."

3 PILLARS:
P1 (35%): Dinh dưỡng thực tế — Sub-topics: Đọc nhãn, Thay thế lành mạnh, Myth
P2 (35%): Công thức nhanh < 20 phút — Sub-topics: Meal prep, Lunch box
P3 (30%): Câu chuyện KH — Sub-topics: Before/after, Review, Hành trình

CONTENT MIX TUẦN:
T2: TOFU — Video "3 sự thật về [thực phẩm] bạn chưa biết"
T4: MOFU — Case study KH
T6: TOFU — Infographic "5 thay thế cho bữa trưa văn phòng"
T7: TOFU — Công thức nhanh video 60s

KPI: TikTok view rate > 30%; Facebook reach/post > 2K
```

### Example 2 — Giáo dục: Leadership Academy
```
CONTENT MISSION: "Lãnh đạo thực chiến cho middle manager VN — không cần lý thuyết MBA."

4 PILLARS:
P1 (30%): Quản lý team thực tế (xử lý NV năng suất thấp, 1-on-1...)
P2 (25%): Communication skills (feedback, trình bày, email chuyên nghiệp)
P3 (25%): Quản lý bản thân (delegation, time management, burnout)
P4 (20%): Case study VN

MIX: TikTok 3 video/tuần (hook tình huống thật) + Facebook 4 posts/tuần
```

## 5. Edge Cases & Error Handling

**Case 1: Không biết bắt đầu Pillar nào**
→ "KH hay hỏi gì nhất trong 3 tháng qua?" → Đó là Pillar 1.

**Case 2: Content nhiều nhưng reach thấp**
→ Kiểm tra: > 40% post là offer/bán hàng → rebalance về TOFU.

**Case 3: Team 1 người**
→ Focus 2 Pillar, 1-2 kênh. Repurpose: 1 idea → TikTok + Facebook + Email.

**Case 4: Không biết KPI content**
→ TikTok: view rate, follower; FB: reach, save, comment; Email: open rate, CTR.
→ Không dùng Like làm KPI chính.

## 6. State Management

| State | Mô tả | Claude làm gì |
|---|---|---|
| `MISSION_SETTING` | Xây Content Mission | Chạy Bước 1 |
| `PILLAR_BUILDING` | Xây Pillars | Chạy Bước 2 |
| `MATRIX_MAPPING` | Ma trận × kênh | Chạy Bước 3 |
| `MIX_DESIGN` | Content mix tuần | Chạy Bước 4 |
| `COMPILING` | Compile document | Chạy Bước 5 |
| `DONE` | Hoàn chỉnh | Đề xuất: "brandformance-content-calendar" |

## References

- `brandformance-content.md` → Toàn bộ
- `brandformance-customer.md` → Phần III (Câu nói nội tâm = input cho hook)
- `references/customer-journey-7-stage.md` → Hành trình KH 7 giai đoạn + content theo điểm chạm (Fullstack Marketing buổi 4)

TOFU đúng nghĩa = KHÔNG mention sản phẩm, KHÔNG CTA mua hàng, KHÔNG discount.
