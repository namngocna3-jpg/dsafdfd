# Hành trình khách hàng 7 giai đoạn & content theo điểm chạm

Distil từ "Chiến Binh Fullstack Marketing" buổi 4 (TAS Global Growth). Dùng khi hoạch định chiến lược nội dung tích hợp — map content vào từng giai đoạn tâm lý của khách.

---

## Nguyên tắc nền: hành trình KH KHÔNG tuyến tính

Thực tế khách lướt Facebook → search Google → xem 3 web → 5 video YouTube → 10 clip TikTok → ra cửa hàng xem → về đặt online vì có mã giảm. Hành trình **lộn xộn, đa kênh, nhiều biến số** khác nhau ở mỗi người và mỗi thời điểm.

→ Không thiết kế content cho một đường thẳng. Thiết kế cho từng **trạng thái tâm lý**, để khách đang ở đâu cũng gặp đúng nội dung kéo họ tiến một bước.

## 7 giai đoạn (mô hình cảm xúc → hành động)

Chưa biết → **Biết** → **Thích** → **Tin** → **Mua** → **Yêu** → **Trung thành**

| # | Chuyển | Đặc điểm khách | Mục tiêu marketing | Loại content |
|---|---|---|---|---|
| 1 | Chưa biết → Biết | Chưa biết insight/giải pháp tồn tại | Đánh thức insight, "gãi đúng chỗ ngứa" bằng 3 loại cảm xúc (tích cực/tiêu cực/trung dung) | **Viral/Mass** — content giải trí đánh cảm xúc, lồng insight (vd clip vui lồng nỗi đau về da) |
| 2 | Biết → Thích | Biết nhiều giải pháp nhưng chưa có lý do thích bên mình | Giới thiệu rõ giải pháp bên mình, lồng POD/USP | Content **thông tin/kiến thức**: bệnh học, lợi ích, mẹo |
| 3 | Thích → Tin | Hứng thú nhưng chưa tin | Tạo niềm tin | **Review, feedback, KOL, chứng nhận, giải thưởng, case study** |
| 4 | Tin → Mua | Đã tin, chưa hành động | Kích ra quyết định nhanh | **Promotion, activation, minigame, ưu đãi giới hạn**, lồng insight kích mua |
| 5 | Mua → Yêu | Đã mua nhưng chưa yêu thích | Củng cố lựa chọn, tăng gắn bó | **Hậu mãi, chăm sóc KH**, content củng cố "bạn đã chọn đúng" |
| 6 | Yêu → Trung thành | Là fan nhưng vẫn có thể "phản bội" | Tôn vinh KH, biến thành người bảo vệ thương hiệu | Content **tôn vinh, community, người tiêu dùng thông thái** |

(Giai đoạn 7 "Trung thành" là kết quả của việc làm tốt giai đoạn 6 → khách chủ động giới thiệu.)

## Áp dụng vào thực tế — 4 bước

1. **Xây customer insight & persona** — hiểu rõ KH mục tiêu (dùng `brandformance-customer-insight`).
2. **Chọn công cụ tiếp cận** — inbound/outbound marketing đưa content đến khách đúng kênh.
3. **Lập kế hoạch content theo giai đoạn** — mỗi giai đoạn một mục tiêu, một loại content (bảng trên).
4. **Tối ưu trải nghiệm mọi điểm chạm** — đảm bảo trải nghiệm tốt ở mọi touchpoint, không đứt gãy giữa các kênh.

## Được phép gộp / đảo / né giai đoạn

Hành trình không cứng nhắc. Tùy thị trường & tệp khách:
- **Gộp** giai đoạn khi chu kỳ mua ngắn.
- **Đảo** thứ tự khi hành vi thực tế khác.
- **Né** giai đoạn "Chưa biết → Biết" nếu thị trường cạnh tranh gắt — tập trung ngân sách vào tệp đặc biệt ở giai đoạn sau thay vì đốt tiền phủ nhận thức.

→ Quyết định gộp/né phải dựa trên đặc điểm thị trường + ngân sách, không làm cho đủ 7 bước.

## Mô hình bánh đà (Flywheel)

Khác phễu tuyến tính (đổ khách vào rồi rơi ra ở đáy), bánh đà coi **khách hài lòng ở giai đoạn 5–6–7 quay lại tạo lực đẩy cho giai đoạn 1–2** của khách mới (qua review, UGC, giới thiệu). Đầu tư vào hậu mãi & trung thành không phải chi phí cuối phễu — nó là nhiên liệu đầu phễu rẻ nhất.

## Kết nối skill

- Insight & persona đầu vào → `brandformance-customer-insight`, `brandformance-market-research`.
- Lịch & ma trận content triển khai → `brandformance-content-calendar`, `brandformance-content-matrix`.
- Content viral giai đoạn 1 → `brandformance-content-script` (xem `references/short-video-playbook.md`).
- Content tạo niềm tin giai đoạn 3 → `brandformance-ugc-koc-brief`, `brandformance-seeding-plan`.
- Giai đoạn 6–7 (community, trung thành) → `brandformance-community-building`, `brandformance-referral-program`.
