---
name: brandformance-referral-program
description: "Kích hoạt khi cần thiết kế chương trình giới thiệu (referral) và loyalty — cơ chế incentive, tracking, kênh kích hoạt. Trigger: 'chương trình giới thiệu', 'referral program', 'khách giới thiệu khách', 'loyalty program', 'tăng referral', 'khách cũ giới thiệu khách mới'."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Referral Program

## 1. Triggers

### Explicit triggers
- "thiết kế chương trình giới thiệu", "referral program"
- "loyalty program", "tăng khách giới thiệu"

### Implicit triggers
- Đã có nhiều KH hài lòng nhưng referral chỉ xảy ra tự phát, không có cơ chế chủ động
- CAC từ ads tăng dần — cần kênh acquisition rẻ hơn
- Tỉ lệ giới thiệu tự nhiên cao nhưng chưa có chương trình chính thức

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Sản phẩm/dịch vụ và LTV trung bình 1 khách hàng
- [ ] **[BẮT BUỘC]** Đã có nhóm KH đạt kết quả tốt/hài lòng rõ ràng chưa
- [ ] **[NẾU CÓ]** Data hiện tại về % KH đến từ giới thiệu

## 3. Execution Steps

### Bước 1: Xác định thời điểm đúng để hỏi referral
Không hỏi ngay sau khi mua — hỏi ngay sau khi KH đạt **"aha moment"**: lúc họ vừa thấy kết quả rõ ràng nhất. Đây là lúc cảm xúc tích cực cao nhất.

### Bước 2: Thiết kế incentive 2 chiều (double-sided)
Incentive cho CẢ người giới thiệu VÀ người được giới thiệu hiệu quả hơn nhiều so với chỉ thưởng 1 chiều.

Ví dụ cấu trúc: "Giới thiệu bạn → Bạn được giảm 10%, bạn của bạn cũng được giảm 10%"

### Bước 3: Cơ chế tracking đơn giản cho SME
3 lựa chọn theo độ phức tạp tăng dần:
- Đơn giản nhất: Hỏi trực tiếp "Ai giới thiệu bạn đến đây?" trong form/khi tư vấn
- Trung bình: Mã giới thiệu riêng cho từng KH cũ (dễ nhớ, dễ nói miệng)
- Nâng cao: Link giới thiệu riêng qua Zalo/tool tracking

### Bước 4: Kênh kích hoạt referral
- Email/Zalo OA gửi ngay sau "aha moment" (không đợi đến cuối customer journey)
- Nhắc trong Community — dùng social proof có sẵn
- Sale/CSKH hỏi trực tiếp trong lúc chăm sóc

### Bước 5: Kết nối với Bypass Lead
KH đến từ giới thiệu thường có LTV cao hơn và tỉ lệ chốt cao hơn — gắn tag riêng trong CRM để đo ROI thực của chương trình.

### Bước 6: Build Referral Program document
Cơ chế đầy đủ: Điều kiện tham gia + Incentive 2 chiều + Kênh kích hoạt + Cách tracking + Cách trao thưởng.

## 4. Examples

### Example 1 — Dịch vụ chăm sóc da spa
```
THỜI ĐIỂM HỎI: Ngay sau liệu trình thứ 3 (khi khách bắt đầu thấy kết quả rõ)

INCENTIVE: "Giới thiệu bạn bè → Bạn nhận 1 buổi chăm sóc miễn phí, bạn của bạn được giảm 15% lần đầu"

TRACKING: Mã giới thiệu là tên khách + 3 số cuối SĐT — nhân viên lễ tân nhập vào CRM khi khách mới đặt lịch

KÍCH HOẠT: Nhân viên hỏi trực tiếp cuối buổi + gửi Zalo OA nhắc lại sau 3 ngày kèm mã
```

### Example 2 — Khóa học kỹ năng online
```
THỜI ĐIỂM HỎI: Ngay sau khi học viên hoàn thành module đầu tiên và để lại feedback tích cực

INCENTIVE: "Giới thiệu 1 người đăng ký → Bạn nhận thêm 1 tháng học phí, người mới giảm 20%"

TRACKING: Link giới thiệu riêng qua landing page, gắn UTM riêng theo học viên

KẾT NỐI BYPASS LEAD: Đánh tag "Referral - có chương trình" khác với "Bypass - giới thiệu tự phát"
```

## 5. Edge Cases & Error Handling

**Incentive quá thấp không đủ động lực**: Incentive nên tương đương 10-20% CAC trung bình.
**Incentive quá cao thu hút referral rác**: Thêm điều kiện xác thực (phải hoàn thành 1 hành động cụ thể).
**Không có cơ chế tracking**: Bắt đầu từ cách đơn giản nhất (hỏi trực tiếp).

## 6. State Management

| State | Claude làm gì |
|---|---|
| `TIMING_IDENTIFY` | Xác định thời điểm đúng để hỏi |
| `INCENTIVE_DESIGN` | Thiết kế incentive 2 chiều |
| `TRACKING_SETUP` | Chọn cơ chế tracking phù hợp |
| `ACTIVATION_CHANNEL` | Xác định kênh kích hoạt |
| `BYPASS_LINK` | Kết nối với Bypass Lead tracking |
| `DONE` | Referral Program document hoàn chỉnh |

## References
- `brandformance-framework.md` → Phần V, IV
- `brandformance-bypass-lead-system.md` → Đồng bộ tracking nguồn KH
- `brandformance-community-building.md` → Kênh kích hoạt qua community
