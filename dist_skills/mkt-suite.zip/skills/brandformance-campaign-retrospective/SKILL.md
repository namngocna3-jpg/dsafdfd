---
name: brandformance-campaign-retrospective
description: "Kích hoạt khi cần tổng kết campaign vừa kết thúc và ghi vào Campaign Memory — điều gì work, điều gì không, insight khách hàng mới phát hiện. Trigger: 'retrospective campaign', 'tổng kết campaign', 'campaign memory', 'rút kinh nghiệm chiến dịch', 'campaign vừa kết thúc có gì học được'. Kích hoạt ngay sau khi 1 campaign kết thúc, trước khi lập kế hoạch chu kỳ tiếp theo."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Campaign Retrospective

## 1. Triggers

### Explicit triggers
- "tổng kết campaign vừa xong", "campaign retrospective"
- "campaign memory", "rút kinh nghiệm chiến dịch này"

### Implicit triggers
- Campaign vừa kết thúc (theo Timeline ở `brandformance-campaign-timeline.md`)
- Chuẩn bị lập plan cho chu kỳ tiếp theo nhưng chưa tổng kết chu kỳ vừa qua
- Có insight khách hàng mới xuất hiện trong quá trình chạy (câu hỏi lạ, objection mới) chưa được ghi lại đâu cả

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Campaign vừa kết thúc + kết quả thực tế đầy đủ (ads, content, conversion, doanh thu)
- [ ] **[BẮT BUỘC]** Campaign Plan gốc để so sánh mục tiêu ban đầu
- [ ] **[NẾU CÓ]** Content Report, Ads Report, Email Report của campaign đó

Đọc trước khi thực hiện:
- `brandformance-campaign-plan.md` → Kế hoạch gốc để đối chiếu
- `brandformance-measurement.md` → Toàn bộ

## 3. Execution Steps

### Bước 1: So sánh kết quả thực tế vs mục tiêu ban đầu
Đối chiếu từng KPI trong Campaign Plan gốc với kết quả thật: đạt / vượt / thiếu, và thiếu bao nhiêu %.

### Bước 2: Rút insight theo 4 khía cạnh
- **Brand message**: Thông điệp nào resonate nhất qua từng phase (Teasing/Bung nhẹ/Bung mạnh)?
- **Creative/hook**: Hook/format nào work nhất, dữ liệu cụ thể từ Ads Report/Content Report
- **Audience**: Audience nào convert tốt nhất, tệp nào không hiệu quả
- **Offer**: Offer có đủ hấp dẫn không, tripwire→core offer bridge có hoạt động không

### Bước 3: Ghi nhận insight khách hàng mới
Trong quá trình chạy, có câu hỏi/objection/ngôn ngữ mới nào từ KH mà trước đây chưa biết? Đây là nguyên liệu quý cho `brandformance-customer-insight.md` lần cập nhật tới.

### Bước 4: Phân loại What Worked / What Didn't / Surprises
```
WHAT WORKED (giữ lại, nhân bản):
- [Cụ thể, có số liệu]

WHAT DIDN'T WORK (tránh lặp lại):
- [Cụ thể, có số liệu]

SURPRISES (không lường trước, cần theo dõi thêm):
- [Điều bất ngờ, tích cực hoặc tiêu cực]
```

### Bước 5: Build Campaign Memory entry theo format chuẩn
Format nhất quán để dễ tái sử dụng — không viết tự do, phải theo cấu trúc cố định để `brandformance-next-cycle.md` scan lại được dễ dàng.

### Bước 6: Lưu vào Notion Campaign Memory database
Ghi entry mới, gắn tag theo loại campaign/mùa vụ/sản phẩm để tra cứu sau này.

## 4. Examples

### Example 1 — Generic: Campaign launch dịch vụ tư vấn tài chính
```
KẾT QUẢ VS MỤC TIÊU: Target 15 KH mới — đạt 12 (80%). Target CPL 500K — thực tế 620K (vượt 24%).

WHAT WORKED:
- Hook "3 lỗi tài chính phổ biến người đi làm 30 tuổi" — CTR 2.1%, cao nhất trong campaign
- Retarget từ video viewers 75%+ có tỉ lệ chốt 35%, cao hơn nhiều so với cold audience (8%)

WHAT DIDN'T WORK:
- Audience Broad ở Phase Teasing không hiệu quả — CPM cao gấp đôi ước tính do cạnh tranh mùa cao điểm
- Landing page có 6 field form — form fill rate chỉ 6%, thấp hơn benchmark 15%

SURPRISES:
- Nhiều KH inbox hỏi "có tư vấn online không" — insight mới: KH ở tỉnh cũng quan tâm nhưng
  ngại không hỏi trực tiếp vì tưởng chỉ phục vụ TP.HCM

CAMPAIGN MEMORY ENTRY: Tag [tư vấn tài chính, Q3, retarget-work]
→ Nhân rộng: Hook dạng "3 lỗi phổ biến", Retarget video viewers 75%+
→ Tránh lặp lại: Audience Broad trong mùa cao điểm, form landing page quá dài
→ Cần khai thác: Insight "tư vấn online cho tỉnh" cho campaign tới
```

### Example 2 — Giáo dục: Campaign khai giảng khóa học AI
```
KẾT QUẢ VS MỤC TIÊU: Target 30 học viên — đạt 22 (73%)

WHAT WORKED: Webinar miễn phí làm cầu nối rất tốt — 60% người tham gia webinar đăng ký khóa học
WHAT DIDN'T WORK: Email D-3 (FAQ) có CTR thấp nhất sequence — nội dung quá dài, không đúng câu hỏi thật KH hay hỏi
SURPRISES: Nhiều học viên đăng ký sau khi xem lại webinar recording (không tham gia live) —
insight mới: nên gửi recording sớm hơn, không đợi đến cuối sequence

CAMPAIGN MEMORY ENTRY: Tag [khóa học AI, khai giảng, webinar-work]
→ Nhân rộng: Webinar làm cầu nối chuyển đổi chính
→ Tránh: Email FAQ dài dòng — rút gọn và dùng đúng câu hỏi thật từ inbox
→ Test mới chu kỳ tới: Gửi recording webinar sớm hơn (D+1 thay vì D+5)
```

## 5. Edge Cases & Error Handling

**Campaign chưa đủ data để rút kết luận chắc chắn** (mẫu nhỏ, chạy ngắn ngày): Ghi rõ giới hạn, đánh dấu insight là "sơ bộ, cần thêm data" thay vì kết luận cứng.

**Kết quả tốt nhưng không rõ tại sao (lucky vs replicable)**: Phân biệt rõ — nếu chỉ có 1 yếu tố thay đổi trong kỳ thì có thể attribute; nếu nhiều biến thay đổi cùng lúc, ghi nhận là "chưa rõ nguyên nhân chính, cần test tách biệt ở chu kỳ sau".

**Campaign thất bại hoàn toàn**: Vẫn phải viết retrospective đầy đủ — thất bại có insight giá trị không kém thành công, đặc biệt là phần "What Didn't Work".

## 6. State Management

| State | Claude làm gì |
|---|---|
| `RESULT_COMPARE` | So sánh thực tế vs mục tiêu |
| `INSIGHT_EXTRACT` | Rút insight 4 khía cạnh |
| `CUSTOMER_INSIGHT` | Ghi nhận insight KH mới |
| `CLASSIFY` | Phân loại Worked/Didn't/Surprises |
| `MEMORY_FORMAT` | Build entry theo format chuẩn |
| `DONE` | Lưu vào Notion Campaign Memory |

## References
- `brandformance-campaign-plan.md` → Kế hoạch gốc để đối chiếu
- `brandformance-ads-report.md`, `brandformance-content-report.md`, `brandformance-email-report.md` → Nguồn dữ liệu
- `brandformance-next-cycle.md` → Dùng entry này làm evidence bắt buộc phải quét trước
- `brandformance-customer-insight.md` → Cập nhật khi có insight KH mới
