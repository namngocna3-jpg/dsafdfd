---
name: brandformance-email-plan
description: "Kích hoạt khi cần xây dựng chiến lược email marketing Brandformance — chuỗi welcome, nurture, BOFU theo tầng phễu. Trigger: 'email marketing', 'xây chuỗi email', 'email sequence', 'kế hoạch email', 'setup email marketing', 'email funnel'. Kích hoạt cả khi cần setup email từ đầu hoặc optimize email đang chạy."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: customer</summary>

# brandformance-customer

> Kiến thức về phân khúc khách hàng và chân dung KH — đọc trước khi chạy bất kỳ skill research, content, hoặc nurture/conversion.

## I. Nguyên tắc phân khúc

Ngân sách của bất kỳ SME nào không đủ để tiếp cận toàn bộ thị trường. Câu hỏi không phải "khách hàng mục tiêu là ai" mà là "vùng nào mình có thể thắng với ngân sách hiện tại."

## II. Phương pháp cắt lát (phân khúc thị trường)

Tiêu chí cắt lát: Hành vi (đã thử giải pháp nào) + Vấn đề đang gặp (cụ thể) + Giai đoạn ra quyết định

## III. Phương pháp cắt lớp (chân dung KH)

Đi sâu vào: vị trí trong hành trình mua + câu nói nội tâm thật + điều gì ngăn ra quyết định.

## IV. 3 nhóm khách hàng

**Nhóm Lạnh** — chưa biết brand. KPI: CPM, Video View Rate, organic reach.
**Nhóm Ấm** — đã biết, đang cân nhắc. KPI: CTR, CPL, engagement depth.
**Nhóm Nóng** — gần ra quyết định. KPI: CPA, CPO, Inbox→Booking rate.

## V. Lead chất lượng

MQL: đúng ICP + tín hiệu nhu cầu rõ ràng.
SQL: brand seeding đủ + có ngân sách + quyền quyết định.

MQL là điều kiện cần. SQL là điều kiện đủ để Sales tiếp nhận.

Điểm số tối giản: Đúng Persona (20đ) + Ngân sách phù hợp (20đ) + Intent rõ (25đ) + Tiếp xúc ≥2 lần (20đ) + Phản hồi nhanh (15đ). Ngưỡng: SQL ≥80 → Sales gọi trong 2-4h / MQL 60-79 → tiếp tục nurture / Cold <60 → nurture dài hạn.

## VI. Bypass Lead

Không đi qua phễu nhưng vẫn mua. LTV thường cao hơn lead thường vì đã có sẵn trust (quen biết, network cá nhân, giới thiệu miệng). Nguồn phổ biến nhất: Zalo cá nhân của founder/sale — khác hẳn Zalo OA (broadcast tự động), đây là kênh 1-1 mang tính con người.

Tracking: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới (form, Sale, gặp trực tiếp) + gắn tag riêng trong CRM, không gộp chung với lead phễu chính thức — gộp chung sẽ làm sai lệch phân tích LTV và tỉ lệ chốt theo từng nguồn.

## VII. Referral

KH hài lòng là nguồn lead rẻ nhất và có tỉ lệ chốt cao nhất — nhưng chỉ khi có cơ chế chủ động, không để tự phát.

Thời điểm đúng để hỏi giới thiệu: ngay sau "aha moment" — lúc KH vừa thấy kết quả rõ ràng nhất, không phải ngay sau khi mua.

Incentive 2 chiều (double-sided — cả người giới thiệu và người được giới thiệu đều có lợi) hiệu quả hơn 1 chiều vì người giới thiệu không cảm thấy giống đang "bán hàng" cho bạn bè. KH đến từ referral thường có LTV và tỉ lệ chốt cao hơn KH đến từ ads.

</details>

---

# Email Plan

## 1. Triggers
- "email marketing", "chuỗi email", "email sequence"
- Setup email từ đầu hoặc optimize email đang chạy

## 2. Context Requirements
- [ ] **[BẮT BUỘC]** List size, platform (Mailchimp/ConvertKit/Klaviyo)
- [ ] **[BẮT BUỘC]** Customer Insight (3 nhóm)
- [ ] **[NẾU CÓ]** Open rate, CTR hiện tại

## 3. Execution Steps

### Bước 1: Email = NURTURE + CONVERT, không phải TOFU

Sequences theo mục tiêu:
- Welcome: Vừa subscribe → Onboard + qualify
- Nurture: Lead warm → Build trust → Hot
- BOFU: Trước launch → Convert Hot lead
- Post-purchase: Sau mua → Onboard + retention + referral

### Bước 2: Welcome Sequence (5-7 emails, 14 ngày)

Email 1 (Ngay): Welcome + deliver LM. Subject: "Đây là [LM] bạn đăng ký"
Email 2 (Ngày 2): Founder story + 1 insight thật
Email 3 (Ngày 4): Education + Case study
Email 4 (Ngày 7): Soft offer (mention sản phẩm QUA kết quả, không pitch)
Email 5 (Ngày 10): FAQ / objection handling
Email 6 (Ngày 14): CTA rõ ràng + deadline

### Bước 3: BOFU Sequence (5 emails, 7 ngày)
D-7: Mở cửa đăng ký
D-5: Social proof (case study + số liệu)
D-3: FAQ / objection xử lý
D-1: Urgency "Còn 24 giờ"
D-0: Final push

### Bước 4: KPIs

| Metric | Good | Excellent |
|---|---|---|
| Open rate | > 20% | > 35% |
| CTR | > 2% | > 5% |
| Unsubscribe | < 0.5% | < 0.2% |

Open < 15% → Subject line / List quality. CTR < 1% → Body content / CTA.

## 4. Examples

### Example 1 — Welcome: Khóa học content marketing
```
EMAIL 1: "[Tên] — Checklist viết caption của bạn đây" → Deliver + set expectation
EMAIL 2: "Lần đầu chạy ads 200 triệu thất bại — bài học" → Story
EMAIL 4: "Từ 0 inbox → 15 inbox/ngày sau 3 tuần" → Case study soft mention
EMAIL 6: "Khóa Content Marketing mở — 15 slot" → Offer + deadline
```

### Example 2 — BOFU: Spa promo tháng 8
```
D-7: "Flash Sale tháng 8 mở cửa — ưu đãi cho subscriber"
D-5: "Chị Hoa xóa nám 8 tuần với liệu trình này"
D-3: "Liệu trình có phù hợp da nhạy cảm không?"
D-1: "Còn 24 giờ — sau đó giá trả về mức bình thường"
D-0 (9h): "Kết thúc 23:59 hôm nay"
D-0 (19h): "Còn 5 slot"
```

## 5. Edge Cases
Open rate thấp → A/B test subject line + check sender name + preview text.
Unsubscribe cao → Quá promotional hoặc quá dày (> 3 emails/tuần).
List nhỏ < 200 → Build list trước, BOFU sequence không đủ sample.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `STRATEGY` | Email strategy theo tầng |
| `WELCOME_BUILD` | Welcome sequence |
| `BOFU_BUILD` | BOFU sequence |
| `KPI_SET` | KPIs + benchmarks |
| `DONE` | Email plan hoàn chỉnh |

## References
- `brandformance-content.md` → Phần X (Email channel)
- `brandformance-customer.md` → Phần III (Câu nói nội tâm = subject line gold)
