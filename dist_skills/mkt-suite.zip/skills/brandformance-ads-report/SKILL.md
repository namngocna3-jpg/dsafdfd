---
name: brandformance-ads-report
description: "Kích hoạt khi cần báo cáo hiệu quả Performance Ads — CPL, ROAS, MER, CAC theo campaign kèm nhận định và action cụ thể. Trigger: 'báo cáo ads', 'report Meta Ads', 'CPL ROAS tháng này', 'báo cáo hiệu quả quảng cáo', 'ads tháng này ra sao'. Kích hoạt cả khi kết thúc chu kỳ ads hoặc cần cập nhật định kỳ cho founder."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Ads Report

## 1. Triggers

### Explicit triggers
- "báo cáo ads tháng/tuần này", "report Meta Ads"
- "CPL ROAS MER tháng này thế nào?"

### Implicit triggers
- Kết thúc chu kỳ chạy ads (tuần/tháng/campaign) → cần tổng kết
- Founder hỏi "ads đang hiệu quả không" mà chưa có báo cáo sẵn
- Chuẩn bị dùng `brandformance-next-cycle.md` → cần ads report làm input

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Data ads theo campaign/ad set/ad (spend, CPL, CTR, ROAS, CPA) trong khoảng thời gian
- [ ] **[BẮT BUỘC]** Mục tiêu KPI ban đầu để so sánh
- [ ] **[NẾU CÓ]** Data lịch sử kỳ trước

Đọc trước khi thực hiện:
- `brandformance-ads.md` → Toàn bộ (ngưỡng chỉ số tham chiếu ở Phần VI)
- `brandformance-measurement.md` → Phần IV, V

## 3. Execution Steps

### Bước 1: Thu thập số liệu theo cấp Campaign → Ad Set → Ad
Dùng Meta MCP nếu có kết nối. Chỉ số cần: Spend, Impressions, Reach, CTR, CPM, CPC, CPL/CPA, ROAS, Frequency.

### Bước 2: Tính chỉ số tổng hợp
- **MER** = Tổng doanh thu / Tổng chi marketing — quan trọng hơn ROAS từng kênh riêng lẻ
- **CAC** = Tổng chi phí / Số KH mới có được
- So sánh với mục tiêu ban đầu và benchmark trong `brandformance-ads.md` Phần VI

### Bước 3: Phân loại từng campaign/ad set theo ngưỡng chuẩn
| Trạng thái | Tiêu chí |
|---|---|
| Winner | CTR > 2%, CPL ổn định 5-7 ngày, đang trong ngân sách target |
| Cần tối ưu | CTR 0.8-2%, CPL cao hơn target nhưng chưa quá 2× |
| Nên dừng | CTR < 0.8% sau 3 ngày, hoặc CPL > 2× target sau 7 ngày |

### Bước 4: Chẩn đoán nguyên nhân theo tầng phễu bị nghẽn
Nếu ads yếu, xác định vấn đề nằm ở tầng nào (Reach→Click / Click→Lead / Lead→Chốt) trước khi kết luận — tham chiếu `brandformance-ads-optimize.md`.

### Bước 5: Đề xuất action ưu tiên
Mỗi campaign trong báo cáo phải có action rõ ràng: Scale / Tối ưu tiếp / Dừng — không chỉ liệt kê số.

### Bước 6: Build report + feed vào Campaign Memory
Ghi lại insight quan trọng (creative nào work, audience nào tốt) để dùng cho `brandformance-campaign-retrospective.md`.

## 4. Examples

### Example 1 — Generic: Dịch vụ thuê xe du lịch (báo cáo tháng)
```
TỔNG QUAN: Spend 15 triệu, 45 lead, CPL trung bình 333K (target 250K), ROAS 2.8x, MER 3.1x

PHÂN LOẠI:
[CAM 1] TOFU — CTR 2.3% ✓ Winner — Đề xuất: Giữ nguyên, không cần đổi creative
[CAM 2] MOFU Lead Gen — CTR 0.6% ⚠️ Cần tối ưu — Đề xuất: Đổi creative, đã chạy 10 ngày không đổi
[CAM 3] BOFU Retarget — CPL 180K ✓ Winner — Đề xuất: Scale +20% ngân sách

NHẬN ĐỊNH: MER 3.1x vẫn ổn dù CPL Cam 2 cao — vì Cam 3 đang bù tốt. Vấn đề gốc là Cam 2
đang target audience quá rộng (Broad 22-55 tuổi), không phải creative.

ACTION ƯU TIÊN: Thu hẹp audience Cam 2 về Interest cụ thể (du lịch gia đình + cưới hỏi) trong tuần tới.
```

### Example 2 — Giáo dục: Khóa học IELTS (báo cáo campaign vừa kết thúc)
```
TỔNG QUAN: Spend 20 triệu / 14 ngày, 25 học viên đăng ký (target 30), CPA 800K (target 665K)

PHÂN LOẠI:
[CAM Webinar Reg] — CTR 3.1%, CPL 90K ✓ Winner
[CAM BOFU Retarget] — ROAS 4.2x ✓ Winner
[CAM TOFU Broad] — CTR 0.5% ✗ Nên dừng — đã dừng ngày 5 sau khi phát hiện

NHẬN ĐỊNH: Không đạt target 30 học viên vì TOFU Broad thất bại sớm làm giảm tổng traffic vào phễu
2 tuần đầu. Webinar + Retarget hoạt động rất tốt khi có đủ traffic.

ACTION CHO CHU KỲ TỚI: Bỏ hẳn TOFU Broad, thay bằng TOFU Interest ngay từ đầu — dựa trên
bài học `brandformance-ads-testing.md` về audience test.
```

## 5. Edge Cases & Error Handling

**ROAS thấp ở 1 kênh nhưng MER tổng vẫn ổn**: Giữ nguyên kênh đó, không vội cắt — MER là chỉ số quyết định, không phải ROAS từng campaign riêng lẻ.

**Data chưa đủ statistical significance** (impressions/conversions quá ít): Nêu rõ giới hạn, không đưa ra kết luận chắc chắn về winner/loser.

**Thay đổi chính sách/pixel Meta giữa kỳ ảnh hưởng số liệu**: Ghi chú riêng, tách biệt phần data trước/sau thay đổi khi so sánh trend.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `DATA_PULL` | Thu thập số liệu Meta MCP |
| `METRIC_CALC` | Tính MER, CAC, so sánh benchmark |
| `CLASSIFY` | Phân loại Winner/Tối ưu/Dừng |
| `DIAGNOSIS` | Chẩn đoán nguyên nhân |
| `ACTION_PROPOSE` | Đề xuất action ưu tiên |
| `DONE` | Ads Report + feed Campaign Memory |

## References
- `brandformance-ads.md` → Toàn bộ (ngưỡng chuẩn)
- `brandformance-ads-optimize.md` → Fix cụ thể khi ads yếu
- `brandformance-campaign-retrospective.md` → Dùng report này làm input
