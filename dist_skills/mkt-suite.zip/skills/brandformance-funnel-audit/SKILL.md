---
name: brandformance-funnel-audit
description: "Kích hoạt khi cần chẩn đoán điểm nghẽn trong phễu Brandformance — xác định brand yếu ở tầng nào, performance gãy ở tầng nào, và root cause cụ thể. Trigger: 'audit phễu', 'chẩn đoán điểm nghẽn', 'phễu bị gãy ở đâu', 'funnel audit', 'tại sao không ra doanh thu dù traffic ổn', 'traffic nhiều nhưng không ra đơn'. Kích hoạt cả khi có đủ traffic nhưng doanh thu không tương xứng."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: measurement</summary>

# brandformance-measurement

> Kiến thức về đo lường và tối ưu hóa hệ thống Brandformance — đọc trước khi chạy bất kỳ skill đo lường/báo cáo.

## I. Bộ khung đo lường

NSM (North Star Metric) — Kim chỉ nam dài hạn, phản ánh giá trị KH nhận được.
AARRR — Bản đồ hành trình: Acquisition → Activation → Retention → Revenue → Referral.
OMTM (One Metric That Matters) — Trọng tâm ngắn hạn. Lấy chỉ số yếu nhất trong AARRR làm OMTM tháng.
Benchmark — Chuẩn so sánh từ báo cáo ngành, data đối thủ, data lịch sử nội bộ.

Thứ tự logic: NSM → AARRR → OMTM → Benchmark.

## II. Mapping ngược từ doanh thu

Mục tiêu doanh thu tháng → cần bao nhiêu đơn → cần bao nhiêu lead qualified → cần bao nhiêu lead tổng → cần reach bao nhiêu người → cần bao nhiêu content/ads.

## III. Lead Scoring

Điểm số tối giản cho SME:
- Đúng Customer Persona: 20 điểm
- Có ngân sách phù hợp: 20 điểm
- Intent signal rõ (xem pricing, hỏi trực tiếp): 25 điểm
- Đã tiếp xúc brand ≥2 lần: 20 điểm
- Phản hồi nhanh khi được liên hệ: 15 điểm

Ngưỡng: SQL ≥80 → Sales tiếp trong 2-4h / MQL 60-79 → Nurture tiếp / Cold <60 → Brand-building dài hạn.

## IV. Chỉ số theo từng tầng AARRR

Awareness: CPM, Reach, Video View Rate 3s
Acquisition: CPL, CTR, tỉ lệ form đủ thông tin
Activation: Tỉ lệ lead qualified, tỉ lệ inbox→tư vấn
Retention: Tỉ lệ mua lần 2/60 ngày, open rate
Revenue: AOV, ROAS kênh, MER tổng, CAC, LTV
Referral: % lead từ giới thiệu (chính thức + Bypass Lead tự phát), UGC tự nhiên

MER = Tổng doanh thu / Tổng chi marketing. MER > 3 là ổn với SME tăng trưởng.
LTV/CAC: LTV < 3x CAC → mô hình không bền.

## V. Bảng đọc điểm nghẽn

CTR < 1% liên tục → Review top/bottom creative
CPL tăng 3 tuần → Check frequency, thử tệp mới
Mess nhiều, lead ít → Đọc lại 20 mess đầu
Lead nhiều, CR thấp → Nghe lại call/chat
ROAS thấp nhưng MER ổn → Giữ kênh, không cắt
MER giảm đều → Kiểm tra offer tổng
Số liệu bất thường không rõ lý do → Kiểm tra tracking/pixel/EMQ trước khi đổ lỗi creative hay audience

## VI. Dashboard

Đọc mỗi tuần: CPL + Tỉ lệ lead qualified + Tỉ lệ chốt + ROAS + MER.
Review mỗi tháng: Brand KPI (reach tự nhiên, follower growth) + Performance KPI đầy đủ + NSM.

Cấu trúc 3 lớp khi tự xây dashboard: **Raw Data** (import/dán thô) → **Calculation** (công thức) → **Dashboard View** (chỉ số đã tính, dễ nhìn) — tách lớp để không ai vô tình sửa nhầm công thức.

## VII. Community Metrics

Growth (thành viên mới trừ rời đi) + Tỉ lệ active (tương tác trong 30 ngày — quan trọng hơn tổng số thành viên) + Chuyển đổi sang funnel chính.

KPI kỳ vọng khác theo loại community: TOFU đo growth/reach, MOFU đo tỉ lệ tham gia Q&A + chuyển đổi nhẹ, BOFU đo referral phát sinh + repeat purchase.

</details>

---

# Funnel Audit

## 1. Triggers

### Explicit triggers
- "audit phễu marketing", "funnel audit", "chẩn đoán điểm nghẽn"
- "tại sao traffic ổn mà không ra doanh thu?"

### Implicit triggers
- Reach/traffic tốt nhưng lead hoặc doanh thu không tương xứng
- Đã tối ưu từng phần riêng lẻ (ads, content, landing page) nhưng tổng thể vẫn yếu
- Chuẩn bị scale ngân sách nhưng chưa chắc phễu hiện tại có đủ vững để scale
- Số liệu tốt ở giữa phễu nhưng đầu vào hoặc cuối phễu yếu

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Số liệu đầy đủ từng tầng phễu: Reach → Click → Lead → Qualified → Chốt → Doanh thu
- [ ] **[BẮT BUỘC]** Mục tiêu KPI ban đầu để so sánh
- [ ] **[NẾU CÓ]** Benchmark ngành hoặc data lịch sử nội bộ

Đọc trước khi thực hiện:
- `brandformance-measurement.md` → Phần V (Bảng đọc điểm nghẽn)
- `brandformance-framework.md` → Phần VII (Điểm nghẽn phổ biến), Phần III (Phễu 4 giai đoạn)

## 3. Execution Steps

### Bước 1: Thu thập số liệu full-funnel
Không audit từng phần riêng lẻ — cần nhìn toàn bộ chuỗi: Reach → Click (CTR) → Lead (CPL, form fill rate) → Qualified (tỉ lệ MQL→SQL) → Chốt (tỉ lệ inbox→chốt) → Doanh thu (AOV, ROAS, MER).

### Bước 2: Chạy qua bảng chẩn đoán theo tầng
| Triệu chứng | Vấn đề khả nghi |
|---|---|
| Reach cao, CTR < 1% | Creative không chạm hoặc sai audience — vấn đề BRAND/CONTENT |
| CTR ổn, form fill thấp | Landing page/Offer — vấn đề PERFORMANCE structure |
| Lead nhiều, tỉ lệ qualified thấp | Audience targeting sai hoặc content thu hút sai người |
| Qualified cao, tỉ lệ chốt thấp | Sales process/script yếu — vấn đề PERFORMANCE execution |
| ROAS thấp nhưng MER ổn | Không phải vấn đề — kênh khác đang bù, giữ nguyên |
| MER giảm đều toàn hệ thống | Vấn đề ở Offer tổng thể, không phải 1 kênh cụ thể |

### Bước 3: Phân biệt Brand gãy vs Performance gãy
- **Brand gãy**: Reach tốt nhưng không convert vì KH không tin tưởng đủ — thường thấy ở CTR ổn nhưng inbox hỏi rồi biến mất nhiều, hoặc followers tăng nhưng không có "recall" thương hiệu
- **Performance gãy**: Cơ chế chuyển đổi có vấn đề cụ thể — form, tracking, script, giá — có thể fix nhanh bằng thay đổi kỹ thuật

### Bước 4: Root cause, không dừng ở triệu chứng
Với mỗi điểm nghẽn tìm được, hỏi tiếp "tại sao" ít nhất 2 lần. Ví dụ: "CTR thấp" → tại sao? → "Creative cũ, đã chạy 3 tuần" → tại sao chưa đổi? → "Không có quy trình sản xuất creative mới định kỳ" = root cause thật.

### Bước 5: Đề xuất fix theo ưu tiên impact
Xếp hạng điểm nghẽn theo: (1) Impact tới doanh thu, (2) Effort để fix, (3) Thời gian thấy kết quả. Ưu tiên "impact cao, effort thấp" trước.

### Bước 6: Build Funnel Audit Report
Sơ đồ phễu với số liệu từng tầng + đánh dấu điểm nghẽn + root cause + đề xuất fix theo ưu tiên.

## 4. Examples

### Example 1 — Generic: Dịch vụ sửa chữa nhà (traffic tốt, ít đơn)
```
SỐ LIỆU: Reach 80K/tháng, CTR 1.5% (tốt), Form fill 8% (thấp — benchmark 15%),
Lead → Chốt 30% (tốt)

CHẨN ĐOÁN: Vấn đề nằm ở Landing Page/Offer, không phải Creative hay Sales.
ROOT CAUSE: Form yêu cầu 6 field (tên, SĐT, email, địa chỉ, loại dịch vụ, mô tả chi tiết)
→ Quá nhiều ma sát cho KH đang ở giai đoạn cân nhắc.

FIX ƯU TIÊN: Giảm form xuống 2 field (Tên + SĐT), chuyển câu hỏi chi tiết sang bước tư vấn qua điện thoại.
Impact: Cao / Effort: Thấp / Thời gian thấy kết quả: 1 tuần
```

### Example 2 — Giáo dục: Trung tâm kỹ năng (lead nhiều, chốt ít)
```
SỐ LIỆU: CPL 120K (rất tốt), Lead → Qualified 70% (tốt), Qualified → Chốt chỉ 8% (rất thấp — benchmark 20%)

CHẨN ĐOÁN: Vấn đề ở PERFORMANCE execution — Sales process, không phải Marketing.
ROOT CAUSE: Sale mới, chưa có script chuẩn, hay để lead im lặng quá 3 ngày mới follow-up lại.

FIX ƯU TIÊN 1: Áp dụng `brandformance-lead-conversion.md` — script chuẩn + cadence follow-up
FIX ƯU TIÊN 2: Setup SLA follow-up trong 2h cho lead SQL (theo `brandformance-lead-scoring.md`)
Impact: Cao / Effort: Trung bình / Thời gian thấy kết quả: 2-3 tuần
```

## 5. Edge Cases & Error Handling

**Nhiều điểm nghẽn cùng lúc**: Chỉ fix 1 điểm nghẽn lớn nhất trước, đo lại sau 1-2 tuần rồi mới sang điểm tiếp theo — tránh thay đổi nhiều biến cùng lúc gây khó đánh giá.

**Data không đủ để chẩn đoán chính xác** (mẫu quá nhỏ): Nêu rõ giới hạn, đề xuất chạy thêm ít nhất 1-2 tuần hoặc tăng ngân sách test trước khi kết luận.

**Phễu mới, chưa có benchmark nội bộ**: Dùng benchmark ngành tạm thời từ `brandformance-ads.md` Phần VI, điều chỉnh sau khi có đủ data thực tế.

## 6. State Management

| State | Claude làm gì |
|---|---|
| `DATA_COLLECT` | Thu thập số liệu full-funnel |
| `DIAGNOSIS` | Chạy bảng chẩn đoán theo tầng |
| `BRAND_VS_PERF` | Phân loại Brand gãy vs Performance gãy |
| `ROOT_CAUSE` | Đào sâu nguyên nhân gốc |
| `PRIORITIZE` | Xếp hạng fix theo impact |
| `DONE` | Funnel Audit Report hoàn chỉnh |

## References
- `brandformance-measurement.md` → Phần V (Bảng đọc điểm nghẽn)
- `brandformance-ads-optimize.md` → Fix cụ thể tầng Ads
- `brandformance-lead-conversion.md` → Fix cụ thể tầng Sales
- `brandformance-landing-page.md` → Fix cụ thể tầng Landing Page
