---
name: brandformance-creative-review
description: "Kích hoạt khi cần review và đánh giá creative/brief/content theo tiêu chí Brandformance — kiểm tra Brand layer + Performance layer + mức độ phù hợp tầng phễu. Trigger: 'review creative', 'brief có ổn không', 'content này đạt chuẩn không', 'duyệt content', 'check ads trước khi chạy', 'caption này được không', 'copy quảng cáo ổn chưa', 'nội dung này đúng tone chưa', 'review bài đăng'. Kích hoạt cả khi user paste nội dung vào và hỏi ý kiến, hoặc khi team content cần duyệt trước khi publish/upload ads."
---

## 🧠 Kiến thức nền Brandformance — NHÚNG SẴN, tự động áp dụng <!-- bf-autoload -->
> Kiến thức nền đã được nhúng thẳng bên dưới. LUÔN áp dụng khi thực thi skill này. Không cần đọc file ngoài, không hỏi lại người dùng. (Không xoá phần này.)

<details><summary>📚 Kiến thức nền: framework</summary>

# brandformance-framework

> Tài liệu nền tảng — đọc trước khi chạy bất kỳ skill nào trong bộ Brandformance 2026.

---

## I. Vấn đề Brandformance giải quyết

Phần lớn SME Việt Nam đang chọn một trong hai: hoặc chạy ads thuần performance (đốt tiền đo lead), hoặc làm brand thuần (đăng bài, không đo được gì). Cả hai đều sai vì thiếu nhau.

Chỉ làm performance: CPL tăng dần sau 3–6 tháng vì tệp audience bão hòa. Khách mua xong không nhớ tên thương hiệu. Remarketing chiếm 40–60% ngân sách mà tỉ lệ chốt vẫn giảm.

Chỉ làm brand: content đẹp, engagement ổn, nhưng doanh thu không theo. Không biết content nào đang dẫn khách vào phễu.

Brandformance không phải trung dung giữa hai cái trên. Đây là tư duy tích hợp: mọi hoạt động branding đều phải gắn với chỉ số đo được, và mọi hoạt động performance đều phải có chiều sâu thương hiệu đủ để khách không cần nghĩ lại khi quyết định mua.

## II. Bản chất Brandformance

Brandformance = Branding + Performance — nhưng không phải ghép cơ học. Mỗi điểm chạm với khách đồng thời làm hai việc: xây niềm tin thương hiệu và thúc đẩy hành động cụ thể.

## III. Phễu 4 giai đoạn (phiên bản SME)

GĐ1: Awareness + Acquisition (gộp) — Brand 70% / Performance 30%
GĐ2: Activation + Retention (gộp) — Brand 50% / Performance 50%
GĐ3: Conversion — Brand 30% / Performance 70%
GĐ4: Revenue + Referral — Brand 60% / Performance 40%

## IV. Bypass Lead

Khách không đi qua phễu nhưng vẫn mua — thường đến qua Zalo cá nhân của founder/sale, network cá nhân, hoặc giới thiệu miệng ngoài chương trình chính thức. Thường có LTV cao hơn lead thường vì đã có sẵn trust, không cần thuyết phục nhiều.

Nguyên tắc xử lý: luôn hỏi "biết đến qua đâu" khi tiếp nhận KH mới, gắn tag riêng trong CRM — không gộp chung với lead từ phễu chính thức vì hành vi mua và LTV khác nhau đáng kể, gộp chung sẽ làm sai lệch phân tích hiệu quả phễu. Khi Bypass Lead đủ lớn và có pattern rõ, nên chính thức hóa thành chương trình Referral có cơ chế thưởng — xem chi tiết trong nhóm Email & Owned Channels.

## V. Phễu AAARRR — khung đo lường

Awareness: CPM, Reach, Video View Rate
Acquisition: CPL, CTR, số lead
Activation: Tỉ lệ lead qualified, aha moment
Retention: Tỉ lệ mua lần 2, open rate
Revenue: AOV, ROAS, MER, CAC, LTV
Referral: % lead từ giới thiệu, UGC — nên có cơ chế chính thức (incentive 2 chiều) thay vì chỉ để tự phát

MER = Tổng doanh thu / Tổng chi marketing. Quan trọng hơn ROAS từng kênh.

## VI. Blueprint 8 thành phần

1. Chân dung KH + phân khúc
2. Định vị thương hiệu + Brand Bible
3. Hệ thống kênh (Reach/Nurture/Convert — gồm Meta, Google Search, Zalo OA, Email)
4. Hệ thống nội dung (4 Pillar + Calendar)
5. Hệ thống Lead (Hook→LM→Offer→Funnel→Landing Page→Conversion)
6. Hệ thống Ads (Setup→Tracking→Testing→Optimize→Scale→Creative Refresh)
7. Hệ thống đo lường (KPI→Dashboard→Report→Retrospective→Next Cycle)
8. Hệ thống tăng trưởng bền vững (Campaign Memory + Referral Program + Bypass Lead System)

## VII. Điểm nghẽn phổ biến

CTR < 1% liên tục → Creative không chạm, sai audience
CPL tăng 3 tuần → Tệp bão hòa, creative mệt
Mess nhiều, lead ít → Sai tệp, script chốt yếu
Lead nhiều, CR thấp → Lead rác, sales yếu
MER giảm đều → Cả hệ thống yếu, kiểm tra offer tổng
Số liệu ads bất thường không rõ lý do → Kiểm tra tracking/pixel trước khi kết luận creative hay audience sai

</details>

<details><summary>📚 Kiến thức nền: content</summary>

# brandformance-content

> Kiến thức về hệ thống nội dung Brandformance — đọc trước khi chạy bất kỳ skill content hoặc community.

## I. 4 Content Pillar theo mục đích phễu

Pillar 1: Nhận diện & Thu hút (TOFU) — không đề cập sản phẩm trực tiếp
Pillar 2: Giáo dục & Tin tưởng (MOFU) — đề cập sản phẩm gián tiếp
Pillar 3: Chuyển đổi (BOFU) — CTA rõ, offer cụ thể
Pillar 4: Giữ chân & Referral — nuôi dưỡng KH cũ

## II. Trục nội dung

Công thức: Trục nội dung = Mục tiêu truyền thông × Vấn đề KH × Thế mạnh thương hiệu

## III. Nguồn sản xuất content

FGC (Founder Generated Content) — lợi thế SME lớn nhất
BGC (Brand Generated Content) — kênh brand chính thức
EGC (Employee Generated Content) — nhân sự nội bộ
UGC (User Generated Content) — KH thật tạo content
KOC/KOL — người review trả phí

## IV. Ma trận content theo 3 tầng phễu

TOFU: Brand 80% / Perf 20% — CPM, View Rate
MOFU: Brand 50% / Perf 50% — CTR, CPL
BOFU: Brand 30% / Perf 70% — CPA, Conversion Rate

## V. Hook → Lead Magnet → Offer

Hook: thu hút attention (mọi giai đoạn)
Lead Magnet: đổi info lấy tài nguyên giá trị
Offer: gói SP/DV kèm giá trị, giảm rào cản ra quyết định
Chuỗi: Hook → LM → Thank-you page → Email/Zalo nurture → Core Offer → Retarget

## VI. Target bằng content

Target rộng + content nói đúng vấn đề cụ thể = content gạn lọc người phù hợp.
Bỏ target sâu theo hành vi/sở thích truyền thống (ngày càng sai lệch, đắt).

## VII. Content Funnel đa kênh

Facebook/Instagram: Reach + Conversion
TikTok: TOFU, viral, khám phá
Zalo OA: Nurture, retention — 2 loại tin khác nhau: **Broadcast** (quảng cáo, cần follower đồng ý, giới hạn 2-3 lần/tuần để tránh giảm follow rate) và **ZNS** (Zalo Notification Service — giao dịch/xác nhận đơn/lịch hẹn, không phải quảng cáo, độ tin cậy cao hơn). Nội dung phải ngắn, trực tiếp hơn Email vì thói quen kiểm tra Zalo nhiều lần/ngày.
Email: Nurture sequence, conversion — phù hợp nội dung sâu, case study dài mà Zalo không phù hợp.
Group/Forum: Seeding, social proof
Kênh Founder: Trust building, FGC

## VIII. Community — kênh Retention/Referral

Community không phải kênh acquisition, đừng đo bằng lead ngay. 3 loại theo tầng phễu:
- **TOFU (Open)**: giáo dục, growth-focused — đo bằng reach/growth, không kỳ vọng chuyển đổi cao
- **MOFU (Semi-closed)**: Q&A, poll — đo bằng tỉ lệ tham gia + chuyển đổi nhẹ sang lead
- **BOFU (Closed, chỉ KH đã mua)**: đo bằng tỉ lệ tham gia hoạt động + referral phát sinh + repeat purchase

Quy tắc nội dung trong community: 80% giá trị thật / 20% soft mention sản phẩm — vi phạm tỉ lệ này, community sẽ giống spam và mất tương tác thật.

</details>

---

# Creative Review

## 1. Triggers

### Explicit triggers
- Người dùng yêu cầu: "review creative này", "duyệt content giúp tôi", "check ads trước khi chạy"
- Người dùng hỏi: "caption này được không?", "nội dung này ổn chưa?", "copy này đúng tone chưa?"
- Người dùng paste nội dung và hỏi: "bạn thấy sao?", "có điểm nào cần sửa không?"

### Implicit triggers
- User paste một bài caption/script/ads copy vào conversation mà không nói gì thêm → đang chờ feedback
- User vừa chia sẻ brief và muốn kiểm tra trước khi giao cho designer/copywriter
- Team content vừa hoàn thành bài và cần sign-off trước khi publish
- Chuẩn bị upload ads nhưng chưa chắc về creative → cần double-check

## 2. Context Requirements

- [ ] **[BẮT BUỘC]** Nội dung cần review (caption / script / copy ads / brief / headline)
- [ ] **[BẮT BUỘC]** Tầng phễu mà content này nhắm đến (TOFU / MOFU / BOFU) — nếu không biết, Claude tự suy luận và confirm
- [ ] **[NẾU CÓ]** Brand Bible đã có (để đối chiếu tone + từ điển)
- [ ] **[NẾU CÓ]** Platform đăng (Facebook / TikTok / Instagram / Email / Ads)
- [ ] **[NẾU CÓ]** Mục tiêu cụ thể của bài: reach / engagement / click / lead / mua hàng

Đọc trước khi thực hiện:
- `brandformance-brand-bible` (nếu có) → Voice Matrix, Từ điển thương hiệu
- `brandformance-framework.md` → Phần III (Tỉ lệ Brand/Performance theo tầng phễu)
- `brandformance-content.md` → Phần IV (Ma trận content theo 3 tầng phễu)

## 3. Execution Steps

### Bước 1: Xác định context của creative
1.1 Đọc toàn bộ nội dung được review trước khi đưa ra bất kỳ nhận xét nào.
1.2 Nếu chưa biết tầng phễu → tự suy luận: "Bài này đang cố tạo awareness, hay đang bán hàng?" → confirm với user.
1.3 Nếu chưa biết platform → hỏi trước khi review chi tiết.
1.4 Map vào Brand Bible nếu có: voice, tone, từ điển → chuẩn bị đối chiếu.

### Bước 2: Đánh giá Brand Layer (0-10)
Chấm điểm theo 5 tiêu chí, mỗi tiêu chí tối đa 2 điểm:

**B1 — Cảm xúc / Câu chuyện (0-2 điểm)**
- Bài có yếu tố cảm xúc thật không? (không phải "chúng tôi trân trọng...")
- Có câu chuyện / observation / insight thật không?
- Người đọc có thể kết nối không?

**B2 — Brand Voice nhất quán (0-2 điểm)**
- Tone có đúng với Brand Bible không?
- Từ ngữ có đúng với Từ điển thương hiệu không?
- Giọng viết có nhất quán từ đầu đến cuối không?

**B3 — Giá trị cung cấp (0-2 điểm)**
- Người đọc nhận được gì từ bài này ngoài thông tin về sản phẩm?
- Có insight, kiến thức, hoặc điều gì KH sẽ muốn lưu/chia sẻ?

**B4 — Đúng tầng phễu (0-2 điểm)**
- TOFU: Không bán hàng, chạm vào vấn đề, không mention sản phẩm trực tiếp?
- MOFU: Proof, credibility, mention sản phẩm qua kết quả?
- BOFU: Offer rõ, deadline có lý do, reassuring, không aggressive?

**B5 — Không trông như quảng cáo (0-2 điểm)**
- Đọc lên có cảm giác "natural" không hay "ad-like"?
- Nếu che đi logo/brand name, người đọc có biết đây là quảng cáo không?

**Brand Layer Score: X/10**

### Bước 3: Đánh giá Performance Layer (0-10)
Chấm điểm theo 5 tiêu chí, mỗi tiêu chí tối đa 2 điểm:

**P1 — CTA rõ ràng và khả thi (0-2 điểm)**
- CTA có rõ người đọc cần làm gì không?
- CTA có phù hợp với mức độ commitment của tầng phễu không? (TOFU: follow / BOFU: mua ngay)

**P2 — Trigger hành động đúng nhóm KH (0-2 điểm)**
- Content trigger đúng Pain Point / Desire của nhóm KH đang nhắm không?
- Câu hook có đủ cụ thể để đúng người đọc dừng lại?

**P3 — Gắn với mục tiêu đo được (0-2 điểm)**
- Có UTM / tracking link nếu cần dẫn về landing page không?
- Kết quả của bài này sẽ được đo bằng chỉ số gì?

**P4 — Giảm ma sát chuyển đổi (0-2 điểm)**
- Có đủ thông tin để người đọc ra quyết định không?
- Có xử lý objection phổ biến ngay trong bài không?

**P5 — Urgency / Reason-to-act-now (0-2 điểm)**
- Nếu là BOFU: Có lý do rõ ràng để hành động ngay không? (không phải fake countdown)
- Lý do đó có thuyết phục không?

**Performance Layer Score: X/10**

### Bước 4: Tổng hợp Brandformance Score và feedback
4.1 Brandformance Score = (Brand Score + Performance Score) / 2

| Điểm | Đánh giá | Khuyến nghị |
|---|---|---|
| 8-10 | ✅ Xuất sắc | Ready to publish/run |
| 6-8 | 👍 Tốt | Publish với 1-2 chỉnh sửa nhỏ |
| 4-6 | ⚠️ Cần cải thiện | Sửa điểm quan trọng trước khi publish |
| 0-4 | 🔴 Cần làm lại | Viết lại thay vì patch |

4.2 Feedback cụ thể:
- Điểm mạnh: "[Câu/đoạn cụ thể] — tốt vì [lý do]"
- Điểm cần sửa: "[Câu/đoạn cụ thể] — vấn đề là [lý do] → đề xuất sửa thành [phiên bản gợi ý]"

4.3 Đề xuất phiên bản cải thiện nếu điểm < 6: Viết lại đoạn quan trọng nhất.

## 4. Edge Cases & Error Handling

**Case 1: Content quá dài (> 1000 từ)**
→ Hỏi: "Bài này dài, bạn muốn review toàn bộ hay tập trung vào phần cụ thể nào (hook, CTA, brand voice)?"

**Case 2: Không biết tầng phễu**
→ Tự suy luận và confirm: "Tôi đọc bài này và nghĩ đây là MOFU. Đúng không?"
→ Nếu content không rõ tầng phễu → đây tự nó là vấn đề cần flag.

**Case 3: Chưa có Brand Bible để đối chiếu**
→ Review dựa trên nguyên tắc chung, ghi chú: "Đây là review theo nguyên tắc chung. Có Brand Bible sẽ check chính xác hơn."

**Case 4: User không đồng ý với feedback**
→ Giải thích lý do cụ thể dựa trên nguyên tắc Brandformance.
→ Đề xuất test A/B: "Version của bạn vs version gợi ý — chạy 3 ngày và so CTR."

**Case 5: Content vi phạm quy tắc quảng cáo**
→ Flag ngay: "Câu [X] có thể vi phạm chính sách Meta/TikTok vì [lý do]."
→ Gợi ý cách viết lại đúng quy định nhưng vẫn giữ được ý.

**Case 6: User paste nhiều creative cùng lúc**
→ Review từng cái theo thứ tự.
→ Tổng hợp cuối: "Creative [A] mạnh nhất, nên ưu tiên run. Creative [C] cần sửa trước khi chạy."

## References

- `brandformance-brand-bible` — Voice Matrix và Từ điển thương hiệu để đối chiếu (nếu có)
- `brandformance-content.md` — Phần IV (Ma trận content theo tầng phễu)
- `brandformance-framework.md` — Phần III (Tỉ lệ Brand/Performance theo tầng)

Checklist nhanh trước khi publish:
1. ✅ Bài này ở tầng phễu nào? Tone có khớp không?
2. ✅ Brand Voice Matrix có được tuân thủ không?
3. ✅ Brand layer (cảm xúc, câu chuyện) đủ chưa?
4. ✅ Performance layer (CTA, trigger) rõ ràng không?
5. ✅ Bài này trông như "content thật" hay "quảng cáo rõ ràng"?
